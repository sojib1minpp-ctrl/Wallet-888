import { initializeApp, getApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDYGN2srwFjDBpyJWS1cbqmjH4LzRkohnE",
  authDomain: "wallet-888-5d12d.firebaseapp.com",
  databaseURL: "https://wallet-888-5d12d-default-rtdb.firebaseio.com",
  projectId: "wallet-888-5d12d",
  storageBucket: "wallet-888-5d12d.firebasestorage.app",
  messagingSenderId: "136687120401",
  appId: "1:136687120401:web:d04106b0c393fd5768c1b0"
};

// Initialize Firebase with a singleton pattern
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const db = getFirestore(app);
export const rtdb = getDatabase(app);
export const storage = getStorage(app);