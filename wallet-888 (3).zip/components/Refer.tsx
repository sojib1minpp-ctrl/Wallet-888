
import React from 'react';
import { User } from '../types';
import { ChevronLeft, Copy, Facebook, MessageCircle, Send } from 'lucide-react';

interface ReferProps {
  user: User;
  onBack: () => void;
  addNotification: (msg: string, type: any) => void;
}

const ReferView: React.FC<ReferProps> = ({ user, onBack, addNotification }) => {
  const referLink = `https://wallet888.app/reg?ref=${user.uid}`;
  const promoCode = `W888_${user.uid}`;

  const stats = [
    { label: 'TOTAL REFERS', value: user.totalRefers.toString(), color: 'text-[#5343e8]' },
    { label: 'DEPOSITED', value: user.refersDeposited.toString(), color: 'text-[#5343e8]' },
    { label: 'EARNED', value: `৳ ${user.totalEarned.toFixed(0)}`, color: 'text-[#5343e8]' },
  ];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    addNotification("Copied to clipboard!", "success");
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1 text-gray-500 dark:text-gray-400 font-bold">
          <ChevronLeft size={20} /> Back
        </button>
        <h2 className="text-xl font-black dark:text-white">Refer & Earn</h2>
        <div className="w-10"></div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] border border-gray-50 dark:border-gray-700">
        <div className="grid grid-cols-2 gap-4 mb-8">
          {stats.map((s, idx) => (
            <div 
              key={idx} 
              className={`bg-[#f4f6ff] dark:bg-gray-700/50 p-6 rounded-3xl text-center border border-white dark:border-gray-600 shadow-sm ${idx === 2 ? 'col-span-2' : ''}`}
            >
              <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-black tracking-[0.2em] mb-1">{s.label}</p>
              <p className={`text-2xl font-black ${s.color} dark:text-indigo-400`}>{s.value}</p>
            </div>
          ))}
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest ml-1">My Promo Code</label>
            <div className="flex gap-2">
              <div className="flex-1 px-5 py-4 bg-[#f4f6ff] dark:bg-gray-700/50 rounded-2xl font-mono font-black text-[#5343e8] dark:text-indigo-400 border border-white dark:border-gray-600 flex items-center shadow-inner overflow-hidden">
                <span className="truncate">{promoCode}</span>
              </div>
              <button onClick={() => handleCopy(promoCode)} className="p-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-600 rounded-2xl text-[#5343e8] hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm transition-all active:scale-95">
                <Copy size={20} strokeWidth={2.5} />
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest ml-1">Referral Link</label>
            <div className="flex gap-2">
              <div className="flex-1 px-5 py-4 bg-[#f4f6ff] dark:bg-gray-700/50 rounded-2xl text-[10px] text-gray-400 dark:text-gray-400 border border-white dark:border-gray-600 truncate flex items-center shadow-inner font-medium">
                {referLink}
              </div>
              <button onClick={() => handleCopy(referLink)} className="p-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-600 rounded-2xl text-[#5343e8] hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm transition-all active:scale-95">
                <Copy size={20} strokeWidth={2.5} />
              </button>
            </div>
          </div>

          <div className="pt-6 border-t border-gray-50 dark:border-gray-700 text-center">
            <p className="text-[10px] text-gray-400 dark:text-gray-500 font-black uppercase tracking-[0.2em] mb-6">Share via Social Media</p>
            <div className="flex justify-center gap-6">
              <button className="w-14 h-14 bg-[#0088cc] text-white rounded-full flex items-center justify-center hover:scale-110 shadow-lg shadow-[#0088cc]/30 transition-transform active:scale-95">
                <Send size={26} fill="white" />
              </button>
              <button className="w-14 h-14 bg-[#1877F2] text-white rounded-full flex items-center justify-center hover:scale-110 shadow-lg shadow-[#1877F2]/30 transition-transform active:scale-95">
                <Facebook size={26} fill="white" />
              </button>
              <button className="w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center hover:scale-110 shadow-lg shadow-[#25D366]/30 transition-transform active:scale-95">
                <MessageCircle size={26} fill="white" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/10 dark:to-orange-900/10 p-5 rounded-3xl border border-amber-100 dark:border-amber-800/50 text-center shadow-sm">
        <p className="text-[11px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-1">🎁 Instant Reward</p>
        <p className="text-xs font-bold text-amber-700 dark:text-amber-500">Get 2% instant bonus on your friend's first deposit!</p>
      </div>
    </div>
  );
};

export default ReferView;