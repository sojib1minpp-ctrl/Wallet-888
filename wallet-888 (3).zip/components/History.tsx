
import React, { useState } from 'react';
import { User, Transaction } from '../types';
import { Copy, ArrowUpRight, ArrowDownLeft } from 'lucide-react';

interface HistoryProps {
  user: User;
  transactions: Transaction[];
}

const History: React.FC<HistoryProps> = ({ user, transactions }) => {
  const [filter, setFilter] = useState<'all' | 'deposit' | 'withdraw'>('all');

  const filteredTx = transactions.filter(t => filter === 'all' || t.type === filter);

  const totalDeposit = transactions.filter(t => t.type === 'deposit' && t.status === 'success').reduce((acc, t) => acc + t.amount, 0);
  const totalWithdraw = transactions.filter(t => t.type === 'withdraw' && t.status === 'success').reduce((acc, t) => acc + t.amount, 0);

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          <p className="text-indigo-100 text-xs font-bold uppercase tracking-widest mb-1">Financial Summary</p>
          <h3 className="text-3xl font-bold mb-6">৳ {user.balance.toFixed(2)}</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 rounded-2xl p-3 border border-white/10">
              <p className="text-[10px] text-indigo-100 uppercase font-bold">Total Deposit</p>
              <p className="text-lg font-bold">৳{totalDeposit.toFixed(0)}</p>
            </div>
            <div className="bg-white/10 rounded-2xl p-3 border border-white/10">
              <p className="text-[10px] text-indigo-100 uppercase font-bold">Total Payout</p>
              <p className="text-lg font-bold">৳{totalWithdraw.toFixed(0)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex bg-white dark:bg-gray-800 p-1 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
        {(['all', 'deposit', 'withdraw'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all ${
              filter === f ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filteredTx.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-2xl border border-dashed border-gray-200 dark:border-gray-700">
            <p className="text-gray-400 italic">No transactions found</p>
          </div>
        ) : (
          filteredTx.map((tx) => (
            <div key={tx.id} className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex items-center gap-4 shadow-sm">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                tx.type === 'deposit' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
              }`}>
                {tx.type === 'deposit' ? <ArrowDownLeft size={24} /> : <ArrowUpRight size={24} />}
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <p className="font-bold dark:text-white capitalize">{tx.type} via {tx.method}</p>
                  <p className={`font-bold ${tx.type === 'deposit' ? 'text-green-500' : 'text-rose-500'}`}>
                    {tx.type === 'deposit' ? '+' : '-'} ৳{tx.amount.toFixed(0)}
                  </p>
                </div>
                <div className="flex justify-between items-end mt-1">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-gray-400">{tx.date}</span>
                    <span className="text-[10px] text-gray-500 font-mono flex items-center gap-1 cursor-pointer hover:text-indigo-600">
                      ID: {tx.id.toUpperCase()} <Copy size={10} />
                    </span>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                    tx.status === 'success' ? 'bg-green-100 text-green-700' : 
                    tx.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {tx.status}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default History;
