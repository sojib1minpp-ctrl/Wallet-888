
import React, { useState, useEffect } from 'react';
import { User } from '../types';
// Fixed: Added Gift to the imports from lucide-react
import { ChevronLeft, RotateCw, Lock, Clock, X, Gift } from 'lucide-react';

interface FreeSpinProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  onBack: () => void;
  addNotification: (msg: string, type: any) => void;
  updateBalance: (amt: number) => void;
}

const FreeSpin: React.FC<FreeSpinProps> = ({ user, setUser, onBack, addNotification, updateBalance }) => {
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [showWinBanner, setShowWinBanner] = useState(false);
  const [lastWinVal, setLastWinVal] = useState(0);

  // Cooldown calculation: 24 hours
  const COOLDOWN_PERIOD = 24 * 60 * 60 * 1000;

  useEffect(() => {
    const updateTimer = () => {
      if (!user.lastSpinDate) {
        setTimeLeft(0);
        return;
      }
      const nextSpinTime = new Date(user.lastSpinDate).getTime() + COOLDOWN_PERIOD;
      const now = Date.now();
      const diff = nextSpinTime - now;
      setTimeLeft(diff > 0 ? diff : 0);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [user.lastSpinDate]);

  const segments = [
    { value: 1, color: '#f87171' },
    { value: 5, color: '#fb923c' },
    { value: 10, color: '#fbbf24' },
    { value: 50, color: '#4ade80' },
    { value: 100, color: '#2dd4bf' },
    { value: 1000, color: '#38bdf8' },
    { value: 2000, color: '#818cf8' },
    { value: 3000, color: '#c084fc' },
    { value: 800000, color: '#f472b6' },
    { value: 5, color: '#f87171' },
  ];

  const formatTime = (ms: number) => {
    const h = Math.floor(ms / (1000 * 60 * 60));
    const m = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const s = Math.floor((ms % (1000 * 60)) / 1000);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSpin = () => {
    if (spinning) return;
    
    if (user.spinDaysRemaining <= 0) {
      addNotification("ডিপোজিট না করলে স্পিন করতে পারবেন না!", "error");
      return;
    }

    if (timeLeft > 0) {
      addNotification(`পরবর্তী স্পিনের জন্য অপেক্ষা করুন: ${formatTime(timeLeft)}`, "info");
      return;
    }

    setSpinning(true);
    const spinCount = 8 + Math.floor(Math.random() * 5); 
    const sliceAngle = 360 / segments.length;
    
    const isLucky = Math.random() > 0.999; 
    let targetIndex;
    if (isLucky) {
      targetIndex = Math.floor(Math.random() * segments.length);
    } else {
      targetIndex = Math.random() > 0.5 ? 0 : (Math.random() > 0.5 ? 1 : 9);
    }

    const targetRotation = (360 - (targetIndex * sliceAngle)) + (360 * spinCount);
    setRotation(targetRotation);

    setTimeout(() => {
      setSpinning(false);
      const winValue = segments[targetIndex].value;
      
      updateBalance(winValue);
      setLastWinVal(winValue);
      setShowWinBanner(true);

      setUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          spinDaysRemaining: prev.spinDaysRemaining - 1,
          lastSpinDate: new Date().toISOString()
        };
      });

      addNotification(`অভিনন্দন! আপনি জিতেছেন ৳ ${winValue}`, "success");
    }, 3000);
  };

  const isLocked = user.spinDaysRemaining <= 0;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <div className="flex items-center justify-between px-1">
        <button onClick={onBack} className="flex items-center gap-1 text-gray-500 dark:text-gray-400 font-bold">
          <ChevronLeft size={20} /> Back
        </button>
        <h2 className="text-xl font-bold dark:text-white">Daily Fortune</h2>
        <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-900/20 px-3 py-1 rounded-full border border-amber-100 dark:border-amber-800 shadow-sm">
           <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-tight">{user.spinDaysRemaining} Days Left</span>
        </div>
      </div>

      <div className="flex flex-col items-center py-10 bg-white dark:bg-gray-800 rounded-[3rem] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)] relative overflow-hidden border border-gray-50 dark:border-gray-700">
        
        {/* Win Notification Banner as seen in screenshot */}
        {showWinBanner && (
          <div className="absolute top-4 left-4 right-4 z-40 animate-in slide-in-from-top duration-500">
             <div className="bg-white/95 dark:bg-gray-700/95 backdrop-blur-md px-4 py-3 rounded-2xl border border-green-500/30 shadow-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600">
                      <RotateCw size={16} className="animate-spin-slow" />
                   </div>
                   <p className="text-xs font-black text-gray-800 dark:text-white truncate">অভিনন্দন! আপনি জিতেছেন ৳ {lastWinVal}</p>
                </div>
                <button onClick={() => setShowWinBanner(false)} className="text-gray-400 p-1"><X size={16} /></button>
             </div>
          </div>
        )}

        {isLocked && (
          <div className="absolute inset-0 bg-white/60 dark:bg-gray-800/80 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-8 text-center">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mb-4 text-gray-400 shadow-inner">
              <Lock size={32} />
            </div>
            <h3 className="text-lg font-black dark:text-white mb-2 uppercase tracking-tight">স্পিন লক করা আছে!</h3>
            <p className="text-sm text-gray-500 mb-8 font-medium">একটি ডিপোজিট করুন এবং ১০ দিনের স্পিন সাইকেল শুরু করুন!</p>
            <button onClick={onBack} className="bg-[#5343e8] text-white px-10 py-4 rounded-2xl font-black text-xs shadow-xl shadow-indigo-600/20 active:scale-95 transition-all uppercase tracking-widest">ডিপোজিট করুন</button>
          </div>
        )}

        {/* The Wheel */}
        <div className="relative w-72 h-72 mb-10 group">
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20 w-8 h-8 flex items-center justify-center drop-shadow-2xl">
            <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[22px] border-t-[#dc2626]"></div>
          </div>
          
          <div 
            className="w-full h-full rounded-full border-8 border-white dark:border-gray-700 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.3)] overflow-hidden relative spin-wheel"
            style={{ 
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? 'transform 3s cubic-bezier(0.15, 0, 0.15, 1)' : 'none'
            }}
          >
            {segments.map((seg, i) => {
              const angle = 360 / segments.length;
              return (
                <div 
                  key={i}
                  className="absolute top-0 left-1/2 w-1/2 h-full origin-left flex items-start justify-center pt-8"
                  style={{ 
                    transform: `rotate(${i * angle}deg)`,
                    backgroundColor: seg.color,
                    clipPath: `polygon(0% 0%, 100% 0%, 100% ${Math.tan((angle / 2) * (Math.PI / 180)) * 100}%, 0% 50%)`,
                    width: '100%',
                    left: '50%',
                    transformOrigin: '0% 50%'
                  }}
                >
                   <span 
                    className="text-[10px] font-black text-white whitespace-nowrap drop-shadow-md"
                    style={{ transform: `rotate(${angle / 2}deg) translateY(-8px) translateX(22px)` }}
                   >
                    ৳{seg.value >= 1000 ? (seg.value / 1000) + 'K' : seg.value}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="absolute inset-0 m-auto w-14 h-14 bg-white dark:bg-gray-700 rounded-full shadow-2xl z-10 flex items-center justify-center font-black text-indigo-600 dark:text-indigo-400 border-4 border-indigo-50 dark:border-gray-600 text-sm">
            888
          </div>
        </div>

        {/* 24-Hour Timer Display as seen in screenshot */}
        <div className="text-center px-8 mb-8 space-y-4">
          {timeLeft > 0 ? (
            <div className="flex flex-col items-center gap-3 animate-in fade-in duration-500">
              <div className="flex items-center gap-3 bg-rose-50 dark:bg-rose-900/10 px-6 py-3 rounded-2xl border border-rose-100 dark:border-rose-800 shadow-inner">
                <Clock size={22} className="text-rose-500 animate-pulse" />
                <span className="text-2xl font-black text-rose-500 tabular-nums tracking-wider">
                   {formatTime(timeLeft)}
                </span>
              </div>
              <p className="text-[10px] text-gray-400 dark:text-gray-500 font-black uppercase tracking-[0.25em] ml-1">Next spin available in</p>
            </div>
          ) : (
            <div className="bg-indigo-50 dark:bg-indigo-900/10 px-8 py-4 rounded-2xl border border-indigo-100 dark:border-indigo-800/50">
               <p className="text-gray-700 dark:text-gray-300 text-xs font-bold leading-relaxed">
                  ২৪ ঘন্টায় একবার স্পিন করতে পারবেন।<br/>
                  <span className="text-[11px] opacity-70 font-black text-indigo-600 dark:text-indigo-400 mt-1 block uppercase tracking-tighter">সাইকেল বাকি: {user.spinDaysRemaining} দিন</span>
               </p>
            </div>
          )}
        </div>

        {/* Action Button */}
        <button 
          onClick={handleSpin}
          disabled={spinning || timeLeft > 0 || isLocked}
          className={`px-16 py-5 rounded-[2rem] font-black text-white shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 text-lg uppercase tracking-widest ${
            spinning || timeLeft > 0 || isLocked
              ? 'bg-gray-200 dark:bg-gray-700 cursor-not-allowed text-gray-400 dark:text-gray-500 shadow-none border-b-4 border-gray-300 dark:border-gray-800' 
              : 'bg-gradient-to-r from-[#5343e8] to-[#6d5ae0] hover:shadow-[0_20px_40px_-10px_rgba(83,67,232,0.5)] border-b-4 border-indigo-800'
          }`}
        >
          {spinning ? (
            <RotateCw size={24} className="animate-spin" />
          ) : timeLeft > 0 ? (
            <span className="opacity-60">LOCKED</span>
          ) : (
            <>
              <RotateCw size={24} />
              SPIN NOW
            </>
          )}
        </button>
      </div>
      
      {/* Tips section as requested in screenshot */}
      <div className="bg-indigo-50 dark:bg-indigo-900/10 p-6 rounded-[2.5rem] border border-indigo-100 dark:border-indigo-800 shadow-sm relative overflow-hidden group">
        <div className="absolute -right-4 -top-4 opacity-5 group-hover:opacity-10 transition-opacity">
           <Gift size={80} className="text-indigo-600" />
        </div>
        <div className="flex gap-4 items-start">
           <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-800/30 flex items-center justify-center shrink-0">
              <span className="text-lg">💡</span>
           </div>
           <p className="text-xs text-indigo-700 dark:text-indigo-400 font-bold leading-relaxed">
            টিপস: আপনি যদি ১০ দিনের ভেতরে পুনরায় ডিপোজিট করেন, তবে আপনার স্পিন সাইকেল আবার নতুন করে ১০ দিন শুরু হবে।
           </p>
        </div>
      </div>
    </div>
  );
};

export default FreeSpin;
