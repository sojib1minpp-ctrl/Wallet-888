import React, { useState, useEffect, useMemo } from 'react';
import { User, AppSettings } from '../types';
import { ChevronRight, Trophy, Medal, Award, Zap } from 'lucide-react';
import CrystalGame from './CrystalGame';
import WingoGame from './WingoGame';
import AviatorGame from './AviatorGame';
import SnakeGame from './SnakeGame';
import SuperSlot from './SuperSlot';

interface GamesProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type?: any) => void;
  onNavigate: (tab: any) => void;
  onGameToggle?: (isActive: boolean) => void;
  settings: AppSettings;
}

interface RecentWinner {
  id: string;
  uid: string;
  amount: number;
  game: string;
  time: string;
  avatarSeed: string;
}

const Games: React.FC<GamesProps> = ({ user, setUser, addNotification, onNavigate, onGameToggle, settings }) => {
  const [currentBanner, setCurrentBanner] = useState(0);
  const [recentWinners, setRecentWinners] = useState<RecentWinner[]>([]);
  const [activeGame, setActiveGame] = useState<string | null>(null);

  const banners = useMemo(() => [
    { 
      id: 1, 
      img: settings.banner1Img,
      title: settings.banner1Title
    },
    { 
      id: 2, 
      img: settings.banner2Img,
      title: settings.banner2Title
    },
    { 
      id: 3, 
      img: settings.banner3Img,
      title: settings.banner3Title
    }
  ], [settings.banner1Img, settings.banner1Title, settings.banner2Img, settings.banner2Title, settings.banner3Img, settings.banner3Title]);

  const gameList = useMemo(() => [
    { name: 'Aviator', color: 'from-rose-600 to-red-700', icon: '✈️', id: 'aviator' },
    { name: 'Big / Small', color: 'from-amber-400 to-orange-500', icon: '🎲', id: 'wingo' },
    { name: 'Classic Cards', color: 'from-blue-500 to-indigo-600', icon: '🃏', id: 'crystal' },
    { name: 'Super Slot', color: 'from-purple-500 to-indigo-600', icon: '🎰', id: 'slot' },
    { name: 'Snake Tower', color: 'from-red-500 to-orange-600', icon: '🐍', id: 'snake' },
    { name: 'Spin Winner', color: 'from-emerald-400 to-teal-500', icon: '🎡' },
  ], []);

  const topThree = useMemo(() => [
    { name: 'SABBIR_KING', amount: '8,40,00,000.50', rank: 1, uid: '9231408', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sabbir' },
    { name: 'RAJU_WINNER', amount: '45,20,000.75', rank: 2, uid: '1283921', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Raju' },
    { name: 'ANIK_PRO', amount: '12,80,000.25', rank: 3, uid: '5562712', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Anik' }
  ], []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [banners.length]);

  useEffect(() => {
    const generateWinner = () => ({
      id: Math.random().toString(36).substr(2, 9),
      uid: Math.floor(1000000 + Math.random() * 9000000).toString(),
      amount: Math.floor(Math.random() * 5000 + 100),
      game: gameList[Math.floor(Math.random() * gameList.length)].name,
      time: 'Now',
      avatarSeed: Math.random().toString(36).substr(2, 5)
    });

    setRecentWinners(Array.from({ length: 10 }, generateWinner));

    const ticker = setInterval(() => {
      setRecentWinners(prev => {
        const newList = [generateWinner(), ...prev.slice(0, 9)];
        return newList;
      });
    }, 2500);

    return () => clearInterval(ticker);
  }, [gameList]);

  useEffect(() => {
    if (onGameToggle) {
      onGameToggle(activeGame !== null);
    }
  }, [activeGame, onGameToggle]);

  const handleGameClick = (game: any) => {
    if (game.id === 'crystal') {
      setActiveGame('crystal');
    } else if (game.id === 'wingo') {
      setActiveGame('wingo');
    } else if (game.id === 'aviator') {
      setActiveGame('aviator');
    } else if (game.id === 'snake') {
      setActiveGame('snake');
    } else if (game.id === 'slot') {
      setActiveGame('slot');
    } else {
      addNotification(`Entering ${game.name}...`);
    }
  };

  if (activeGame === 'crystal') {
    return <CrystalGame user={user} setUser={setUser} addNotification={addNotification} onBack={() => setActiveGame(null)} />;
  }

  if (activeGame === 'wingo') {
    return <WingoGame user={user} setUser={setUser} addNotification={addNotification} onBack={() => setActiveGame(null)} />;
  }

  if (activeGame === 'aviator') {
    return <AviatorGame user={user} setUser={setUser} addNotification={addNotification} onBack={() => setActiveGame(null)} onDepositClick={() => { setActiveGame(null); onNavigate('deposit'); }} />;
  }

  if (activeGame === 'snake') {
    return <SnakeGame user={user} setUser={setUser} addNotification={addNotification} onBack={() => setActiveGame(null)} />;
  }

  if (activeGame === 'slot') {
    return <SuperSlot user={user} setUser={setUser} addNotification={addNotification} onBack={() => setActiveGame(null)} />;
  }

  return (
    <div className="space-y-6 pb-10">
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em]">Latest Announcements</h3>
          <span className="text-[9px] bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-black uppercase">Admin Ads</span>
        </div>
        
        <div className="relative h-44 w-full rounded-[2rem] overflow-hidden shadow-xl border border-white/50 dark:border-gray-700 bg-gray-200 dark:bg-gray-800">
          {banners.map((banner, index) => (
            <div
              key={banner.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                index === currentBanner ? 'opacity-100 z-10' : 'opacity-0 z-0'
              }`}
            >
              <img src={banner.img} alt={banner.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex flex-col justify-end p-6">
                <h4 className="text-white font-black text-xl tracking-tight leading-tight transform translate-y-0 transition-transform duration-500 delay-100">
                  {banner.title}
                </h4>
              </div>
            </div>
          ))}
          
          <div className="absolute bottom-4 right-6 z-20 flex gap-1.5">
            {banners.map((_, index) => (
              <div
                key={index}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  index === currentBanner ? 'w-6 bg-white' : 'w-1.5 bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">Popular Games</h2>
          <button className="flex items-center gap-1 text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest hover:underline">
            View All <ChevronRight size={12} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {gameList.map((game, idx) => (
            <button
              key={idx}
              onClick={() => handleGameClick(game)}
              className={`relative group overflow-hidden h-40 rounded-[2.5rem] bg-gradient-to-br ${game.color} shadow-[0_15px_30px_-10px_rgba(0,0,0,0.15)] active:scale-[0.96] transition-all flex flex-col items-center justify-center p-4 border-4 border-white dark:border-gray-800`}
            >
              <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"></div>
              <span className="text-5xl mb-3 drop-shadow-md transform group-hover:scale-110 transition-transform duration-300">{game.icon}</span>
              <span className="text-white font-black text-center text-sm leading-tight uppercase tracking-widest">
                {game.name}
              </span>
              <div className="absolute top-4 right-4 px-2 py-0.5 bg-white/30 backdrop-blur-md rounded-full text-[8px] text-white font-black tracking-widest uppercase">
                LIVE
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">Tournament Ranking</h2>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Live Updates</span>
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] p-6 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] border border-gray-100 dark:border-gray-700">
          <div className="flex items-end justify-center gap-3 mb-10 pt-10">
            <div className="flex flex-col items-center w-28 text-center animate-in slide-in-from-left-4 duration-700">
              <div className="relative mb-3">
                <Medal className="absolute -top-10 left-1/2 -translate-x-1/2 text-gray-400 drop-shadow-lg" size={32} strokeWidth={2.5} />
                <div className="w-20 h-20 rounded-full border-4 border-gray-100 dark:border-gray-700 overflow-hidden bg-gray-50 ring-4 ring-gray-100/30">
                  <img src={topThree[1].avatar} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-2 -right-1 bg-gray-400 text-white w-7 h-7 rounded-full flex items-center justify-center font-black text-xs border-2 border-white">2</div>
              </div>
              <p className="text-[11px] font-black text-gray-900 dark:text-white truncate w-full uppercase tracking-tighter mb-0.5">{topThree[1].name}</p>
              <p className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400">৳ {topThree[1].amount}</p>
            </div>

            <div className="flex flex-col items-center w-36 pb-6 scale-110 animate-in zoom-in duration-700">
              <div className="relative mb-4">
                <Trophy className="absolute -top-12 left-1/2 -translate-x-1/2 text-amber-500 drop-shadow-[0_0_15px_rgba(245,158,11,0.6)] animate-bounce duration-[2000ms]" size={48} strokeWidth={2.5} />
                <div className="w-24 h-24 rounded-full border-4 border-amber-400 overflow-hidden bg-amber-50 shadow-2xl ring-8 ring-amber-400/10 dark:ring-amber-900/20">
                  <img src={topThree[0].avatar} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-2 -right-2 bg-amber-500 text-white w-9 h-9 rounded-full flex items-center justify-center font-black text-sm border-4 border-white shadow-lg">1</div>
              </div>
              <p className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-tighter mb-0.5">{topThree[0].name}</p>
              <p className="text-xs font-black text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded-lg border border-amber-100 dark:border-amber-800">৳ {topThree[0].amount}</p>
            </div>

            <div className="flex flex-col items-center w-28 text-center animate-in slide-in-from-right-4 duration-700">
              <div className="relative mb-3">
                <Award className="absolute -top-10 left-1/2 -translate-x-1/2 text-orange-400 drop-shadow-md" size={32} strokeWidth={2.5} />
                <div className="w-20 h-20 rounded-full border-4 border-orange-100 dark:border-gray-700 overflow-hidden bg-gray-50 ring-4 ring-orange-100/30">
                  <img src={topThree[2].avatar} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-2 -right-1 bg-orange-400 text-white w-7 h-7 rounded-full flex items-center justify-center font-black text-xs border-2 border-white">3</div>
              </div>
              <p className="text-[11px] font-black text-gray-900 dark:text-white truncate w-full uppercase tracking-tighter mb-0.5">{topThree[2].name}</p>
              <p className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400">৳ {topThree[2].amount}</p>
            </div>
          </div>

          <div className="h-[1px] bg-gray-100 dark:bg-gray-700 w-full mb-8"></div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.25em] mb-4 flex items-center gap-2">
              <Zap size={14} className="text-amber-500 fill-amber-500" /> Live Winner Feed
            </h4>
            
            <div className="space-y-3">
              {recentWinners.map((winner, idx) => (
                <div key={winner.id} className="flex items-center gap-4 bg-[#f8f9ff] dark:bg-gray-700/40 p-3.5 rounded-3xl border border-white dark:border-gray-700 shadow-sm animate-in fade-in slide-in-from-right-4 duration-500" style={{ animationDelay: `${idx * 100}ms` }}>
                  <div className="w-12 h-12 rounded-2xl overflow-hidden bg-indigo-50 border-2 border-white shadow-inner">
                    <img src={`https://api.dicebear.com/7.x/pixel-art/svg?seed=${winner.avatarSeed}`} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-black dark:text-white leading-none mb-1.5 uppercase tracking-tighter">UID: {winner.uid}</p>
                    <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-1">
                      Won in <span className="text-indigo-600 dark:text-indigo-400">{winner.game}</span>
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-black text-green-500 tracking-tight leading-none mb-1">৳{winner.amount.toFixed(2)}</p>
                    <span className="text-[8px] font-black text-gray-300 dark:text-gray-600 uppercase tracking-widest">{winner.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Games;