
import React, { useState } from 'react';
import { User, Transaction, AppSettings } from '../types';
import { Copy, CheckCircle, Info, Clock, ShieldCheck, Zap, Image as ImageIcon, X, FileText, Smartphone } from 'lucide-react';

interface DepositProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type: 'success' | 'info') => void;
  onNewTransaction: (tx: Transaction) => void;
  settings: AppSettings;
}

const Deposit: React.FC<DepositProps> = ({ user, setUser, addNotification, onNewTransaction, settings }) => {
  const [step, setStep] = useState(1);
  const [method, setMethod] = useState<'Bkash' | 'Nagad' | 'Binance' | null>(null);
  const [amount, setAmount] = useState<string>('');
  const [txnId, setTxnId] = useState('');
  const [screenshot, setScreenshot] = useState<string | null>(null);

  const getMethodData = () => {
    if (method === 'Bkash') return { number: settings.bkashNumber, title: settings.bkashTitle, instruction: settings.bkashInstruction, img: settings.bkashImg };
    if (method === 'Nagad') return { number: settings.nagadNumber, title: settings.nagadTitle, instruction: settings.nagadInstruction, img: settings.nagadImg };
    if (method === 'Binance') return { number: settings.binanceNumber, title: settings.binanceTitle, instruction: settings.binanceInstruction, img: settings.binanceImg };
    return { number: '', title: '', instruction: '', img: '' };
  };

  const { number: targetNumber, title: targetTitle, instruction: targetInstruction, img: targetImg } = getMethodData();

  const handleNext = () => {
    const amt = parseFloat(amount);
    if (!amt || amt < 300 || amt > 25000) {
      alert("Amount must be between ৳300 and ৳25,000");
      return;
    }
    setStep(2);
  };

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!txnId) {
      alert("Please enter Transaction ID");
      return;
    }
    if (!screenshot) {
      alert("Please upload a payment screenshot");
      return;
    }
    
    const depositAmt = parseFloat(amount);
    const newTx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      uid: user.uid,
      type: 'deposit',
      amount: depositAmt,
      method: method || '',
      status: 'pending',
      date: new Date().toLocaleString(),
      txnId: txnId,
      screenshotUrl: screenshot
    };

    onNewTransaction(newTx);
    setUser(prev => prev ? { ...prev, spinDaysRemaining: 10, totalDeposits: (prev.totalDeposits || 0) + depositAmt } : null);
    addNotification("পেমেন্ট রিকোয়েস্ট পাঠানো হয়েছে!", 'success');
    
    setStep(1);
    setAmount('');
    setTxnId('');
    setMethod(null);
    setScreenshot(null);
  };

  const copyNumber = () => {
    navigator.clipboard.writeText(targetNumber);
    addNotification("Number copied!", 'info');
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <h2 className="text-2xl font-black dark:text-white">Deposit Funds</h2>

      {step === 1 ? (
        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => setMethod('Bkash')}
              className={`p-3 rounded-[1.5rem] border-2 transition-all flex flex-col items-center gap-2 bg-white dark:bg-gray-800 shadow-sm ${
                method === 'Bkash' ? 'border-pink-500 ring-4 ring-pink-50' : 'border-gray-50 dark:border-gray-700'
              }`}
            >
              <div className="w-12 h-12 rounded-xl overflow-hidden shadow-inner">
                <img src={settings.bkashImg} alt="Bkash" className="w-full h-full object-cover" />
              </div>
              <span className="font-black text-[9px] uppercase tracking-widest text-pink-600">bKash</span>
            </button>
            <button
              onClick={() => setMethod('Nagad')}
              className={`p-3 rounded-[1.5rem] border-2 transition-all flex flex-col items-center gap-2 bg-white dark:bg-gray-800 shadow-sm ${
                method === 'Nagad' ? 'border-orange-500 ring-4 ring-orange-50' : 'border-gray-50 dark:border-gray-700'
              }`}
            >
              <div className="w-12 h-12 rounded-xl overflow-hidden shadow-inner">
                <img src={settings.nagadImg} alt="Nagad" className="w-full h-full object-cover" />
              </div>
              <span className="font-black text-[9px] uppercase tracking-widest text-orange-600">Nagad</span>
            </button>
            <button
              onClick={() => setMethod('Binance')}
              className={`p-3 rounded-[1.5rem] border-2 transition-all flex flex-col items-center gap-2 bg-white dark:bg-gray-800 shadow-sm ${
                method === 'Binance' ? 'border-amber-500 ring-4 ring-amber-50' : 'border-gray-50 dark:border-gray-700'
              }`}
            >
              <div className="w-12 h-12 rounded-xl overflow-hidden shadow-inner flex items-center justify-center bg-amber-100">
                <img src={settings.binanceImg} alt="Binance" className="w-full h-full object-cover" />
              </div>
              <span className="font-black text-[9px] uppercase tracking-widest text-amber-600">Binance</span>
            </button>
          </div>

          {method && (
            <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-xl border border-gray-50 dark:border-gray-700 animate-in zoom-in-95 duration-300">
              <div className="flex items-center gap-3 mb-6">
                 <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl flex items-center justify-center text-indigo-600 overflow-hidden">
                   <img src={targetImg} className="w-full h-full object-cover" />
                 </div>
                 <div>
                    <h3 className="text-sm font-black dark:text-white uppercase leading-none">{targetTitle}</h3>
                    <p className="text-[9px] font-bold text-gray-400 mt-1 uppercase tracking-widest">Add amount below</p>
                 </div>
              </div>

              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-1">Deposit Amount (৳300 - ৳25,000)</label>
              <div className="relative group">
                <span className="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-black text-gray-300">৳</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-14 pr-6 py-6 rounded-3xl border border-gray-100 dark:bg-gray-700 dark:text-white outline-none text-2xl font-black shadow-inner"
                  placeholder="0.00"
                />
              </div>
              <button onClick={handleNext} className="w-full mt-8 bg-indigo-600 text-white font-black py-6 rounded-3xl shadow-xl uppercase tracking-widest active:scale-95 transition-all">Next Step</button>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[3rem] shadow-2xl border border-gray-100 dark:border-gray-700 space-y-8 animate-in zoom-in-95 duration-500">
          <div className="text-center space-y-6">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-4 leading-none">SEND MONEY TO {targetTitle}:</p>
            <div className="relative group">
              <div className={`flex items-center justify-center gap-4 py-6 px-4 rounded-[2rem] border-2 border-dashed shadow-inner transition-colors ${
                method === 'Bkash' ? 'bg-pink-50 dark:bg-pink-900/10 border-pink-100' : 
                method === 'Nagad' ? 'bg-orange-50 dark:bg-orange-900/10 border-orange-100' : 
                'bg-amber-50 dark:bg-amber-900/10 border-amber-100'
              }`}>
                <span className={`text-2xl font-mono font-black tracking-[0.05em] ${
                  method === 'Bkash' ? 'text-pink-600' : 
                  method === 'Nagad' ? 'text-orange-600' : 
                  'text-amber-600'
                }`}>{targetNumber}</span>
                <button onClick={copyNumber} className="p-3 bg-white dark:bg-gray-600 text-indigo-600 rounded-2xl shadow-md active:scale-90"><Copy size={24} /></button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-indigo-50 dark:bg-indigo-900/20 p-6 rounded-[2rem] border border-indigo-100 dark:border-indigo-800 space-y-4">
              <div className="text-center">
                <p className="text-sm font-black text-indigo-600 dark:text-indigo-400 uppercase">{method} Deposit: ৳{amount}</p>
                <p className="text-xs font-bold text-gray-600 dark:text-gray-300 mt-2 leading-relaxed">
                  {targetInstruction}
                </p>
              </div>
              <div className="h-px bg-indigo-200 dark:bg-indigo-800/50"></div>
              <p className="text-[11px] font-bold text-rose-500 leading-relaxed text-center px-2 italic">
                প্রিয় গ্রাহক কোনরকম ডিপোজিট সমস্যা হলে আমাদের সাথে যোগাযোগ করবেন দয়া করে ভুল ইনফরমেশন দিবেন না তাহলে আপনার একাউন্ট রিস্ক হয়ে যাবে পরবর্তীতে এটার জন্য দায়ী ভাই আমি নয় সঠিকভাবে কাজ করুন ধন্যবাদ
              </p>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Transaction ID / PayID</label>
              <input type="text" value={txnId} onChange={(e) => setTxnId(e.target.value)} className="w-full px-6 py-5 rounded-3xl border border-gray-100 dark:bg-gray-700 dark:text-white outline-none font-mono font-black text-lg shadow-inner uppercase tracking-wider" placeholder="8X7Y2Z1W..." />
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Upload Result Screenshot</label>
              {!screenshot ? (
                <div className="relative">
                  <input type="file" accept="image/*" onChange={handleScreenshotUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" />
                  <div className="w-full py-10 rounded-3xl border-2 border-dashed border-gray-200 dark:bg-gray-700/50 flex flex-col items-center justify-center gap-2">
                    <ImageIcon size={32} className="text-gray-300" />
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Proof Image</span>
                  </div>
                </div>
              ) : (
                <div className="relative rounded-3xl overflow-hidden group">
                  <img src={screenshot} alt="Payment Proof" className="w-full h-44 object-cover" />
                  <button onClick={() => setScreenshot(null)} className="absolute top-3 right-3 p-2 bg-black/50 text-white rounded-full"><X size={16} /></button>
                </div>
              )}
            </div>

            <button onClick={handleSubmit} className="w-full bg-[#10b981] text-white font-black py-6 rounded-[2rem] shadow-xl flex items-center justify-center gap-3 text-lg uppercase tracking-widest active:scale-95 transition-all">
              Confirm Deposit Request
            </button>
            <button onClick={() => setStep(1)} className="w-full text-gray-400 text-[10px] font-black uppercase tracking-widest">Go Back</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Deposit;
