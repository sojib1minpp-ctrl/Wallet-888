import React from 'react';
import { ShieldCheck, Zap } from 'lucide-react';

const SplashScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-[#0c0f1d] flex flex-col items-center justify-center z-[9999] overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-indigo-600/20 rounded-full blur-[100px] animate-pulse"></div>
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-purple-600/20 rounded-full blur-[100px] animate-pulse"></div>
      
      {/* Glossy Card Logo */}
      <div className="relative mb-10 group">
        <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-[3rem] blur-2xl opacity-30 group-hover:opacity-50 transition-opacity animate-pulse"></div>
        <div className="relative w-32 h-32 bg-white rounded-[2.5rem] flex items-center justify-center shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5)] transform hover:scale-105 transition-transform duration-500 border-b-8 border-gray-200">
          <span className="text-5xl font-black bg-gradient-to-br from-indigo-600 to-purple-700 bg-clip-text text-transparent">888</span>
        </div>
      </div>
      
      {/* Branding */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-black text-white mb-3 tracking-[0.2em] uppercase drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">Wallet 888</h1>
        <div className="h-1 w-20 bg-gradient-to-r from-indigo-500 to-purple-600 mx-auto rounded-full"></div>
      </div>
      
      {/* Loading Bar Container */}
      <div className="relative w-72">
        <div className="flex justify-between items-center mb-3 px-1">
          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
            <Zap size={12} className="fill-indigo-400" /> System Loading
          </span>
          <span className="text-[10px] font-black text-white/40 tabular-nums">EST. 2.5S</span>
        </div>
        <div className="w-full h-3 bg-white/5 rounded-full overflow-hidden border border-white/10 shadow-inner">
          <div className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-500 animate-loading-bar rounded-full shadow-[0_0_15px_rgba(99,102,241,0.6)] animate-gradient"></div>
        </div>
      </div>
      
      {/* Security Footer */}
      <div className="absolute bottom-12 flex flex-col items-center gap-4">
        <div className="flex items-center gap-2 bg-white/5 px-6 py-3 rounded-full border border-white/10 backdrop-blur-xl">
           <ShieldCheck size={16} className="text-green-400" />
           <p className="text-[10px] font-black text-white/60 uppercase tracking-widest leading-none">AES-256 SECURED ENVIRONMENT</p>
        </div>
        <div className="flex gap-4 opacity-20">
           <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
           <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce"></div>
           <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
        </div>
      </div>
      
      <style>{`
        @keyframes loading-bar {
          0% { width: 0%; }
          20% { width: 35%; }
          50% { width: 65%; }
          80% { width: 92%; }
          100% { width: 100%; }
        }
        .animate-loading-bar {
          animation: loading-bar 3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }
      `}</style>
    </div>
  );
};

export default SplashScreen;