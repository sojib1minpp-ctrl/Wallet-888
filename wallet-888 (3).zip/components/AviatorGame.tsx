
import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { ChevronLeft, MoreHorizontal, Minus, Plus, History as HistoryIcon, Volume2, VolumeX, ShieldCheck, Zap, Cloud, RotateCcw } from 'lucide-react';

interface AviatorGameProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type?: any) => void;
  onBack: () => void;
  onDepositClick: () => void;
}

interface AviatorBet {
  id: string;
  user: string;
  avatar: string;
  amount: number;
  multiplier?: number;
  winAmount?: number;
  status: 'pending' | 'cashed-out' | 'lost';
  isLocalUser?: boolean;
}

interface UserAviatorHistory {
  id: string;
  amount: number;
  multiplier?: number;
  winAmount?: number;
  status: 'win' | 'loss';
  time: string;
}

const AviatorGame: React.FC<AviatorGameProps> = ({ user, setUser, addNotification, onBack, onDepositClick }) => {
  const [gameState, setGameState] = useState<'waiting' | 'flying' | 'crashed'>('waiting');
  const [multiplier, setMultiplier] = useState(1.0);
  const [countdown, setCountdown] = useState(10);
  const [userBetAmount, setUserBetAmount] = useState<number>(10);
  const [isUserInGame, setIsUserInGame] = useState(false);
  // Changed history to an empty array initially; it will be filled with time-based data
  const [history, setHistory] = useState<number[]>([]);
  const [liveBets, setLiveBets] = useState<AviatorBet[]>([]);
  const [userHistory, setUserHistory] = useState<UserAviatorHistory[]>([]);
  const [listTab, setListTab] = useState<'all' | 'history'>('all');
  const [isSoundOn, setIsSoundOn] = useState(true);
  const [isBlasting, setIsBlasting] = useState(false);
  const [betTab, setBetTab] = useState<'bet' | 'auto'>('bet');
  const [playerCount, setPlayerCount] = useState(11768);
  
  const multiplierInterval = useRef<any>(null);
  const countdownInterval = useRef<any>(null);
  const crashPoint = useRef<number>(1.0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const startTime = useRef<number>(0);
  const isUserInGameRef = useRef(false);

  // Helper to generate a deterministic result based on a timestamp (Mobile Time)
  const generateTimeSeededResult = (ts: number) => {
    // Basic PRNG using sine of timestamp
    const x = Math.sin(ts) * 10000;
    const rand = x - Math.floor(x);
    
    // Aviator-style distribution
    if (rand < 0.40) return 1.01 + rand * 0.99; // 40% Low (1.01x - 2.0x)
    if (rand < 0.70) return 2.0 + rand * 3.0;   // 30% Medium (2.0x - 5.0x)
    if (rand < 0.90) return 5.0 + rand * 15.0;  // 20% High (5.0x - 20.0x)
    return 20.0 + rand * 180.0;                 // 10% Super High (20.0x+)
  };

  useEffect(() => {
    isUserInGameRef.current = isUserInGame;
  }, [isUserInGame]);

  useEffect(() => {
    audioRef.current = new Audio('https://www.soundjay.com/transportation/airplane-engine-1.mp3');
    audioRef.current.loop = true;
    
    // Initialize History based on current Mobile Time
    const now = Date.now();
    const initialHistory: number[] = [];
    // Generate 15 conceptual "previous rounds" based on time
    // Assuming each round takes roughly 30 seconds
    for (let i = 1; i <= 15; i++) {
      const pastTime = now - (i * 30000);
      initialHistory.push(generateTimeSeededResult(pastTime));
    }
    setHistory(initialHistory);

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      if (gameState === 'flying' && isSoundOn) {
        audioRef.current.play().catch(() => {});
      } else {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    }
  }, [gameState, isSoundOn]);

  const generateFakeBets = () => {
    const names = ['a***i', '1***1', 'a***r', 'p***a', 'v***0', 'l***6', '3***3', 'n***a', 'm***x', 'k***8'];
    return names.map(name => ({
      id: Math.random().toString(),
      user: name,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
      amount: Math.floor(Math.random() * 5000) + 100,
      status: 'pending' as const
    }));
  };

  useEffect(() => {
    setLiveBets(generateFakeBets());
    setPlayerCount(Math.floor(Math.random() * (14000 - 10000 + 1)) + 10000);
  }, []);

  const startNewRound = () => {
    setGameState('waiting');
    setMultiplier(1.0);
    setCountdown(10);
    setIsUserInGame(false);
    setIsBlasting(false);
    setLiveBets(generateFakeBets());
    setPlayerCount(Math.floor(Math.random() * (14000 - 10000 + 1)) + 10000);

    countdownInterval.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countdownInterval.current);
          launchIndicator();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const launchIndicator = () => {
    setGameState('flying');
    
    // Instead of completely random, we can also seed the live crash point with time for consistency
    crashPoint.current = generateTimeSeededResult(Date.now());
    crashPoint.current = Math.min(crashPoint.current, 1000.0);
    
    startTime.current = Date.now();

    multiplierInterval.current = setInterval(() => {
      const elapsed = (Date.now() - startTime.current) / 1000;
      
      let currentMult = 1.0;
      // Growth curve logic
      const t1 = 1.0 / 0.15; 
      const t2 = t1 + 5.0;    
      const t3 = t2 + 4.0;    
      const t4 = t3 + 3.0;    
      const t10 = t4 + (5.0 * 3.0); 

      if (elapsed <= t1) {
        currentMult = 1.0 + (elapsed * 0.15);
      } else if (elapsed <= t2) {
        currentMult = 2.0 + ((elapsed - t1) / 5.0);
      } else if (elapsed <= t3) {
        currentMult = 3.0 + ((elapsed - t2) / 4.0);
      } else if (elapsed <= t4) {
        currentMult = 4.0 + ((elapsed - t3) / 3.0);
      } else if (elapsed <= t10) {
        currentMult = 5.0 + ((elapsed - t4) / 3.0);
      } else {
        currentMult = 10.0 + ((elapsed - t10) / 2.0);
      }
      
      if (currentMult >= crashPoint.current) {
        handleCrash(crashPoint.current);
      } else {
        setMultiplier(parseFloat(currentMult.toFixed(2)));
        
        setLiveBets(prev => prev.map(bet => {
          if (!bet.isLocalUser && bet.status === 'pending' && Math.random() > 0.99) {
            return {
              ...bet,
              status: 'cashed-out',
              multiplier: currentMult,
              winAmount: bet.amount * currentMult
            };
          }
          return bet;
        }));
      }
    }, 40);
  };

  const handleCrash = (finalMult: number) => {
    clearInterval(multiplierInterval.current);
    setIsBlasting(true); 
    setMultiplier(finalMult);
    
    if (isUserInGameRef.current) {
      const historyItem: UserAviatorHistory = {
        id: Math.random().toString(36).substr(2, 5),
        amount: userBetAmount,
        status: 'loss',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setUserHistory(prev => [historyItem, ...prev].slice(0, 50));
    }

    setTimeout(() => {
      setGameState('crashed');
      setHistory(prev => [finalMult, ...prev].slice(0, 15));
      
      setLiveBets(prev => prev.map(bet => {
          if (bet.status === 'pending') return { ...bet, status: 'lost' };
          return bet;
      }));

      setTimeout(startNewRound, 4000);
    }, 600);
  };

  const placeBet = () => {
    if (gameState !== 'waiting') return;
    if (user.balance < userBetAmount) {
      addNotification("ব্যালেন্স নেই!", "error");
      return;
    }
    
    setUser(prev => {
      if (!prev) return null;
      return { 
        ...prev, 
        balance: prev.balance - userBetAmount,
        totalTurnover: (prev.totalTurnover || 0) + userBetAmount 
      };
    });
    
    setIsUserInGame(true);
    
    const localBet: AviatorBet = {
      id: 'local_user',
      user: 'You',
      avatar: user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`,
      amount: userBetAmount,
      status: 'pending',
      isLocalUser: true
    };
    
    setLiveBets(prev => [localBet, ...prev]);
    addNotification("বেট ধরা হয়েছে", "success");
  };

  const cashOut = () => {
    if (gameState !== 'flying' || !isUserInGame || isBlasting) return;
    const winAmt = userBetAmount * multiplier;
    setUser(prev => prev ? { ...prev, balance: prev.balance + winAmt } : null);
    setIsUserInGame(false);
    
    const historyItem: UserAviatorHistory = {
      id: Math.random().toString(36).substr(2, 5),
      amount: userBetAmount,
      multiplier: multiplier,
      winAmount: winAmt,
      status: 'win',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setUserHistory(prev => [historyItem, ...prev].slice(0, 50));

    setLiveBets(prev => prev.map(bet => {
      if (bet.isLocalUser) {
        return { ...bet, status: 'cashed-out', multiplier, winAmount: winAmt };
      }
      return bet;
    }));
    
    addNotification(`আপনি জিতেছেন! ৳${winAmt.toFixed(2)}`, 'success');
  };

  useEffect(() => {
    startNewRound();
    return () => {
      clearInterval(multiplierInterval.current);
      clearInterval(countdownInterval.current);
    };
  }, []);

  const progress = Math.min(1, (multiplier - 1) / 50); 
  const indicatorX = progress * 72; 
  const indicatorY = Math.pow(progress, 1.3) * 52;

  return (
    <div className="fixed inset-0 bg-[#000000] text-white flex flex-col font-sans select-none overflow-hidden z-[100]">
      <div className="p-3 flex items-center justify-between border-b border-white/5 bg-[#1b1c1d] z-[60]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1 hover:bg-white/5 rounded-full active:scale-90 transition-transform">
            <ChevronLeft size={20} />
          </button>
          <span className="text-[#dc2626] font-black italic text-base tracking-tighter uppercase">Aviator</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-[#141516] px-2.5 py-1 rounded-full flex items-center gap-2 border border-white/10 shadow-inner">
            <span className="text-green-500 font-black text-[11px]">{user.balance.toFixed(2)} <span className="text-[7px] opacity-60 font-medium uppercase">BDT</span></span>
            <button onClick={onDepositClick} className="w-4 h-4 bg-amber-500 rounded-full flex items-center justify-center text-black font-bold text-[8px] shadow-lg">+</button>
          </div>
          <button onClick={() => setIsSoundOn(!isSoundOn)} className="text-gray-400 hover:text-white transition-colors">
            {isSoundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
          <button className="text-gray-400 hover:text-white"><MoreHorizontal size={16} /></button>
        </div>
      </div>

      <div className="flex items-center gap-1.5 px-3 py-1 bg-[#1b1c1d] overflow-x-auto no-scrollbar border-b border-white/5 z-50 min-h-[32px]">
        {history.length === 0 ? (
          <div className="flex-1 text-[8px] font-black text-gray-700 uppercase tracking-widest text-center animate-pulse">Syncing Round History...</div>
        ) : (
          history.map((h, i) => (
            <div key={i} className={`flex-shrink-0 px-2 py-0.5 rounded-full text-[9px] font-black border border-white/5 shadow-sm transition-all animate-in fade-in slide-in-from-right-2 duration-500 ${
              h >= 10 ? 'bg-purple-600/20 text-purple-500 border-purple-500/30' :
              h >= 2 ? 'bg-blue-600/20 text-blue-400 border-blue-400/30' :
              'bg-gray-700/40 text-gray-500'
            }`}>
              {h.toFixed(2)}x
            </div>
          ))
        )}
        {history.length > 0 && <button className="ml-auto text-gray-600 hover:text-white pl-2"><HistoryIcon size={12} /></button>}
      </div>

      <div className="relative flex-[1.2] bg-gradient-to-b from-[#020617] via-[#111827] to-[#000000] m-2 rounded-[1.25rem] border border-white/10 overflow-hidden flex flex-col items-center justify-center shadow-2xl">
        <div className="absolute inset-0 z-0 pointer-events-none opacity-40">
           {[...Array(30)].map((_, i) => (
             <div 
               key={i} 
               className="absolute bg-white/50 rounded-full animate-[rising_linear_infinite]"
               style={{
                 width: Math.random() * 2 + 'px',
                 height: Math.random() * 2 + 'px',
                 left: Math.random() * 100 + '%',
                 bottom: '-10%',
                 animationDuration: (Math.random() * 2 + 1) + 's',
                 animationDelay: Math.random() * 3 + 's'
               }}
             />
           ))}
           <div className="absolute top-10 left-10 opacity-10"><Cloud size={48} className="text-white animate-pulse" /></div>
           <div className="absolute top-[60%] right-[15%] opacity-10"><Cloud size={36} className="text-white animate-pulse" /></div>
        </div>

        {gameState === 'flying' && (
          <div className="absolute inset-0 pointer-events-none z-1">
             <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
               <path 
                 d={`M 0 100 Q 15 100, ${15 + indicatorX} ${94 - indicatorY} L ${15 + indicatorX} 100 Z`}
                 fill="rgba(220, 38, 38, 0.4)" 
                 className="transition-all duration-[40ms] ease-linear"
               />
               <path 
                 d={`M 0 100 Q 15 100, ${15 + indicatorX} ${94 - indicatorY}`}
                 stroke="#ef4444"
                 strokeWidth="2.5"
                 fill="none"
                 className="transition-all duration-[40ms] ease-linear"
               />
             </svg>
          </div>
        )}

        <div className="z-10 text-center w-full h-full flex flex-col items-center justify-center">
          {gameState === 'waiting' ? (
            <div className="flex flex-col items-center animate-in fade-in zoom-in duration-300">
               <div className="relative w-24 h-24 flex items-center justify-center">
                  <div className="absolute inset-0 border-[4px] border-amber-500/10 rounded-full"></div>
                  <div className="absolute inset-0 border-[4px] border-amber-500 rounded-full border-t-transparent animate-spin" style={{ animationDuration: '4s' }}></div>
                  <span className="text-4xl font-black text-amber-500 tabular-nums">{countdown}</span>
               </div>
               <p className="mt-2 text-[8px] font-black text-gray-500 uppercase tracking-[0.2em] opacity-80">Next round in</p>
            </div>
          ) : gameState === 'flying' ? (
            <div className="relative w-full h-full">
               <div className="absolute top-[38%] w-full text-center z-10 px-4">
                 <span className={`text-[68px] leading-none font-black tabular-nums transition-all drop-shadow-[0_0_20px_rgba(0,0,0,1)] ${multiplier >= 10 ? 'text-purple-500' : (multiplier >= 2 ? 'text-blue-500' : 'text-white')}`}>
                   {multiplier.toFixed(2)}x
                 </span>
               </div>
               
               <div 
                 className={`absolute bottom-[6%] left-[12%] transition-all duration-[40ms] ease-linear z-20 flex items-center justify-center`} 
                 style={{ transform: `translate(${indicatorX}vw, -${indicatorY}vh)` }}
               >
                 <div className={`relative w-8 h-8 bg-[#dc2626] rounded-full shadow-[0_4px_15px_rgba(220,38,38,0.7)] border-[3px] border-white/20 flex items-center justify-center transition-all ${isBlasting ? 'scale-[8] opacity-0 duration-500' : 'scale-100'}`}>
                    <Zap className="text-white fill-white" size={12} />
                    <div className="absolute inset-0 rounded-full border border-white/20 animate-ping"></div>
                 </div>
               </div>
            </div>
          ) : (
            <div className="flex flex-col items-center animate-in zoom-in duration-500 w-full px-6">
               <div className="bg-[#1b1c1d]/95 backdrop-blur-md px-12 py-6 rounded-[2.5rem] border-2 border-white/5 shadow-2xl">
                 <span className="text-6xl font-black text-white tabular-nums tracking-tighter leading-none">{multiplier.toFixed(2)}x</span>
               </div>
               <p className="mt-8 text-[8px] font-black text-gray-700 uppercase tracking-widest opacity-40">WAITING FOR NEXT ROUND...</p>
            </div>
          )}
        </div>

        <div className="absolute bottom-5 right-5 flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1 rounded-lg border border-white/10 z-30">
           <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
           <span className="text-[11px] font-black text-white leading-none tabular-nums tracking-tight">{playerCount}</span>
        </div>
      </div>

      <div className="px-4 py-3 bg-[#141516] border-t border-white/10 shadow-inner">
        <div className="flex bg-[#1b1c1d] rounded-2xl p-0.5 gap-0.5 border border-white/5 shadow-inner mb-3">
           <button onClick={() => setBetTab('bet')} className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase transition-all tracking-widest ${betTab === 'bet' ? 'bg-[#2c2d2e] text-white shadow-lg' : 'text-gray-500'}`}>Bet</button>
           <button onClick={() => setBetTab('auto')} className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase transition-all tracking-widest ${betTab === 'auto' ? 'bg-[#2c2d2e] text-white shadow-lg' : 'text-gray-500'}`}>Auto</button>
        </div>

        <div className="flex gap-3 items-stretch h-24">
           <div className="flex-[1.2] flex flex-col justify-between py-0.5">
              <div className="flex items-center justify-between bg-[#1b1c1d] p-1 rounded-xl border border-white/5">
                 <button onClick={() => setUserBetAmount(p => Math.max(1, p - 1))} className="w-8 h-8 bg-[#2c2d2e] rounded-lg flex items-center justify-center text-gray-400 active:scale-90 transition-transform"><Minus size={16} strokeWidth={3} /></button>
                 <input type="number" value={userBetAmount} onChange={e => setUserBetAmount(parseFloat(e.target.value) || 0)} className="w-full bg-transparent text-center font-black text-xl outline-none tabular-nums text-white" />
                 <button onClick={() => setUserBetAmount(p => p + 1)} className="w-8 h-8 bg-[#2c2d2e] rounded-lg flex items-center justify-center text-gray-400 active:scale-90 transition-transform"><Plus size={16} strokeWidth={3} /></button>
              </div>
              <div className="grid grid-cols-3 gap-2">
                 {[10, 100, 500].map(val => (
                   <button key={val} onClick={() => setUserBetAmount(val)} className="py-2 bg-[#1b1c1d] rounded-lg text-[9px] font-black text-gray-500 border border-white/5 active:scale-95 transition-all shadow-sm hover:text-white">{val}</button>
                 ))}
              </div>
           </div>
           
           <div className="flex-1">
              {isUserInGame ? (
                <button onClick={cashOut} disabled={gameState !== 'flying' || isBlasting} className={`w-full h-full rounded-2xl flex flex-col items-center justify-center gap-1 shadow-xl transition-all active:scale-95 border-b-4 ${gameState === 'flying' && !isBlasting ? 'bg-amber-500 border-amber-700 shadow-amber-500/30' : 'bg-gray-700 border-gray-900 opacity-50 cursor-not-allowed'}`}>
                  <span className="text-[10px] font-black uppercase text-amber-900 leading-none tracking-widest">Cash Out</span>
                  <p className="text-xl font-black text-black tabular-nums leading-none">{(userBetAmount * multiplier).toFixed(2)}</p>
                </button>
              ) : (
                <button onClick={placeBet} disabled={gameState !== 'waiting'} className={`w-full h-full rounded-2xl flex flex-col items-center justify-center gap-1 shadow-xl transition-all active:scale-95 border-b-4 ${gameState === 'waiting' ? 'bg-[#22c55e] border-[#15803d] shadow-green-500/20' : 'bg-gray-700 border-gray-900 opacity-50 cursor-not-allowed'}`}>
                  <span className="text-[10px] font-black uppercase text-green-100 leading-none tracking-widest">Place Bet</span>
                  <p className="text-2xl font-black text-white tabular-nums leading-none">{userBetAmount.toFixed(0)}</p>
                </button>
              )}
           </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col bg-[#141516] overflow-hidden">
        <div className="flex px-4 py-2 bg-[#1b1c1d] border-y border-white/5 items-center justify-between z-10">
           <div className="flex gap-8">
              <button 
                onClick={() => setListTab('all')}
                className={`text-[10px] font-black uppercase tracking-widest pb-1.5 transition-all ${listTab === 'all' ? 'text-white border-b-2 border-red-600' : 'text-gray-500 hover:text-gray-300'}`}
              >
                All Bets
              </button>
              <button 
                onClick={() => setListTab('history')}
                className={`text-[10px] font-black uppercase tracking-widest pb-1.5 transition-all ${listTab === 'history' ? 'text-white border-b-2 border-red-600' : 'text-gray-500 hover:text-gray-300'}`}
              >
                History
              </button>
           </div>
           <div className="flex items-center gap-1.5 px-2.5 py-1 bg-green-500/10 rounded-full border border-green-500/20 shadow-sm">
              <ShieldCheck size={11} className="text-green-500" />
              <span className="text-[7.5px] font-black text-green-500 uppercase tracking-tighter">Verified</span>
           </div>
        </div>
        
        <div className="flex-1 overflow-y-auto no-scrollbar px-2 divide-y divide-white/5 bg-[#141516] relative min-h-[150px]">
           {listTab === 'all' ? (
             liveBets.map((bet) => (
               <div key={bet.id} className={`grid grid-cols-4 px-4 py-3 items-center transition-all ${bet.status === 'cashed-out' ? 'bg-green-500/10 border-l-2 border-green-500' : ''} ${bet.isLocalUser ? 'bg-indigo-600/15 border-l-2 border-indigo-500 shadow-inner' : ''}`}>
                  <div className="flex items-center gap-2.5 overflow-hidden">
                     <div className="w-7 h-7 rounded-full border border-white/10 overflow-hidden flex-shrink-0">
                        <img src={bet.avatar} className="w-full h-full object-cover" alt="av" />
                     </div>
                     <span className={`text-[10.5px] font-bold truncate tracking-tight ${bet.isLocalUser ? 'text-indigo-400' : 'text-gray-500'}`}>{bet.user}</span>
                  </div>
                  <div className="text-center text-[10.5px] font-black text-gray-400 tabular-nums">৳{bet.amount.toFixed(0)}</div>
                  <div className="text-center">
                     {bet.status === 'cashed-out' ? (
                       <span className="text-[9px] font-black text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-lg border border-blue-500/10 transition-all">{bet.multiplier?.toFixed(2)}x</span>
                     ) : <span className="text-gray-800 font-bold text-[10px]">-</span>}
                  </div>
                  <div className="text-right text-[11px] font-black text-green-500 tabular-nums">
                     {bet.status === 'cashed-out' ? `৳${bet.winAmount?.toFixed(0)}` : ''}
                  </div>
               </div>
             ))
           ) : (
             userHistory.length === 0 ? (
               <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-10 opacity-40">
                  <RotateCcw size={40} strokeWidth={1} className="mb-3 text-gray-400" />
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500">No game history yet</p>
               </div>
             ) : (
               userHistory.map((item) => (
                 <div key={item.id} className={`grid grid-cols-4 px-4 py-3 items-center border-l-2 transition-all ${item.status === 'win' ? 'border-green-500 bg-green-500/5' : 'border-rose-500 bg-rose-500/5'}`}>
                    <div className="text-[10px] font-black text-gray-500 uppercase tracking-tighter tabular-nums">{item.time}</div>
                    <div className="text-center text-[10.5px] font-black text-gray-400 tabular-nums">৳{item.amount.toFixed(2)}</div>
                    <div className="text-center">
                       {item.status === 'win' ? (
                         <span className="text-[9px] font-black text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-lg border border-blue-500/10">{item.multiplier?.toFixed(2)}x</span>
                       ) : <span className="text-rose-500 font-black text-[9px] uppercase tracking-widest px-2 py-0.5 bg-rose-500/10 rounded-lg">LOSS</span>}
                    </div>
                    <div className={`text-right text-[11px] font-black tabular-nums ${item.status === 'win' ? 'text-green-500' : 'text-rose-500/50'}`}>
                       {item.status === 'win' ? `+৳${item.winAmount?.toFixed(2)}` : `-৳${item.amount.toFixed(2)}`}
                    </div>
                 </div>
               ))
             )}
           <div className="h-20 w-full"></div>
        </div>
      </div>

      <style>{`
        @keyframes rising {
          from { transform: translateY(0); opacity: 0; }
          15% { opacity: 0.8; }
          85% { opacity: 0.8; }
          to { transform: translateY(-1200%); opacity: 0; }
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default AviatorGame;
