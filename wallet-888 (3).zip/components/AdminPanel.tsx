import React, { useState, useMemo } from 'react';
import { User, Transaction, AppSettings, BonusCode, UserMessage } from '../types';
import { 
  Users, Download, Upload, Settings, Search, 
  Copy, Smartphone, Zap, LayoutDashboard, Ticket, Trash2, Plus, MessageCircle, Phone, DownloadCloud, Globe, Wallet, LayoutGrid, CheckCircle2, Lock, Eye, EyeOff, Minus, ShieldCheck, UserMinus, UserPlus, PlayCircle, History as HistoryIcon,
  Ban, ExternalLink, Image as ImageIcon
} from 'lucide-react';

interface AdminPanelProps {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  bonusCodes: BonusCode[];
  setBonusCodes: React.Dispatch<React.SetStateAction<BonusCode[]>>;
  addNotification: (msg: string, type?: any) => void;
  addUserMessage: (uid: string, title: string, content: string, type?: any) => void;
  onBack: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  users, setUsers, transactions, setTransactions, settings, setSettings, bonusCodes, setBonusCodes, addNotification, addUserMessage, onBack 
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<'dashboard' | 'users' | 'deposits' | 'withdrawals' | 'settings' | 'bonus'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPasswords, setShowPasswords] = useState<{ [key: string]: boolean }>({});
  const [balanceAdjustments, setBalanceAdjustments] = useState<{ [key: string]: string }>({});
  
  const [newCode, setNewCode] = useState('');
  const [newReward, setNewReward] = useState('');
  const [newMaxUses, setNewMaxUses] = useState('');

  const stats = useMemo(() => {
    const today = new Date().toLocaleDateString();
    const todayDeposits = transactions.filter(t => t.type === 'deposit' && t.status === 'success' && t.date.includes(today)).reduce((a, b) => a + b.amount, 0);
    const todayWithdrawals = transactions.filter(t => t.type === 'withdraw' && t.status === 'success' && t.date.includes(today)).reduce((a, b) => a + b.amount, 0);
    const pendingDeposits = transactions.filter(t => t.type === 'deposit' && t.status === 'pending').length;
    const pendingWithdrawals = transactions.filter(t => t.type === 'withdraw' && t.status === 'pending').length;

    return { totalUsers: users.length, todayDeposits, todayWithdrawals, pendingDeposits, pendingWithdrawals };
  }, [users, transactions]);

  const calculateRegPercent = (u: User) => {
    const fields = ['firstName', 'lastName', 'nid', 'dob', 'avatarUrl', 'boundBkash', 'boundNagad', 'boundBinance'];
    const filled = fields.filter(f => !!(u as any)[f]).length;
    return Math.round((filled / fields.length) * 100);
  };

  const filteredUsers = users.filter(u => 
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.uid.includes(searchQuery) || 
    u.phone.includes(searchQuery)
  );

  const togglePassword = (userId: string) => {
    setShowPasswords(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  const handleBalanceUpdate = (userId: string, action: 'add' | 'subtract') => {
    const amtStr = balanceAdjustments[userId];
    const amount = parseFloat(amtStr);
    if (isNaN(amount) || amount <= 0) {
      addNotification("সঠিক পরিমাণ দিন", "error");
      return;
    }

    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const newBalance = action === 'add' ? u.balance + amount : Math.max(0, u.balance - amount);
        addNotification(`৳${amount} ${action === 'add' ? 'যোগ' : 'বিয়োগ'} করা হয়েছে`, "success");
        return { ...u, balance: newBalance };
      }
      return u;
    }));
    setBalanceAdjustments(prev => ({ ...prev, [userId]: '' }));
  };

  const handleDemoToggle = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const isNowDemo = !u.isDemo;
        addNotification(isNowDemo ? "একাউন্ট ডেমো করা হয়েছে" : "ডেমো মোড বন্ধ করা হয়েছে", "info");
        return { ...u, isDemo: isNowDemo };
      }
      return u;
    }));
  };

  const handleAction = (txId: string, action: 'approve' | 'reject') => {
    setTransactions(prev => prev.map(t => {
      if (t.id === txId) {
        const newStatus = action === 'approve' ? 'success' : 'failed';
        if (action === 'approve') {
          setUsers(uList => uList.map(u => {
            if (u.uid === t.uid) {
              if (t.type === 'deposit') {
                return { ...u, balance: u.balance + t.amount, totalDeposits: (u.totalDeposits || 0) + t.amount };
              } else if (t.type === 'withdraw') {
                return { ...u, balance: Math.max(0, u.balance - t.amount) };
              }
            }
            return u;
          }));
          addUserMessage(t.uid, t.type === 'deposit' ? "ডিপোজিট সফল" : "উত্তোলন সফল", `আপনার ৳${t.amount} ${t.type === 'deposit' ? 'ডিপোজিট' : 'উত্তোলন'} সফল হয়েছে।`, 'success');
        } else {
          addUserMessage(t.uid, t.type === 'deposit' ? "ডিপোজিট বাতিল" : "উত্তোলন বাতিল", `আপনার ৳${t.amount} ${t.type === 'deposit' ? 'ডিপোজিট' : 'উত্তোলন'} রিকোয়েস্টটি বাতিল করা হয়েছে।`, 'error');
        }
        return { ...t, status: newStatus as any };
      }
      return t;
    }));
    addNotification(action === 'approve' ? 'অনুমোদন সফল' : 'বাতিল করা হয়েছে', action === 'approve' ? 'success' : 'info');
  };

  const handleBlockUser = (uId: string) => {
    setUsers(prev => prev.map(u => u.id === uId ? { ...u, isBlocked: !u.isBlocked } : u));
    addNotification("ইউজার স্ট্যাটাস পরিবর্তন হয়েছে", "success");
  };

  const handleCreateCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode || !newReward || !newMaxUses) return;
    const nCode: BonusCode = {
      id: Math.random().toString(36).substr(2, 9),
      code: newCode.toUpperCase(),
      reward: parseFloat(newReward),
      maxUses: parseInt(newMaxUses),
      currentUses: 0
    };
    setBonusCodes(prev => [...prev, nCode]);
    setNewCode(''); setNewReward(''); setNewMaxUses('');
    addNotification("বোনাস কোড তৈরি হয়েছে!", "success");
  };

  const adminTabs = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Stat' },
    { id: 'users', icon: Users, label: 'Users' },
    { id: 'deposits', icon: Download, label: 'Depo' },
    { id: 'withdrawals', icon: Upload, label: 'With' },
    { id: 'bonus', icon: Ticket, label: 'Bonus' },
    { id: 'settings', icon: Settings, label: 'Set' },
  ];

  return (
    <div className="relative min-h-[calc(100vh-120px)] flex flex-col animate-in fade-in slide-in-from-right duration-500 pb-32">
      <div className="flex items-center justify-between px-1 mb-6">
        <h2 className="text-2xl font-black text-red-600 dark:text-red-400 uppercase tracking-tighter">Admin Control</h2>
        <button onClick={onBack} className="px-4 py-1.5 bg-gray-100 dark:bg-gray-800 rounded-full text-[10px] font-black text-gray-400 hover:text-red-500 uppercase tracking-widest transition-colors">Exit</button>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-3xl border-b-4 border-indigo-500 shadow-xl text-center active:scale-95 transition-all cursor-pointer" onClick={() => setActiveAdminTab('users')}>
          <div className="w-8 h-8 bg-indigo-50 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mx-auto mb-2 text-indigo-500"><Users size={16} /></div>
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Users</p>
          <p className="text-lg font-black dark:text-white">{stats.totalUsers}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-3xl border-b-4 border-green-500 shadow-xl text-center active:scale-95 transition-all cursor-pointer" onClick={() => setActiveAdminTab('deposits')}>
          <div className="w-8 h-8 bg-green-50 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-2 text-green-500"><Download size={16} /></div>
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Deposits</p>
          <p className="text-lg font-black dark:text-white">{stats.pendingDeposits}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-3xl border-b-4 border-rose-500 shadow-xl text-center active:scale-95 transition-all cursor-pointer" onClick={() => setActiveAdminTab('withdrawals')}>
          <div className="w-8 h-8 bg-rose-50 dark:bg-rose-900/30 rounded-full flex items-center justify-center mx-auto mb-2 text-rose-500"><Upload size={16} /></div>
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Payouts</p>
          <p className="text-lg font-black dark:text-white">{stats.pendingWithdrawals}</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {activeAdminTab === 'dashboard' && (
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-red-600 to-red-800 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-6 opacity-70">Financial Pulse</p>
              <div className="grid grid-cols-1 gap-6">
                <div className="bg-white/10 p-5 rounded-3xl border border-white/10 backdrop-blur-md">
                  <span className="text-[9px] font-bold text-red-100 uppercase block mb-1">Today's Deposit</span>
                  <span className="text-3xl font-black">৳ {stats.todayDeposits.toLocaleString()}</span>
                </div>
                <div className="bg-white/10 p-5 rounded-3xl border border-white/10 backdrop-blur-md">
                  <span className="text-[9px] font-bold text-red-100 uppercase block mb-1">Today's Payout</span>
                  <span className="text-3xl font-black">৳ {stats.todayWithdrawals.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeAdminTab === 'users' && (
          <div className="space-y-4 px-1">
            <div className="relative mb-6">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input 
                type="text" 
                placeholder="Search Gmail or UID..." 
                value={searchQuery} 
                onChange={e => setSearchQuery(e.target.value)} 
                className="w-full pl-14 pr-6 py-5 rounded-[1.8rem] bg-white dark:bg-gray-800 dark:text-white border border-gray-100 dark:border-gray-700 outline-none focus:ring-2 focus:ring-red-500 font-bold shadow-sm" 
              />
            </div>

            {filteredUsers.length === 0 ? (
              <div className="py-20 text-center text-gray-400 font-bold italic bg-white dark:bg-gray-800 rounded-[2.5rem]">No users found matching search</div>
            ) : (
              filteredUsers.map(u => (
                <div key={u.id} className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] border border-gray-100 dark:border-gray-700 shadow-lg space-y-6 relative overflow-hidden transition-all hover:border-red-500/30">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <img src={u.avatarUrl || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${u.uid}`} className="w-16 h-16 rounded-2xl bg-gray-50 border-2 border-gray-100 dark:border-gray-700 shadow-md" alt="av" />
                        {u.isDemo && <div className="absolute -top-2 -right-2 bg-amber-500 text-white p-1 rounded-full border-2 border-white shadow-lg"><PlayCircle size={14} /></div>}
                      </div>
                      <div>
                        <p className="text-sm font-black dark:text-white uppercase truncate max-w-[180px]">{u.email || u.phone}</p>
                        <p className="text-[10px] font-bold text-indigo-500 flex items-center gap-1 mt-0.5">UID: {u.uid} <Copy size={10} className="cursor-pointer" onClick={() => {navigator.clipboard.writeText(u.uid); addNotification("UID Copied", "info")}}/></p>
                        <div className="flex items-center gap-2 mt-2">
                           {u.isBlocked ? (
                             <span className="bg-red-50 text-red-500 text-[8px] font-black px-2 py-0.5 rounded-full border border-red-100 uppercase tracking-widest">Blocked</span>
                           ) : (
                             <span className="bg-green-50 text-green-500 text-[8px] font-black px-2 py-0.5 rounded-full border border-green-100 uppercase tracking-widest">Active</span>
                           )}
                           {u.isDemo && <span className="bg-amber-50 text-amber-600 text-[8px] font-black px-2 py-0.5 rounded-full border border-amber-100 uppercase tracking-widest">Demo Account</span>}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                       <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Balance</p>
                       <p className="text-xl font-black text-green-600">৳{u.balance.toFixed(0)}</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-2xl flex items-center justify-between border border-gray-100 dark:border-gray-700 shadow-inner">
                    <div className="flex flex-col">
                      <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-0.5">Sensitive: Password</span>
                      <p className="text-sm font-mono font-bold dark:text-white">
                        {showPasswords[u.id] ? u.password : '••••••••'}
                      </p>
                    </div>
                    <button onClick={() => togglePassword(u.id)} className="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
                      {showPasswords[u.id] ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-1">Adjust Wallet Balance</label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                         <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">৳</span>
                         <input 
                           type="number" 
                           placeholder="Amount" 
                           value={balanceAdjustments[u.id] || ''} 
                           onChange={e => setBalanceAdjustments(prev => ({ ...prev, [u.id]: e.target.value }))}
                           className="w-full pl-8 pr-4 py-3.5 bg-[#f8faff] dark:bg-gray-700 rounded-2xl outline-none font-bold text-sm border-2 border-transparent focus:border-indigo-500 transition-all"
                         />
                      </div>
                      <button onClick={() => handleBalanceUpdate(u.id, 'add')} className="p-3 bg-green-500 text-white rounded-2xl shadow-lg active:scale-90 transition-transform"><Plus size={20} /></button>
                      <button onClick={() => handleBalanceUpdate(u.id, 'subtract')} className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg active:scale-90 transition-transform"><Minus size={20} /></button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                     <button 
                       onClick={() => handleBlockUser(u.id)} 
                       className={`flex flex-col items-center justify-center gap-1.5 py-4 rounded-[1.5rem] border transition-all active:scale-95 ${u.isBlocked ? 'bg-black border-black text-white' : 'bg-white dark:bg-gray-700 border-gray-100 dark:border-gray-600 text-gray-600 dark:text-gray-300'}`}
                     >
                       <Ban size={18} />
                       <span className="text-[8px] font-black uppercase tracking-widest">{u.isBlocked ? 'Unblock' : 'Block User'}</span>
                     </button>

                     <button 
                       onClick={() => handleDemoToggle(u.id)} 
                       className={`flex flex-col items-center justify-center gap-1.5 py-4 rounded-[1.5rem] border transition-all active:scale-95 ${u.isDemo ? 'bg-amber-500 border-amber-500 text-white shadow-lg' : 'bg-white dark:bg-gray-700 border-gray-100 dark:border-gray-600 text-gray-600 dark:text-gray-300'}`}
                     >
                       <PlayCircle size={18} />
                       <span className="text-[8px] font-black uppercase tracking-widest">{u.isDemo ? 'Live Mode' : 'Make Demo'}</span>
                     </button>

                     <button 
                       className="flex flex-col items-center justify-center gap-1.5 py-4 rounded-[1.5rem] border border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300 transition-all active:scale-95"
                     >
                       <HistoryIcon size={18} />
                       <span className="text-[8px] font-black uppercase tracking-widest">History</span>
                     </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeAdminTab === 'deposits' && (
          <div className="space-y-4">
            {transactions.filter(t => t.type === 'deposit').reverse().map(t => (
              <div key={t.id} className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] border border-gray-100 dark:border-gray-700 shadow-xl overflow-hidden">
                 <div className="flex justify-between items-start mb-6">
                    <div>
                      <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{t.method} DEPOSIT</span>
                      <h3 className="text-3xl font-black dark:text-white mt-1">৳ {t.amount}</h3>
                      <p className="text-[10px] text-gray-400 font-bold mt-1">UID: {t.uid}</p>
                    </div>
                    <span className={`text-[9px] font-black uppercase px-4 py-1.5 rounded-full border ${t.status === 'success' ? 'bg-green-50 border-green-200 text-green-600' : t.status === 'failed' ? 'bg-red-50 border-red-200 text-red-600' : 'bg-amber-50 border-amber-200 text-amber-600'}`}>{t.status}</span>
                 </div>
                 {t.status === 'pending' && (
                   <div className="flex gap-4">
                      <button onClick={() => handleAction(t.id, 'reject')} className="flex-1 py-5 bg-gray-50 text-gray-400 rounded-2xl font-black text-[11px] uppercase">Reject</button>
                      <button onClick={() => handleAction(t.id, 'approve')} className="flex-[2] py-5 bg-green-500 text-white rounded-2xl font-black text-[11px] uppercase">Approve</button>
                   </div>
                 )}
              </div>
            ))}
          </div>
        )}

        {activeAdminTab === 'withdrawals' && (
          <div className="space-y-4">
            {transactions.filter(t => t.type === 'withdraw').reverse().map(t => {
              const u = users.find(user => user.uid === t.uid);
              const regPercent = u ? calculateRegPercent(u) : 20;

              return (
                <div key={t.id} className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] border border-gray-100 dark:border-gray-700 shadow-xl relative overflow-hidden animate-in slide-in-from-right duration-500">
                   <div className="flex justify-between items-start mb-6">
                      <div className="flex items-center gap-3">
                         <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${
                            t.method === 'Bkash' ? 'bg-pink-500' : t.method === 'Nagad' ? 'bg-orange-500' : 'bg-amber-500'
                         }`}>
                           {t.method === 'Binance' ? <Wallet className="text-white" size={24} /> : <Smartphone className="text-white" size={24} />}
                         </div>
                         <div>
                            <span className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest leading-none">PAYOUT VIA {t.method}</span>
                            <h3 className="text-3xl font-black dark:text-white mt-1 leading-none">৳ {t.amount}</h3>
                         </div>
                      </div>
                      <span className={`text-[9px] font-black uppercase px-4 py-1.5 rounded-full border ${t.status === 'success' ? 'bg-green-50 border-green-200 text-green-600' : t.status === 'failed' ? 'bg-red-50 border-red-200 text-red-600' : 'bg-amber-50 border-amber-200 text-amber-600'}`}>{t.status}</span>
                   </div>

                   <div className="space-y-4">
                      <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-700/50 p-3 rounded-xl border border-gray-100 dark:border-gray-700">
                         <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Profile Completion</span>
                         <div className="flex items-center gap-2">
                            <div className="w-20 h-1.5 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                               <div className="h-full bg-indigo-500" style={{ width: `${regPercent}%` }}></div>
                            </div>
                            <span className="text-[10px] font-black text-indigo-600">{regPercent}%</span>
                         </div>
                      </div>

                      <div className="bg-rose-50 dark:bg-rose-900/10 p-5 rounded-2xl flex items-center justify-between border border-rose-100 dark:border-rose-900/30">
                         <div className="flex flex-col">
                            <span className="text-[8px] font-black text-rose-400 uppercase tracking-[0.2em] mb-1">Target Account</span>
                            <span className="text-xl font-mono font-black text-rose-600 dark:text-rose-400 truncate">{t.targetAccount || 'N/A'}</span>
                         </div>
                         <button 
                           onClick={() => { navigator.clipboard.writeText(t.targetAccount || ''); addNotification('Copied Account', 'info'); }} 
                           className="p-3 bg-white dark:bg-gray-800 text-rose-600 rounded-xl shadow-md shrink-0 active:scale-90 transition-transform"
                         >
                           <Copy size={20} />
                         </button>
                      </div>
                   </div>

                   {t.status === 'pending' && (
                     <div className="flex gap-4 mt-6">
                        <button onClick={() => handleAction(t.id, 'reject')} className="flex-1 py-5 bg-gray-50 dark:bg-gray-700 text-gray-400 rounded-2xl font-black text-[11px] uppercase active:scale-95 transition-all">Cancel</button>
                        <button onClick={() => handleAction(t.id, 'approve')} className="flex-[2] py-5 bg-rose-600 text-white rounded-2xl font-black text-[11px] uppercase shadow-lg shadow-rose-600/20 active:scale-95 transition-all flex items-center justify-center gap-2">
                           <CheckCircle2 size={16} /> Confirm Paid
                        </button>
                     </div>
                   )}
                   <p className="text-center text-[9px] font-bold text-gray-300 dark:text-gray-600 mt-4 uppercase tracking-widest italic">UID: {t.uid}</p>
                </div>
              );
            })}
          </div>
        )}

        {activeAdminTab === 'settings' && (
          <div className="space-y-10 pb-10 px-1">
             <div className="bg-white dark:bg-gray-800 p-8 rounded-[3rem] border border-gray-100 dark:border-gray-700 shadow-2xl space-y-8 animate-in slide-in-from-bottom-4 duration-700">
                <div className="flex items-center gap-3 text-indigo-600">
                   <Globe size={20} strokeWidth={2.5} />
                   <h4 className="text-[11px] font-black uppercase tracking-[0.25em]">Global Platform Links</h4>
                </div>
                <div className="grid grid-cols-1 gap-5">
                   <div className="space-y-2">
                      <label className="flex items-center gap-2 text-[9px] font-black text-gray-400 uppercase ml-1 tracking-widest"><MessageCircle size={12} className="text-sky-500" /> Telegram Link</label>
                      <input type="text" value={settings.telegramLink} onChange={e => setSettings({...settings, telegramLink: e.target.value})} className="w-full px-5 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl border-2 border-transparent focus:border-indigo-500 outline-none text-[11px] font-bold shadow-inner" placeholder="https://t.me/yourchannel" />
                   </div>
                   <div className="space-y-2">
                      <label className="flex items-center gap-2 text-[9px] font-black text-gray-400 uppercase ml-1 tracking-widest"><Phone size={12} className="text-green-500" /> WhatsApp Link</label>
                      <input type="text" value={settings.whatsappLink} onChange={e => setSettings({...settings, whatsappLink: e.target.value})} className="w-full px-5 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl border-2 border-transparent focus:border-indigo-500 outline-none text-[11px] font-bold shadow-inner" placeholder="https://wa.me/880..." />
                   </div>
                   <div className="space-y-2">
                      <label className="flex items-center gap-2 text-[9px] font-black text-gray-400 uppercase ml-1 tracking-widest"><ExternalLink size={12} className="text-blue-500" /> Web Site Link</label>
                      <input type="text" value={settings.webLink} onChange={e => setSettings({...settings, webLink: e.target.value})} className="w-full px-5 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl border-2 border-transparent focus:border-indigo-500 outline-none text-[11px] font-bold shadow-inner" placeholder="https://wallet888.app" />
                   </div>
                   <div className="space-y-2">
                      <label className="flex items-center gap-2 text-[9px] font-black text-gray-400 uppercase ml-1 tracking-widest"><DownloadCloud size={12} className="text-indigo-500" /> App Download Link</label>
                      <input type="text" value={settings.downloadLink} onChange={e => setSettings({...settings, downloadLink: e.target.value})} className="w-full px-5 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl border-2 border-transparent focus:border-indigo-500 outline-none text-[11px] font-bold shadow-inner" placeholder="https://link-to-your-apk.apk" />
                   </div>
                </div>
             </div>

             {/* bKash Payment Method Config */}
             <div className="bg-white dark:bg-gray-800 p-8 rounded-[3.5rem] border border-gray-100 dark:border-gray-700 shadow-2xl space-y-6">
                <div className="flex items-center gap-3 text-pink-600">
                   <Smartphone size={20} strokeWidth={2.5} />
                   <h4 className="text-[11px] font-black uppercase tracking-[0.25em]">bKash Payment Method</h4>
                </div>
                <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Display Title</label>
                      <input type="text" value={settings.bkashTitle} onChange={e => setSettings({...settings, bkashTitle: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-bold text-sm shadow-inner" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">bKash Number</label>
                      <input type="text" value={settings.bkashNumber} onChange={e => setSettings({...settings, bkashNumber: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-black text-lg shadow-inner" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Payment Instruction</label>
                      <textarea value={settings.bkashInstruction} onChange={e => setSettings({...settings, bkashInstruction: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-xs font-bold shadow-inner min-h-[80px]" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Logo/Image URL</label>
                      <input type="text" value={settings.bkashImg} onChange={e => setSettings({...settings, bkashImg: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-[10px] font-mono shadow-inner" />
                    </div>
                </div>
             </div>

             {/* Nagad Payment Method Config */}
             <div className="bg-white dark:bg-gray-800 p-8 rounded-[3.5rem] border border-gray-100 dark:border-gray-700 shadow-2xl space-y-6">
                <div className="flex items-center gap-3 text-orange-600">
                   <Smartphone size={20} strokeWidth={2.5} />
                   <h4 className="text-[11px] font-black uppercase tracking-[0.25em]">Nagad Payment Method</h4>
                </div>
                <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Display Title</label>
                      <input type="text" value={settings.nagadTitle} onChange={e => setSettings({...settings, nagadTitle: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-bold text-sm shadow-inner" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Nagad Number</label>
                      <input type="text" value={settings.nagadNumber} onChange={e => setSettings({...settings, nagadNumber: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-black text-lg shadow-inner" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Payment Instruction</label>
                      <textarea value={settings.nagadInstruction} onChange={e => setSettings({...settings, nagadInstruction: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-xs font-bold shadow-inner min-h-[80px]" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Logo/Image URL</label>
                      <input type="text" value={settings.nagadImg} onChange={e => setSettings({...settings, nagadImg: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-[10px] font-mono shadow-inner" />
                    </div>
                </div>
             </div>

             {/* Binance Payment Method Config */}
             <div className="bg-white dark:bg-gray-800 p-8 rounded-[3.5rem] border border-gray-100 dark:border-gray-700 shadow-2xl space-y-6">
                <div className="flex items-center gap-3 text-amber-600">
                   <Wallet size={20} strokeWidth={2.5} />
                   <h4 className="text-[11px] font-black uppercase tracking-[0.25em]">Binance Payment Method</h4>
                </div>
                <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Display Title</label>
                      <input type="text" value={settings.binanceTitle} onChange={e => setSettings({...settings, binanceTitle: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-bold text-sm shadow-inner" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">PayID / Account</label>
                      <input type="text" value={settings.binanceNumber} onChange={e => setSettings({...settings, binanceNumber: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-black text-lg shadow-inner" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Payment Instruction</label>
                      <textarea value={settings.binanceInstruction} onChange={e => setSettings({...settings, binanceInstruction: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-xs font-bold shadow-inner min-h-[80px]" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Logo/Image URL</label>
                      <input type="text" value={settings.binanceImg} onChange={e => setSettings({...settings, binanceImg: e.target.value})} className="w-full px-5 py-3.5 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none text-[10px] font-mono shadow-inner" />
                    </div>
                </div>
             </div>

             {/* Banner Management Config */}
             <div className="bg-white dark:bg-gray-800 p-8 rounded-[3.5rem] border border-gray-100 dark:border-gray-700 shadow-2xl space-y-8">
                <div className="flex items-center gap-3 text-indigo-600">
                   <LayoutGrid size={20} strokeWidth={2.5} />
                   <h4 className="text-[11px] font-black uppercase tracking-[0.25em]">Home Banner Management</h4>
                </div>
                
                <div className="space-y-10">
                   {/* Banner 1 */}
                   <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-[2.5rem] border border-gray-100 dark:border-gray-600 space-y-5 shadow-inner">
                      <div className="flex items-center justify-between px-1">
                         <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Banner Box 1</p>
                         <ImageIcon size={14} className="text-gray-300" />
                      </div>
                      <div className="space-y-4">
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Banner Title</label>
                            <input type="text" value={settings.banner1Title} onChange={e => setSettings({...settings, banner1Title: e.target.value})} className="w-full px-5 py-3 bg-white dark:bg-gray-800 rounded-2xl outline-none font-bold text-xs shadow-sm border border-gray-100 dark:border-gray-600" placeholder="Title" />
                         </div>
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Image URL</label>
                            <input type="text" value={settings.banner1Img} onChange={e => setSettings({...settings, banner1Img: e.target.value})} className="w-full px-5 py-3 bg-white dark:bg-gray-800 rounded-2xl outline-none font-bold text-[10px] font-mono shadow-sm border border-gray-100 dark:border-gray-600" placeholder="Image URL" />
                         </div>
                      </div>
                   </div>

                   {/* Banner 2 */}
                   <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-[2.5rem] border border-gray-100 dark:border-gray-600 space-y-5 shadow-inner">
                      <div className="flex items-center justify-between px-1">
                         <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Banner Box 2</p>
                         <ImageIcon size={14} className="text-gray-300" />
                      </div>
                      <div className="space-y-4">
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Banner Title</label>
                            <input type="text" value={settings.banner2Title} onChange={e => setSettings({...settings, banner2Title: e.target.value})} className="w-full px-5 py-3 bg-white dark:bg-gray-800 rounded-2xl outline-none font-bold text-xs shadow-sm border border-gray-100 dark:border-gray-600" placeholder="Title" />
                         </div>
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Image URL</label>
                            <input type="text" value={settings.banner2Img} onChange={e => setSettings({...settings, banner2Img: e.target.value})} className="w-full px-5 py-3 bg-white dark:bg-gray-800 rounded-2xl outline-none font-bold text-[10px] font-mono shadow-sm border border-gray-100 dark:border-gray-600" placeholder="Image URL" />
                         </div>
                      </div>
                   </div>

                   {/* Banner 3 */}
                   <div className="bg-gray-50 dark:bg-gray-700/50 p-6 rounded-[2.5rem] border border-gray-100 dark:border-gray-600 space-y-5 shadow-inner">
                      <div className="flex items-center justify-between px-1">
                         <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Banner Box 3</p>
                         <ImageIcon size={14} className="text-gray-300" />
                      </div>
                      <div className="space-y-4">
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Banner Title</label>
                            <input type="text" value={settings.banner3Title} onChange={e => setSettings({...settings, banner3Title: e.target.value})} className="w-full px-5 py-3 bg-white dark:bg-gray-800 rounded-2xl outline-none font-bold text-xs shadow-sm border border-gray-100 dark:border-gray-600" placeholder="Title" />
                         </div>
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-gray-400 uppercase ml-1 tracking-widest">Image URL</label>
                            <input type="text" value={settings.banner3Img} onChange={e => setSettings({...settings, banner3Img: e.target.value})} className="w-full px-5 py-3 bg-white dark:bg-gray-800 rounded-2xl outline-none font-bold text-[10px] font-mono shadow-sm border border-gray-100 dark:border-gray-600" placeholder="Image URL" />
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        )}

        {activeAdminTab === 'bonus' && (
          <div className="space-y-8 pb-10">
            <div className="bg-white dark:bg-gray-800 p-8 rounded-[3rem] border border-gray-100 dark:border-gray-700 shadow-2xl animate-in zoom-in duration-500">
              <div className="flex items-center gap-3 text-indigo-600 mb-8">
                <Plus size={24} strokeWidth={3} />
                <h3 className="text-sm font-black dark:text-white uppercase tracking-[0.2em]">New Bonus Code</h3>
              </div>
              <form onSubmit={handleCreateCode} className="space-y-5">
                <input type="text" value={newCode} onChange={e => setNewCode(e.target.value)} className="w-full px-6 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-black text-base uppercase tracking-widest border-2 border-transparent focus:border-indigo-500 transition-all" placeholder="HAPPY888" />
                <div className="grid grid-cols-2 gap-4">
                  <input type="number" value={newReward} onChange={e => setNewReward(e.target.value)} className="w-full px-6 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-black text-base border-2 border-transparent focus:border-indigo-500 transition-all" placeholder="Reward ৳" />
                  <input type="number" value={newMaxUses} onChange={e => setNewMaxUses(e.target.value)} className="w-full px-6 py-4 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-black text-base border-2 border-transparent focus:border-indigo-500 transition-all" placeholder="Usage Limit" />
                </div>
                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-5 rounded-[2rem] shadow-xl shadow-indigo-600/20 active:scale-[0.98] transition-all uppercase tracking-widest">Generate Bonus Code</button>
              </form>
            </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md bg-white/80 dark:bg-gray-900/80 backdrop-blur-2xl px-2 py-2 rounded-[2.5rem] shadow-2xl flex items-center justify-around z-[150]">
        {adminTabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveAdminTab(tab.id as any)} className={`flex flex-col items-center justify-center py-2 px-1 rounded-3xl transition-all ${activeAdminTab === tab.id ? 'text-red-600 flex-[1.5]' : 'text-gray-400 flex-1'}`}>
            <div className={`p-2.5 rounded-2xl transition-all ${activeAdminTab === tab.id ? 'bg-red-600 text-white shadow-lg' : ''}`}><tab.icon size={18} /></div>
            <span className={`text-[8px] font-black uppercase mt-1.5 ${activeAdminTab === tab.id ? 'opacity-100' : 'opacity-0 h-0 overflow-hidden'}`}>{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default AdminPanel;