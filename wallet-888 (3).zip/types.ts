export type Tab = 'games' | 'deposit' | 'withdraw' | 'history' | 'profile' | 'admin';

export interface User {
  id: string;
  email: string;
  phone: string;
  password: string;
  promoCode?: string;
  balance: number;
  uid: string;
  isVerified: boolean;
  avatarUrl?: string;
  boundBkash?: string;
  boundNagad?: string;
  boundBinance?: string;
  lastSpinDate?: string;
  spinDaysRemaining: number;
  totalRefers: number;
  refersDeposited: number;
  totalEarned: number;
  totalDeposits: number;
  totalTurnover: number;
  isBlocked?: boolean;
  isDemo?: boolean;
  usedBonusCodes: string[];
  // KYC Fields
  firstName?: string;
  lastName?: string;
  nid?: string;
  dob?: string;
}

export interface BonusCode {
  id: string;
  code: string;
  reward: number;
  maxUses: number;
  currentUses: number;
}

export interface UserMessage {
  id: string;
  uid: string;
  title: string;
  content: string;
  date: string;
  isRead: boolean;
  type: 'success' | 'error' | 'info';
}

export interface Transaction {
  id: string;
  uid: string;
  type: 'deposit' | 'withdraw';
  amount: number;
  method: string;
  status: 'pending' | 'success' | 'failed';
  date: string;
  txnId?: string;
  screenshotUrl?: string;
  targetAccount?: string;
}

export interface Notification {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export interface AppSettings {
  bkashTitle: string;
  bkashNumber: string;
  bkashInstruction: string;
  bkashImg: string;
  nagadTitle: string;
  nagadNumber: string;
  nagadInstruction: string;
  nagadImg: string;
  binanceTitle: string;
  binanceNumber: string;
  binanceInstruction: string;
  binanceImg: string;
  telegramLink: string;
  whatsappLink: string;
  sLink: string;
  downloadLink: string;
  webLink: string;
  banner1Title: string;
  banner1Img: string;
  banner2Title: string;
  banner2Img: string;
  banner3Title: string;
  banner3Img: string;
  banners: string[];
  nextAviatorCrash: number;
  nextWingoResult: string;
}