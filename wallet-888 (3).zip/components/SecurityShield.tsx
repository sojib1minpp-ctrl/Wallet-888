
import React, { useState, useEffect } from 'react';
import { ShieldCheck, ShieldAlert, Zap } from 'lucide-react';

interface SecurityShieldProps {
  onViolation?: (msg: string) => void;
}

const SecurityShield: React.FC<SecurityShieldProps> = ({ onViolation }) => {
  const [status, setStatus] = useState<'scanning' | 'protected'>('scanning');
  const [clickBuffer, setClickBuffer] = useState<number[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => setStatus('protected'), 2000);
    
    // Simple anti-spam monitor
    const handleGlobalClick = () => {
      const now = Date.now();
      setClickBuffer(prev => {
        const updated = [...prev, now].filter(t => now - t < 1000);
        if (updated.length > 8) {
          if (onViolation) onViolation("অস্বাভাবিক গতিবিধি শনাক্ত হয়েছে। দয়া করে শান্তভাবে খেলুন।");
          return [];
        }
        return updated;
      });
    };

    window.addEventListener('click', handleGlobalClick);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('click', handleGlobalClick);
    };
  }, [onViolation]);

  return (
    <div className="fixed bottom-20 right-4 z-[60] flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-md rounded-full border border-white/20 shadow-lg pointer-events-none">
      {status === 'scanning' ? (
        <>
          <Zap size={12} className="text-amber-400 animate-pulse" />
          <span className="text-[8px] font-black text-white uppercase tracking-widest">Scanning Security...</span>
        </>
      ) : (
        <>
          <ShieldCheck size={12} className="text-green-400" />
          <span className="text-[8px] font-black text-white uppercase tracking-widest">SSL Protected</span>
        </>
      )}
    </div>
  );
};

export default SecurityShield;
