import React, { useState, useEffect, useCallback } from 'react';
import { User, Tab, Notification, Transaction, AppSettings, UserMessage, BonusCode } from './types';
import SplashScreen from './components/SplashScreen';
import Auth from './components/Auth';
import Navbar from './components/Navbar';
import BottomNav from './components/BottomNav';
import Games from './components/Games';
import Deposit from './components/Deposit';
import Withdraw from './components/Withdraw';
import History from './components/History';
import Profile from './components/Profile';
import NotificationToast from './components/NotificationToast';
import MessageCenter from './components/MessageCenter';
import AdminPanel from './components/AdminPanel';
import AdminEntrance from './components/AdminEntrance';
import { Zap } from 'lucide-react';
import { rtdb } from './firebase';
import { ref, onValue, set, push, update } from 'firebase/database';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [showAdminEntrance, setShowAdminEntrance] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('games');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [userMessages, setUserMessages] = useState<UserMessage[]>([]);
  const [isMessageCenterOpen, setIsMessageCenterOpen] = useState(false);
  const [bonusCodes, setBonusCodes] = useState<BonusCode[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isGameOpen, setIsGameOpen] = useState(false);
  
  const [settings, setSettings] = useState<AppSettings>({
    bkashTitle: "bKash Personal",
    bkashNumber: "01827456782",
    bkashInstruction: "বিকাশ অ্যাপ থেকে 'সেন্ড মানি' অপশনে গিয়ে উপরে দেওয়া নাম্বারে টাকা পাঠিয়ে ট্রানজেকশন আইডি এবং স্ক্রিনশট দিন।",
    bkashImg: "https://picsum.photos/seed/bkash-v3/200/200",
    nagadTitle: "Nagad Personal",
    nagadNumber: "01827456782",
    nagadInstruction: "নগদ অ্যাপ বা ইউএসএসডি কোড ব্যবহার করে সেন্ড মানি করুন। সঠিক টাকা পাঠিয়ে তথ্য দিন।",
    nagadImg: "https://picsum.photos/seed/nagad-v3/200/200",
    binanceTitle: "Binance Pay ID",
    binanceNumber: "77218392",
    binanceInstruction: "Binance Pay এর মাধ্যমে USDT বা BDT কনভার্ট করে উপরে দেওয়া Pay ID তে পেমেন্ট সম্পন্ন করুন।",
    binanceImg: "https://picsum.photos/seed/binance-v3/200/200",
    telegramLink: "https://t.me/wallet888",
    whatsappLink: "https://wa.me/8801827456782",
    sLink: "https://s-link.example.com",
    downloadLink: "https://wallet888.app/apk",
    webLink: "https://wallet888.app",
    banner1Title: "Win Big Today!",
    banner1Img: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=800",
    banner2Title: "New Games Added",
    banner2Img: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800",
    banner3Title: "100% Deposit Bonus",
    banner3Img: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=800",
    banners: [],
    nextAviatorCrash: 1.85,
    nextWingoResult: "Big"
  });

  const addNotification = useCallback((message: string, type: Notification['type'] = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [...prev, { id, message, type }]);
  }, []);

  // Sync Global Settings
  useEffect(() => {
    const settingsRef = ref(rtdb, 'settings');
    return onValue(settingsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setSettings(data);
    });
  }, []);

  // Sync Global Collections (Users, Transactions, Codes, Messages)
  useEffect(() => {
    const usersRef = ref(rtdb, 'users');
    const txRef = ref(rtdb, 'transactions');
    const codesRef = ref(rtdb, 'bonusCodes');
    const msgsRef = ref(rtdb, 'messages');

    const unsubscribeUsers = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setAllUsers(Object.values(data));
    });

    const unsubscribeTx = onValue(txRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setTransactions(Object.values(data).reverse());
    });

    const unsubscribeCodes = onValue(codesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setBonusCodes(Object.values(data));
    });

    const unsubscribeMsgs = onValue(msgsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) setUserMessages(Object.values(data));
    });

    // Check localStorage for session persistence
    const savedUid = localStorage.getItem('currentUserUid');
    if (savedUid) {
      const userRef = ref(rtdb, `users/${savedUid}`);
      onValue(userRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          setUser(data);
          setIsAdmin(data.email === 'sojib1minpp@gmail.com');
        }
      });
    }

    const timer = setTimeout(() => setLoading(false), 2000);
    return () => {
      unsubscribeUsers();
      unsubscribeTx();
      unsubscribeCodes();
      unsubscribeMsgs();
      clearTimeout(timer);
    };
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    localStorage.setItem('currentUserUid', loggedInUser.uid);
    const isSystemAdmin = loggedInUser.email === 'sojib1minpp@gmail.com';
    setIsAdmin(isSystemAdmin);
    if (isSystemAdmin) {
      setShowAdminEntrance(true);
      setActiveTab('admin');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setIsAdmin(false);
    setActiveTab('games');
    localStorage.removeItem('currentUserUid');
  };

  const handleUpdateSettings = (s: AppSettings) => {
    set(ref(rtdb, 'settings'), s);
  };

  const handleNewTransaction = (tx: Transaction) => {
    const newTxRef = push(ref(rtdb, 'transactions'));
    const finalTx = { ...tx, id: newTxRef.key || tx.id };
    set(newTxRef, finalTx);
  };

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const addUserMessage = useCallback((uid: string, title: string, content: string, type: UserMessage['type'] = 'info') => {
    const msgsRef = ref(rtdb, 'messages');
    const newMessageRef = push(msgsRef);
    const newMessage: UserMessage = {
      id: newMessageRef.key || Math.random().toString(),
      uid, title, content, type, isRead: false,
      date: new Date().toLocaleString('bn-BD')
    };
    set(newMessageRef, newMessage);
  }, []);

  const handleUpdateUser = (updatedUser: User) => {
    update(ref(rtdb, `users/${updatedUser.uid}`), updatedUser);
  };

  const handleSetAllUsers = (newUsers: User[]) => {
    // This is primarily used by AdminPanel for bulk mapping updates
    // In a real database we update specific records, but for this clone 
    // we'll simulate the set if needed or handle specific updates in AdminPanel
    newUsers.forEach(u => handleUpdateUser(u));
  };

  if (loading) return <SplashScreen />;
  if (showAdminEntrance) return <AdminEntrance onComplete={() => setShowAdminEntrance(false)} />;

  if (!user) {
    return (
      <div className={`h-full flex flex-col ${isDarkMode ? 'dark' : ''}`}>
        <Auth onLogin={handleLogin} addNotification={addNotification} />
        <div className="fixed top-6 left-1/2 -translate-x-1/2 w-[90%] max-w-[440px] z-[200] flex flex-col items-center pointer-events-none">
          {notifications.map(n => (
            <NotificationToast key={n.id} notification={n} onClose={removeNotification} />
          ))}
        </div>
      </div>
    );
  }

  const unreadCount = userMessages.filter(m => m.uid === user.uid && !m.isRead).length;

  return (
    <div className={`flex flex-col h-full overflow-hidden transition-colors duration-200 ${isDarkMode ? 'dark bg-[#0c0f1d] text-white' : 'bg-gray-50 text-gray-900'}`}>
      {!isGameOpen && (
        <Navbar 
          user={user} 
          isDarkMode={isDarkMode} 
          setIsDarkMode={setIsDarkMode} 
          onLogout={handleLogout}
          isAdmin={isAdmin}
          unreadMessages={unreadCount}
          onBellClick={() => setIsMessageCenterOpen(true)}
        />
      )}

      <main className={`flex-1 overflow-y-auto overflow-x-hidden no-scrollbar ${!isGameOpen ? 'px-4 pt-1' : 'p-0'}`}>
        {activeTab === 'admin' && isAdmin && (
          <AdminPanel 
            users={allUsers} 
            setUsers={handleSetAllUsers as any}
            transactions={transactions} 
            setTransactions={((val: any) => {
              // Admin updates transactions (e.g. approve/reject)
              // This is a simplified handler
            }) as any}
            settings={settings}
            setSettings={handleUpdateSettings}
            bonusCodes={bonusCodes}
            setBonusCodes={((val: any) => {
               // Admin adds bonus codes
            }) as any}
            addNotification={addNotification}
            addUserMessage={addUserMessage}
            onBack={() => setActiveTab('games')}
          />
        )}
        {activeTab === 'games' && <Games user={user} setUser={handleUpdateUser as any} addNotification={addNotification} onNavigate={setActiveTab} onGameToggle={setIsGameOpen} settings={settings} />}
        {activeTab === 'deposit' && (
          <Deposit 
            user={user} setUser={handleUpdateUser as any} addNotification={addNotification} 
            onNewTransaction={handleNewTransaction} 
            settings={settings}
          />
        )}
        {activeTab === 'withdraw' && (
          <Withdraw 
            user={user} setUser={handleUpdateUser as any} addNotification={addNotification} 
            onNewTransaction={handleNewTransaction} 
            settings={settings}
          />
        )}
        {activeTab === 'history' && <History user={user} transactions={transactions.filter(t => t.uid === user.uid)} />}
        {activeTab === 'profile' && (
          <Profile 
            user={user} setUser={handleUpdateUser as any} bonusCodes={bonusCodes} setBonusCodes={(() => {}) as any} 
            addNotification={addNotification} settings={settings}
            updateBalance={(amt) => handleUpdateUser({ ...user, balance: user.balance + amt })}
          />
        )}
        {!isGameOpen && <div className="h-4"></div>}
      </main>

      {!isAdmin && !isGameOpen && <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />}
      
      {isAdmin && !isGameOpen && (
        <button onClick={() => setActiveTab('admin')} className="fixed bottom-24 right-6 w-14 h-14 bg-red-600 text-white rounded-full flex items-center justify-center shadow-2xl z-[150] border-4 border-white animate-pulse">
          <Zap size={24} />
        </button>
      )}

      {isMessageCenterOpen && (
        <MessageCenter 
          messages={userMessages.filter(m => m.uid === user.uid)}
          onClose={() => setIsMessageCenterOpen(false)}
        />
      )}

      <div className="fixed top-20 left-1/2 -translate-y-1/2 w-[90%] max-w-[440px] z-[200] flex flex-col items-center pointer-events-none space-y-2">
        {notifications.map(n => (
          <NotificationToast key={n.id} notification={n} onClose={removeNotification} />
        ))}
      </div>
    </div>
  );
};

export default App;