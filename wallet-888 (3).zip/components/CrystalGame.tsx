
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { ChevronLeft, Wallet, Info, Sparkles, ShieldCheck } from 'lucide-react';

interface CrystalGameProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type?: any) => void;
  onBack: () => void;
}

const CrystalGame: React.FC<CrystalGameProps> = ({ user, setUser, addNotification, onBack }) => {
  const [bet, setBet] = useState<number>(10);
  const [grid, setGrid] = useState<string[][]>([]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [lastWin, setLastWin] = useState<number | null>(null);

  const GEMS = ['💎', '💎', '💎', '💎', '💰', '💰', '🌟', '🌟', '🧧', '🧧'];
  const GRID_SIZE = 7;
  const MIN_BET = 10;
  const MAX_BET = 100000;

  useEffect(() => {
    generateRandomGrid();
  }, []);

  const generateRandomGrid = () => {
    const newGrid: string[][] = [];
    for (let i = 0; i < GRID_SIZE; i++) {
      const row: string[] = [];
      for (let j = 0; j < GRID_SIZE; j++) {
        row.push(GEMS[Math.floor(Math.random() * GEMS.length)]);
      }
      newGrid.push(row);
    }
    setGrid(newGrid);
  };

  const handleBetChange = (amount: string) => {
    const val = parseFloat(amount) || 0;
    setBet(val);
  };

  const adjustBet = (action: 'min' | 'max' | 'x2' | 'half') => {
    if (action === 'min') setBet(MIN_BET);
    if (action === 'max') setBet(Math.min(user.balance, MAX_BET));
    if (action === 'x2') setBet(prev => Math.min(prev * 2, MAX_BET));
    if (action === 'half') setBet(prev => Math.max(prev / 2, MIN_BET));
  };

  const play = () => {
    if (user.balance < bet) {
      addNotification("আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই!", "error");
      return;
    }
    if (bet < MIN_BET || bet > MAX_BET) {
      addNotification(`বেড ১০ থেকে ১,০০,০০০ টাকার মধ্যে হতে হবে!`, "error");
      return;
    }

    setIsSpinning(true);
    setLastWin(null);
    
    // Deduct bet immediately and track turnover
    setUser(prev => prev ? { 
      ...prev, 
      balance: prev.balance - bet,
      totalTurnover: (prev.totalTurnover || 0) + bet 
    } : null);

    // Simulate "spinning" effect
    let cycles = 0;
    const interval = setInterval(() => {
      generateRandomGrid();
      cycles++;
      if (cycles > 12) {
        clearInterval(interval);
        finalizeGame();
      }
    }, 90);
  };

  const finalizeGame = () => {
    /**
     * REQUESTED LOGIC:
     * 1. 99% of players should lose (Probability of profit < 1%)
     * 2. Payouts vary: 8, 9, 10, 12, 15, 25, 2, 1, 0.30, etc.
     * 3. Max payout is 10x (৳10 -> ৳100). Never exceeds 10x.
     */
    const random = Math.random() * 100;
    let winAmount = 0;
    let winType: 'loss' | 'near-push' | 'profit' | 'jackpot' = 'loss';

    if (random < 70) {
      // 70% Hard Loss: Tiny crumbs (0.30 to 3 BDT)
      winAmount = 0.30 + (Math.random() * 2.70);
      winType = 'loss';
    } else if (random < 95) {
      // 25% Near Push/Loss: Significant loss but feels like a "near win" (8 to 10 BDT for 10 BDT bet)
      // Range: 0.5x to 1.0x
      winAmount = bet * (0.5 + Math.random() * 0.5);
      winType = 'near-push';
    } else if (random < 99.5) {
      // 4.5% Small Profit: 1.1x to 2.5x (11 to 25 BDT)
      winAmount = bet * (1.1 + Math.random() * 1.4);
      winType = 'profit';
    } else {
      // 0.5% Big Win: Max 10x (100 BDT for 10 BDT bet)
      winAmount = bet * (5 + Math.random() * 5);
      winType = 'jackpot';
    }

    // Cap the win amount at 10x of the current bet strictly
    winAmount = Math.min(winAmount, bet * 10);

    // Update the visual grid based on the outcome
    const newGrid = [...grid];
    if (winType === 'jackpot' || winType === 'profit') {
      // Visual "Line" of same gems to indicate win
      const luckyGem = GEMS[0]; // Diamond
      const row = Math.floor(Math.random() * GRID_SIZE);
      for(let i=0; i<GRID_SIZE; i++) {
        if (Math.random() > 0.2) newGrid[row][i] = luckyGem;
      }
    }
    setGrid(newGrid);

    setTimeout(() => {
      setIsSpinning(false);
      setUser(prev => prev ? { ...prev, balance: prev.balance + winAmount } : null);
      setLastWin(winAmount);
      
      if (winAmount > bet) {
        addNotification(`আপনি জিতেছেন ৳ ${winAmount.toFixed(2)}`, "success");
      } else if (winAmount > 0) {
        addNotification(`আপনি মাত্র ৳ ${winAmount.toFixed(2)} ফেরত পেয়েছেন।`, "info");
      } else {
        addNotification("আপনি হেরে গেছেন, আবার চেষ্টা করুন।", "error");
      }
    }, 300);
  };

  return (
    <div className="min-h-screen bg-[#080d17] text-white flex flex-col animate-in fade-in duration-500 overflow-hidden font-sans">
      {/* Header */}
      <div className="p-4 flex items-center justify-between bg-[#0b1322]/40 backdrop-blur-md z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 bg-indigo-600/20 rounded-xl text-indigo-400 hover:text-white transition-colors">
            <ChevronLeft size={20} />
          </button>
          <div className="bg-[#5343e8] px-3 py-1 rounded-lg text-white font-black text-xs">888</div>
        </div>
        
        <div className="flex flex-col items-center">
          <span className="text-[9px] font-black text-gray-500 uppercase tracking-[0.3em] mb-1">Balance</span>
          <div className="flex items-center gap-2 text-indigo-400 font-black">
            <span className="text-sm">৳</span>
            <span className="text-lg tabular-nums">{user.balance.toFixed(2)}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
           <button className="p-2 bg-white/5 rounded-full text-gray-400"><Info size={18} /></button>
        </div>
      </div>

      {/* Grid Container */}
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="relative bg-[#101828]/60 backdrop-blur-3xl rounded-[2.5rem] p-4 border border-white/5 shadow-2xl">
          <div className="grid grid-cols-7 gap-1">
            {grid.map((row, rIdx) => 
              row.map((cell, cIdx) => (
                <div 
                  key={`${rIdx}-${cIdx}`} 
                  className={`w-10 h-10 sm:w-11 sm:h-11 bg-[#1e293b]/30 rounded-lg flex items-center justify-center text-xl transition-all duration-300 ${isSpinning ? 'animate-pulse scale-90 opacity-40 blur-[1px]' : 'hover:scale-105 shadow-lg border border-white/5'}`}
                >
                  <span className="drop-shadow-sm">{cell}</span>
                </div>
              ))
            )}
          </div>
          
          {/* Internal Glow */}
          <div className="absolute inset-0 pointer-events-none rounded-[2.5rem] shadow-[inset_0_0_60px_rgba(79,70,229,0.1)]"></div>
        </div>

        {/* Last Win Banner (As seen in screenshot) */}
        <div className="mt-8 transition-all duration-500">
          <div className={`px-10 py-2.5 rounded-full border border-green-500/20 bg-green-500/10 flex items-center gap-2 shadow-lg transition-opacity ${lastWin !== null ? 'opacity-100' : 'opacity-40'}`}>
            <span className="text-[11px] font-black text-green-500 uppercase tracking-widest">
              Last Win: ৳{lastWin ? lastWin.toFixed(2) : '0.00'}
            </span>
          </div>
        </div>
      </div>

      {/* Betting Panel */}
      <div className="p-6 pb-12 bg-[#0f172a] rounded-t-[3rem] border-t border-white/5 shadow-2xl space-y-6">
        {/* Quick Bet Buttons */}
        <div className="grid grid-cols-4 gap-3">
          {['MIN', 'X2', 'X/2', 'MAX'].map((label) => (
            <button
              key={label}
              disabled={isSpinning}
              onClick={() => adjustBet(label.toLowerCase() as any)}
              className="bg-[#1e293b]/50 hover:bg-indigo-600/10 text-gray-500 font-black border border-white/5 py-3 rounded-xl text-[10px] transition-all active:scale-95 disabled:opacity-30"
            >
              {label}
            </button>
          ))}
        </div>

        {/* Stake Control */}
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative bg-[#080d17] rounded-[1.5rem] p-4 flex flex-col border border-white/5">
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1.5 ml-1">Stake Amount</span>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-black text-gray-700">৳</span>
                <input 
                  type="number"
                  value={bet}
                  onChange={(e) => handleBetChange(e.target.value)}
                  disabled={isSpinning}
                  className="bg-transparent w-full font-black text-2xl text-white outline-none tabular-nums"
                  placeholder="0"
                />
              </div>
              <div className="mt-2 text-[8px] font-bold text-gray-600 uppercase tracking-tight">MIN 10 ৳ - MAX 100,000 ৳</div>
            </div>
            
            <button 
              disabled={isSpinning}
              onClick={play}
              className={`h-full min-w-[150px] px-8 py-5 rounded-[1.5rem] flex flex-col items-center justify-center gap-1 transition-all active:scale-95 shadow-xl ${
                isSpinning 
                  ? 'bg-gray-800 text-gray-600' 
                  : 'bg-gradient-to-br from-indigo-600 to-indigo-700 text-white shadow-indigo-600/30'
              }`}
            >
              <span className="font-black text-sm uppercase tracking-widest leading-none">Stake</span>
              <div className="flex items-center gap-1 opacity-60">
                <ShieldCheck size={10} />
                <span className="text-[8px] font-black uppercase tracking-tighter">SSL Protected</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CrystalGame;
