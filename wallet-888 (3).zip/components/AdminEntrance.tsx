
import React, { useEffect, useState } from 'react';
import { ShieldAlert, Zap, Cpu } from 'lucide-react';

interface Props {
  onComplete: () => void;
}

const AdminEntrance: React.FC<Props> = ({ onComplete }) => {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setStage(1), 800),
      setTimeout(() => setStage(2), 1600),
      setTimeout(() => setStage(3), 2400),
      setTimeout(() => onComplete(), 3200),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-black z-[9999] flex flex-col items-center justify-center p-10 overflow-hidden">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,#ef4444_0%,transparent_70%)]"></div>
        <div className="w-full h-full grid grid-cols-10 grid-rows-10">
          {[...Array(100)].map((_, i) => (
            <div key={i} className="border-[0.5px] border-red-900/30"></div>
          ))}
        </div>
      </div>

      <div className="relative flex flex-col items-center">
        <div className={`mb-8 p-6 rounded-full border-4 border-red-600 shadow-[0_0_50px_rgba(239,68,68,0.5)] bg-black/50 transition-all duration-500 ${stage >= 1 ? 'scale-110' : 'scale-75 opacity-50'}`}>
          <ShieldAlert size={64} className="text-red-600 animate-pulse" />
        </div>

        <h2 className="text-2xl font-black text-white uppercase tracking-[0.3em] mb-4 text-center">
          {stage === 0 && "Scanning Identity..."}
          {stage === 1 && "Identity Confirmed"}
          {stage === 2 && "Decrypting Admin HQ"}
          {stage === 3 && "Access Granted"}
        </h2>

        <div className="w-64 h-1.5 bg-gray-900 rounded-full overflow-hidden border border-white/10">
          <div 
            className="h-full bg-red-600 shadow-[0_0_15px_#ef4444] transition-all duration-700 ease-out" 
            style={{ width: `${(stage + 1) * 25}%` }}
          ></div>
        </div>

        <div className="mt-10 flex gap-4">
           <div className={`flex items-center gap-2 px-4 py-2 bg-red-950/30 rounded-xl border border-red-900/50 transition-all duration-500 ${stage >= 1 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <Zap size={14} className="text-red-500" />
              <span className="text-[10px] font-black text-red-400 uppercase tracking-widest leading-none">Root Access</span>
           </div>
           <div className={`flex items-center gap-2 px-4 py-2 bg-red-950/30 rounded-xl border border-red-900/50 transition-all duration-500 ${stage >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <Cpu size={14} className="text-red-500" />
              <span className="text-[10px] font-black text-red-400 uppercase tracking-widest leading-none">AES-256 Active</span>
           </div>
        </div>
      </div>

      <div className="absolute top-0 left-0 w-full h-1 bg-red-600/50 shadow-[0_0_20px_#ef4444] animate-[scan_2s_linear_infinite]"></div>

      <style>{`
        @keyframes scan {
          0% { transform: translateY(-100vh); opacity: 0; }
          50% { opacity: 1; }
          100% { transform: translateY(100vh); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default AdminEntrance;
