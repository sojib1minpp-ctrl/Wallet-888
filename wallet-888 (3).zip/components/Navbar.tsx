import React from 'react';
import { User } from '../types';
import { Bell, Moon, Sun, LogOut, ShieldAlert } from 'lucide-react';

interface NavbarProps {
  user: User;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  onLogout: () => void;
  isAdmin?: boolean;
  unreadMessages?: number;
  onBellClick?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, isDarkMode, setIsDarkMode, onLogout, isAdmin, unreadMessages = 0, onBellClick }) => {
  return (
    <nav className="h-16 bg-white dark:bg-[#0c0f1d] border-b border-gray-100 dark:border-gray-800 flex items-center justify-between px-4 z-[100] w-full shrink-0">
      <div className="flex items-center gap-2">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isAdmin ? 'bg-red-600 animate-pulse' : 'bg-indigo-600'}`}>
          {isAdmin ? <ShieldAlert size={16} className="text-white" /> : <span className="text-white text-[10px] font-black tracking-tighter">888</span>}
        </div>
        <span className={`text-lg font-black bg-clip-text text-transparent ${isAdmin ? 'bg-gradient-to-r from-red-600 to-rose-400' : 'bg-gradient-to-r from-indigo-600 to-purple-600'} dark:from-indigo-400 dark:to-purple-400`}>
          {isAdmin ? 'ADMIN' : 'WALLET'}
        </span>
      </div>

      <div className="flex items-center gap-3">
        {!isAdmin && (
          <div className="flex flex-col items-end mr-1">
            <span className="text-[8px] text-gray-400 uppercase font-black tracking-widest leading-none">BALANCE</span>
            <span className="text-sm font-black text-indigo-600 dark:text-indigo-400 leading-none mt-1">৳ {user.balance.toFixed(2)}</span>
          </div>
        )}

        <div className="flex items-center gap-1">
          {!isAdmin && (
            <button 
              onClick={onBellClick}
              className="relative p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors active:scale-90"
            >
              <Bell size={18} />
              {unreadMessages > 0 && (
                <span className="absolute top-1.5 right-1.5 w-3 h-3 bg-red-500 text-white text-[7px] font-black rounded-full flex items-center justify-center border border-white dark:border-[#0c0f1d] animate-bounce">
                  {unreadMessages}
                </span>
              )}
            </button>
          )}
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
          >
            {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button 
            onClick={onLogout}
            className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;