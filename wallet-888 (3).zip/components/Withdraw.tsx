import React, { useState } from 'react';
import { User, Transaction, AppSettings } from '../types';
import { ChevronRight, HelpCircle, ShieldCheck, AlertCircle, PlusCircle, CheckCircle2 } from 'lucide-react';

interface WithdrawProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type: 'success' | 'error' | 'info') => void;
  onNewTransaction: (tx: Transaction) => void;
  settings: AppSettings;
}

const Withdraw: React.FC<WithdrawProps> = ({ user, setUser, addNotification, onNewTransaction, settings }) => {
  const [method, setMethod] = useState<'Bkash' | 'Nagad' | 'Binance' | null>(null);
  const [amount, setAmount] = useState('');
  const [targetAccount, setTargetAccount] = useState('');

  const usedNumbersDB = ['01700000000'];

  const isBound = (m: string) => {
    if (m === 'Bkash') return !!user.boundBkash;
    if (m === 'Nagad') return !!user.boundNagad;
    if (m === 'Binance') return !!user.boundBinance;
    return false;
  };

  const getBoundValue = (m: string) => {
    if (m === 'Bkash') return user.boundBkash;
    if (m === 'Nagad') return user.boundNagad;
    if (m === 'Binance') return user.boundBinance;
    return '';
  };

  const handleBindAndWithdraw = () => {
    if (user.isDemo) {
      addNotification("এটা দিয়ে উত্তোলন করা যাবে না।", 'error');
      return;
    }

    const amt = parseFloat(amount);
    
    if (user.balance <= 0 || (amt > user.balance)) {
      addNotification("আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই, দয়া করে রিচার্জ করুন", 'error');
      return;
    }

    if (!amt || amt < 500) {
      addNotification("সর্বনিম্ন উত্তোলন ৫০০ টাকা", 'error');
      return;
    }

    const requiredTurnover = user.totalDeposits || 0;
    const currentTurnover = user.totalTurnover || 0;
    if (currentTurnover < requiredTurnover) {
      const remaining = requiredTurnover - currentTurnover;
      addNotification(`আপনার ডিপোজিট করা সম্পূর্ণ টাকা এখনো খেলা হয়নি। আরও ৳${remaining.toFixed(0)} খেলতে হবে।`, 'error');
      return;
    }

    const updatedUser = { ...user };
    
    if (!isBound(method!)) {
      if (!targetAccount || targetAccount.length < 10) {
        addNotification("অনুগ্রহ করে আপনার সঠিক নাম্বারটি দিন", 'error');
        return;
      }
      
      if (usedNumbersDB.includes(targetAccount)) {
        addNotification("এই নাম্বারটি ইতিমধ্যে অন্য একটি একাউন্টে ব্যবহার করা হয়েছে। এটি আর ব্যবহার করা যাবে না।", 'error');
        return;
      }

      if (method === 'Bkash') updatedUser.boundBkash = targetAccount;
      if (method === 'Nagad') updatedUser.boundNagad = targetAccount;
      if (method === 'Binance') updatedUser.boundBinance = targetAccount;
    }

    // UPDATED: No longer deducting balance here. 
    // The balance will be deducted in AdminPanel.tsx upon approval.
    const finalAccount = isBound(method!) ? getBoundValue(method!) : targetAccount;
    setUser(updatedUser);

    const newTx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      uid: user.uid,
      type: 'withdraw',
      amount: amt,
      method: method!,
      status: 'pending',
      date: new Date().toLocaleString(),
      targetAccount: finalAccount
    };

    onNewTransaction(newTx);
    addNotification("আপনার উত্তোলন রিকোয়েস্ট সফল হয়েছে। অ্যাডমিন চেক করে ব্যালেন্স কেটে নেবে।", 'success');
    
    setAmount('');
    setMethod(null);
    setTargetAccount('');
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black dark:text-white">Withdraw Funds</h2>
        <div className="flex items-center gap-1 bg-indigo-50 dark:bg-indigo-900/20 px-3 py-1 rounded-full border border-indigo-100 dark:border-indigo-800">
           <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400">FAST PAYOUT</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { id: 'Bkash', img: settings.bkashImg, label: 'BKASH', color: 'pink' },
          { id: 'Nagad', img: settings.nagadImg, label: 'NAGAD', color: 'orange' },
          { id: 'Binance', img: settings.binanceImg, label: 'BINANCE', color: 'amber' }
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => {
              setMethod(m.id as any);
              setTargetAccount('');
            }}
            className={`p-1 rounded-3xl border-2 transition-all flex flex-col items-center gap-2 overflow-hidden bg-white dark:bg-gray-800 shadow-sm ${
              method === m.id ? 'border-indigo-600 ring-4 ring-indigo-50 dark:ring-indigo-900/20' : 'border-transparent'
            }`}
          >
            <div className="w-full aspect-square rounded-2xl overflow-hidden bg-gray-50 relative">
              <img src={m.img} alt={m.id} className="w-full h-full object-cover" />
              {isBound(m.id) && (
                <div className="absolute top-1 right-1 bg-green-500 text-white p-0.5 rounded-full shadow-lg">
                  <CheckCircle2 size={12} />
                </div>
              )}
            </div>
            <span className="text-[10px] font-black dark:text-white tracking-widest uppercase mb-1">{m.label}</span>
          </button>
        ))}
      </div>

      {method && (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-[3rem] shadow-xl border border-gray-100 dark:border-gray-700 space-y-8 animate-in zoom-in-95 duration-300">
          <div className="bg-[#f8f9ff] dark:bg-gray-700/50 p-6 rounded-3xl border border-indigo-50 dark:border-gray-600 flex justify-between items-center">
            <div>
              <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-black uppercase tracking-[0.2em] mb-1">Selected Channel</p>
              <p className="font-black text-2xl dark:text-white uppercase">{method}</p>
            </div>
            {isBound(method) ? (
              <span className="bg-green-100 text-green-600 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border border-green-200">Bound</span>
            ) : (
              <span className="bg-amber-100 text-amber-600 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border border-amber-200">New Account</span>
            )}
          </div>

          <div className="space-y-6">
            <div className="space-y-3">
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">
                {isBound(method) ? 'Account Number (Locked)' : 'নাম্বার অ্যাড করুন'}
              </label>
              
              {isBound(method) ? (
                <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-700 px-6 py-5 rounded-[2rem] border border-gray-100 dark:border-gray-600 shadow-inner">
                  <ShieldCheck className="text-green-500" size={24} />
                  <span className="text-2xl font-mono font-black text-gray-900 dark:text-white tracking-wider">{getBoundValue(method)}</span>
                </div>
              ) : (
                <div className="relative group">
                  <input
                    type="text"
                    value={targetAccount}
                    onChange={(e) => setTargetAccount(e.target.value)}
                    className="w-full px-6 py-5 rounded-[2rem] border border-gray-100 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono font-black text-lg shadow-inner"
                    placeholder={`আপনার ${method} নাম্বার দিন`}
                  />
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 text-indigo-500">
                    <PlusCircle size={20} />
                  </div>
                </div>
              )}
              
              {!isBound(method) && (
                <p className="text-[10px] text-rose-500 font-black flex items-start gap-1.5 ml-1 leading-relaxed">
                   <AlertCircle size={14} className="shrink-0 mt-0.5" />
                   এই নাম্বারটি স্থায়ীভাবে আপনার আইডির সাথে যুক্ত হবে। পরবর্তীতে অন্য কোনো একাউন্টে এই {method} নাম্বারটি ব্যবহার করতে পারবেন না।
                </p>
              )}
            </div>

            <div className="space-y-3">
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Withdrawal Amount (Min ৳500)</label>
              <div className="relative">
                <span className="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-black text-gray-300">৳</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full pl-14 pr-6 py-6 rounded-[2rem] border border-gray-100 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none text-3xl font-black shadow-inner"
                  placeholder="0.00"
                />
              </div>
              <div className="flex justify-between items-center px-2">
                <p className="text-[11px] font-bold text-gray-400 uppercase tracking-tighter">Available: <span className="text-indigo-600 dark:text-indigo-400 font-black">৳{user.balance.toFixed(2)}</span></p>
                <p className="text-[11px] font-bold text-gray-400 uppercase tracking-tighter">Daily Limit: <span className="text-gray-900 dark:text-white font-black">৳25,000</span></p>
              </div>
            </div>
          </div>

          <button
            onClick={handleBindAndWithdraw}
            className="w-full bg-[#5343e8] hover:bg-[#4335c9] text-white font-black py-6 rounded-[2.5rem] shadow-[0_20px_40px_-10px_rgba(83,67,232,0.4)] transition-all active:scale-[0.96] flex items-center justify-center gap-3 text-lg uppercase tracking-widest"
          >
            Confirm Withdrawal
            <ChevronRight size={24} strokeWidth={3} />
          </button>
        </div>
      )}

      <div className="bg-white dark:bg-gray-800/50 p-8 rounded-[3rem] border border-gray-100 dark:border-gray-700 space-y-6 shadow-sm">
        <div className="flex items-center gap-3 text-indigo-600 dark:text-indigo-400">
          <HelpCircle size={28} />
          <h4 className="font-black uppercase tracking-widest text-sm">প্রয়োজনীয় তথ্য</h4>
        </div>
        <div className="space-y-4 text-[13px] text-gray-600 dark:text-gray-400 leading-relaxed font-bold">
          <p>• সর্বনিম্ন ৫০০ থেকে ২৫ হাজার টাকা উত্তোলন করা যাবে।</p>
          <p>• <span className="text-rose-500">বিশেষ নিয়ম:</span> আপনি যত টাকা ডিপোজিট করবেন, সম্পূর্ণ টাকা না খেললে উত্তোলন করতে পারবেন না।</p>
          <p>• একবার অ্যাকাউন্ট যুক্ত করলে সেটি স্থায়ীভাবে আইডির সাথে থেকে যাবে।</p>
        </div>
        
        <div className="h-px bg-gray-100 dark:bg-gray-700 w-full"></div>
        
        <p className="text-[11px] font-bold text-rose-500 leading-relaxed italic text-center px-2">
          "প্রিয় গ্রাহক উত্তোলন নাম্বারটি সঠিকভাবে যাচাই করে নেন পরবর্তীতে কোন সমস্যা হলে অথবা আমাদের উত্তোলন সাকসেস এটার জন্য আমাদের আমরা টাইম নেই আপনার উচিত উত্তোলন নাম্বারটি সঠিক নিয়মে যাচাই করে দেখার দরকার সঠিকভাবে কাজ করুন ধন্যবাদ"
        </p>

        <button className="w-full py-4 bg-gray-50 dark:bg-gray-700 border border-gray-100 dark:border-gray-600 rounded-2xl text-[11px] font-black text-indigo-600 dark:text-indigo-400 flex items-center justify-center gap-2 uppercase tracking-widest shadow-sm active:scale-95 transition-all">
          সহায়তার জন্য যোগাযোগ করুন
        </button>
      </div>

      <div className="flex justify-center items-center gap-1 opacity-40 py-2">
         <ShieldCheck size={14} className="text-green-500" />
         <span className="text-[10px] font-black uppercase tracking-tighter">SSL Secured Withdrawal Environment</span>
      </div>
    </div>
  );
};

export default Withdraw;