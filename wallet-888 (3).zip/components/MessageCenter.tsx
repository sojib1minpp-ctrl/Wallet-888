
import React from 'react';
import { UserMessage } from '../types';
import { X, Bell, Info, CheckCircle2, AlertCircle, Trash2 } from 'lucide-react';

interface Props {
  messages: UserMessage[];
  onClose: () => void;
}

const MessageCenter: React.FC<Props> = ({ messages, onClose }) => {
  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-end sm:justify-center p-0 sm:p-6 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative w-full max-w-md h-[85vh] sm:h-auto sm:max-h-[80vh] bg-white dark:bg-gray-800 rounded-t-[3rem] sm:rounded-[3rem] overflow-hidden shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-500">
        
        {/* Header */}
        <div className="px-8 py-6 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between bg-gray-50/50 dark:bg-gray-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center text-indigo-600">
               <Bell size={20} className="animate-swing" />
            </div>
            <div>
               <h2 className="text-lg font-black dark:text-white uppercase tracking-tight leading-none">মেসেজ সেন্টার</h2>
               <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-widest">Inbox ({messages.length})</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-3 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-all active:scale-90 text-gray-400"
          >
            <X size={24} strokeWidth={3} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-32 text-center">
               <div className="w-20 h-20 bg-gray-50 dark:bg-gray-700 rounded-full flex items-center justify-center mb-6 text-gray-200 dark:text-gray-600">
                  <Bell size={40} />
               </div>
               <p className="text-gray-400 italic font-bold">আপনার কোনো মেসেজ নেই।</p>
            </div>
          ) : (
            messages.map((m) => (
              <div 
                key={m.id} 
                className={`group p-5 rounded-3xl border transition-all duration-300 ${
                  !m.isRead 
                    ? 'bg-[#f8faff] dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-800/50 shadow-md' 
                    : 'bg-white dark:bg-gray-800/50 border-gray-100 dark:border-gray-700'
                }`}
              >
                <div className="flex gap-4">
                  <div className={`w-10 h-10 rounded-2xl shrink-0 flex items-center justify-center shadow-sm ${
                    m.type === 'success' ? 'bg-green-100 text-green-600' : 
                    m.type === 'error' ? 'bg-rose-100 text-rose-600' : 'bg-blue-100 text-blue-600'
                  }`}>
                    {m.type === 'success' ? <CheckCircle2 size={20} /> : 
                     m.type === 'error' ? <AlertCircle size={20} /> : <Info size={20} />}
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex justify-between items-start">
                      <h3 className={`font-black text-sm uppercase tracking-tight ${
                        m.type === 'success' ? 'text-green-600' : 
                        m.type === 'error' ? 'text-rose-600' : 'text-indigo-600'
                      }`}>
                        {m.title}
                      </h3>
                      {!m.isRead && (
                        <span className="w-2 h-2 bg-indigo-500 rounded-full shadow-[0_0_8px_rgba(79,70,229,0.5)] animate-pulse"></span>
                      )}
                    </div>
                    <p className="text-xs font-bold text-gray-700 dark:text-gray-300 leading-relaxed">
                      {m.content}
                    </p>
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest pt-2 tabular-nums">
                      {m.date}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-8 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-100 dark:border-gray-700">
           <button 
             onClick={onClose}
             className="w-full py-5 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-600/20 active:scale-95 transition-all uppercase tracking-[0.2em] text-[11px]"
           >
             Close Center
           </button>
        </div>
      </div>
      
      <style>{`
        @keyframes swing {
          0% { transform: rotate(0deg); }
          20% { transform: rotate(15deg); }
          40% { transform: rotate(-10deg); }
          60% { transform: rotate(5deg); }
          80% { transform: rotate(-5deg); }
          100% { transform: rotate(0deg); }
        }
        .animate-swing {
          animation: swing 2s infinite ease-in-out;
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
};

export default MessageCenter;
