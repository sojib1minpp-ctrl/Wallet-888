
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User } from '../types';
import { ChevronLeft, ShieldCheck, TrendingUp, Skull } from 'lucide-react';

interface SnakeGameProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type?: any) => void;
  onBack: () => void;
}

const SnakeGame: React.FC<SnakeGameProps> = ({ user, setUser, addNotification, onBack }) => {
  // Requested multipliers for 14 levels
  const MULTIPLIERS = [1.5, 1.9, 2.3, 2.9, 3.3, 4.2, 5.3, 8.0, 9.0, 15.0, 20.0, 30.0, 40.0, 50.0];
  const LEVELS = MULTIPLIERS.length;
  const COLS = 5;
  const MIN_BET = 10;
  const MAX_BET = 25000;

  const [bet, setBet] = useState<number>(10);
  const [isGameActive, setIsGameActive] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [tower, setTower] = useState<('safe' | 'snake' | null)[][]>([]);
  const [revealed, setRevealed] = useState<boolean[][]>([]);
  const [gameOver, setGameOver] = useState(false);
  
  // Ref to track session profit to enforce the 200-300 limit
  const sessionProfit = useRef<number>(0);

  const resetTower = useCallback(() => {
    const newTower = Array.from({ length: LEVELS }, () => Array(COLS).fill(null));
    const newRevealed = Array.from({ length: LEVELS }, () => Array(COLS).fill(false));
    setTower(newTower);
    setRevealed(newRevealed);
    setCurrentLevel(0);
    setGameOver(false);
    setIsGameActive(false);
  }, [LEVELS, COLS]);

  useEffect(() => {
    resetTower();
  }, [resetTower]);

  const startGame = () => {
    if (user.balance < bet) {
      addNotification("আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই!", "error");
      return;
    }
    if (bet < MIN_BET) {
      addNotification(`সর্বনিম্ন বেড ৳${MIN_BET}`, "error");
      return;
    }

    setUser(prev => prev ? { 
      ...prev, 
      balance: prev.balance - bet, 
      totalTurnover: (prev.totalTurnover || 0) + bet 
    } : null);
    
    // Track total spent to calculate net profit
    sessionProfit.current -= bet;
    
    resetTower();
    setIsGameActive(true);
  };

  const handleBoxClick = (level: number, col: number) => {
    if (!isGameActive || gameOver || level !== currentLevel) return;

    /**
     * REQUESTED LOGIC:
     * 1. 1.5x is usually successful.
     * 2. Hard to go past 4x or 5x (Level index 5 or 6).
     * 3. Profit limit: 200-300 BDT. Beyond this, force all losses.
     */
    
    // Calculate current net profit (approximate using balance and deposits)
    const currentNetProfit = user.balance - (user.totalDeposits || 0);
    
    let isSnake = false;
    const rand = Math.random();

    // Forced Loss Condition (Capping profit at ~250 BDT)
    if (currentNetProfit > 250) {
      isSnake = true;
    } else {
      if (level === 0) {
        // High success for 1.5x (85% safe)
        isSnake = rand < 0.15;
      } else if (level < 4) {
        // Medium difficulty for middle levels (60% safe)
        isSnake = rand < 0.40;
      } else if (level < 6) {
        // Significantly harder (20% safe)
        isSnake = rand < 0.80;
      } else {
        // Extremely rare to go beyond 5x (5% safe)
        isSnake = rand < 0.95;
      }
    }
    
    setRevealed(prev => {
      const next = prev.map(row => [...row]);
      next[level][col] = true;
      return next;
    });
    
    setTower(prev => {
      const next = prev.map(row => [...row]);
      next[level][col] = isSnake ? 'snake' : 'safe';
      return next;
    });

    if (isSnake) {
      setGameOver(true);
      setIsGameActive(false);
      addNotification("সাপে কামড় দিয়েছে! আপনি লস করেছেন।", "error");
    } else {
      if (level === LEVELS - 1) {
        // Grand win
        const finalWin = bet * MULTIPLIERS[LEVELS - 1];
        setGameOver(true);
        setIsGameActive(false);
        setUser(prev => prev ? { ...prev, balance: prev.balance + finalWin } : null);
        addNotification(`চমৎকার! আপনি ৫০ গুণ জিতেছেন: ৳${finalWin.toFixed(2)}`, "success");
      } else {
        setCurrentLevel(level + 1);
        addNotification("সাবাস! ব্যাঙ পাওয়া গেছে, পরের ধাপে যান।", "success");
      }
    }
  };

  const cashOut = () => {
    if (!isGameActive || currentLevel === 0 || gameOver) return;
    
    const winAmt = bet * MULTIPLIERS[currentLevel - 1];
    setUser(prev => prev ? { ...prev, balance: prev.balance + winAmt } : null);
    
    sessionProfit.current += winAmt;
    setIsGameActive(false);
    setGameOver(true);
    addNotification(`আপনি ৳${winAmt.toFixed(2)} ক্যাশ আউট করেছেন!`, "success");
  };

  const currentPotentialWin = isGameActive && currentLevel > 0 ? (bet * MULTIPLIERS[currentLevel - 1]) : 0;

  if (tower.length === 0) return <div className="fixed inset-0 bg-[#0a0f1d] flex items-center justify-center text-white font-black">লোডিং...</div>;

  return (
    <div className="fixed inset-0 bg-[#0a0f1d] text-white flex flex-col overflow-hidden font-sans z-[100]">
      {/* Header */}
      <div className="p-4 flex items-center justify-between bg-[#0b1322]/95 backdrop-blur-2xl z-10 border-b border-white/5 shadow-2xl shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 bg-rose-600/20 rounded-xl text-rose-400 hover:text-white active:scale-90 transition-all">
            <ChevronLeft size={20} />
          </button>
          <div className="flex flex-col">
            <span className="text-xs font-black text-rose-500 uppercase tracking-tighter">SNAKE TOWER</span>
            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">WALLET 888</span>
          </div>
        </div>
        
        <div className="flex flex-col items-end">
          <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-0.5 leading-none">Balance</span>
          <div className="flex items-center gap-1.5 text-indigo-400 font-black">
            <span className="text-xs">৳</span>
            <span className="text-base tabular-nums">{user.balance.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Main Game Grid with Scrollable Tower */}
      <div className="flex-1 overflow-y-auto px-6 py-10 no-scrollbar flex flex-col items-center">
        <div className="flex flex-col gap-2 w-full max-w-[320px]">
          {Array.from({ length: LEVELS }).map((_, idx) => {
            const levelIdx = LEVELS - 1 - idx; 
            const isCurrent = currentLevel === levelIdx && isGameActive;
            const isCompleted = currentLevel > levelIdx;

            return (
              <div key={levelIdx} className={`flex gap-3 items-center transition-all duration-300 ${isCurrent ? 'scale-[1.02] z-20' : 'scale-100 z-10 opacity-80'}`}>
                {/* Multiplier Tag on the left */}
                <div className={`w-16 shrink-0 py-2.5 rounded-xl text-[10px] font-black text-center border shadow-lg transition-all ${
                   isCompleted ? 'bg-green-500/10 border-green-500/30 text-green-500' : 
                   isCurrent ? 'bg-indigo-600 border-indigo-400 text-white animate-pulse ring-4 ring-indigo-500/20' : 
                   'bg-gray-800/60 border-white/5 text-gray-500'
                }`}>
                  {MULTIPLIERS[levelIdx].toFixed(1)}x
                </div>

                {/* Boxes for this level */}
                <div className="flex-1 grid grid-cols-5 gap-2">
                  {Array.from({ length: COLS }).map((__, colIdx) => {
                    const content = tower[levelIdx][colIdx];
                    const isRevealed = revealed[levelIdx][colIdx];
                    
                    return (
                      <button
                        key={colIdx}
                        disabled={!isCurrent || gameOver}
                        onClick={() => handleBoxClick(levelIdx, colIdx)}
                        className={`aspect-square rounded-xl flex items-center justify-center text-2xl transition-all duration-300 relative border-2 ${
                          isRevealed 
                            ? (content === 'safe' ? 'bg-green-500 border-green-300 shadow-[0_0_15px_rgba(34,197,94,0.4)]' : 'bg-rose-600 border-rose-400 shadow-[0_0_15px_rgba(225,29,72,0.4)]')
                            : (isCurrent ? 'bg-indigo-900/40 border-indigo-500/50 hover:bg-indigo-700/60 active:scale-90' : (isCompleted ? 'bg-gray-800/50 border-white/5 opacity-60' : 'bg-gray-800/20 border-white/5 opacity-20'))
                        }`}
                      >
                        {isRevealed && content === 'safe' && <span className="animate-bounce">🐸</span>}
                        {isRevealed && content === 'snake' && <Skull className="text-white animate-shake" size={18} />}
                        {isCurrent && !isRevealed && <div className="absolute inset-0 bg-indigo-500/10 rounded-lg animate-pulse"></div>}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Control Panel */}
      <div className="p-6 pb-12 bg-[#0f172a] rounded-t-[3rem] border-t border-white/10 shadow-[0_-20px_50px_rgba(0,0,0,0.6)] space-y-5 shrink-0">
        <div className="flex items-center justify-between px-3">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1.5">Potential Win</span>
            <span className={`text-xl font-black tabular-nums transition-colors ${currentPotentialWin > 0 ? 'text-green-500' : 'text-gray-700'}`}>
              ৳ {currentPotentialWin.toFixed(2)}
            </span>
          </div>
          <div className="flex items-center gap-2 bg-indigo-500/10 px-3 py-1.5 rounded-full border border-indigo-500/20">
            <TrendingUp size={14} className="text-indigo-400" />
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Level {currentLevel + 1}</span>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex-[1.2] relative bg-[#080d17] rounded-[1.5rem] p-4 flex flex-col border border-white/5 shadow-inner">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1 ml-1 leading-none">Stake Amount</span>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xl font-black text-gray-700">৳</span>
              <input 
                type="number"
                value={bet}
                onChange={(e) => setBet(Math.max(0, parseFloat(e.target.value) || 0))}
                disabled={isGameActive}
                className="bg-transparent w-full font-black text-xl text-white outline-none tabular-nums"
                placeholder="10"
              />
            </div>
          </div>

          {!isGameActive || gameOver ? (
            <button 
              onClick={startGame}
              className="flex-1 bg-gradient-to-br from-indigo-600 to-indigo-700 text-white font-black py-4 rounded-[1.5rem] shadow-xl uppercase tracking-[0.2em] text-[11px] active:scale-95 border-b-4 border-indigo-900 transition-all hover:brightness-110"
            >
              Start Game
            </button>
          ) : (
            <button 
              onClick={cashOut}
              disabled={currentLevel === 0}
              className={`flex-1 flex flex-col items-center justify-center rounded-[1.5rem] py-4 shadow-xl active:scale-95 border-b-4 transition-all ${currentLevel === 0 ? 'bg-gray-800 text-gray-600 border-gray-900 cursor-not-allowed' : 'bg-gradient-to-br from-amber-500 to-orange-600 text-white border-amber-800 shadow-amber-500/30'}`}
            >
              <span className="font-black uppercase tracking-widest text-[9px] leading-none mb-1">Take Win</span>
              <span className="font-black text-sm tabular-nums leading-none">৳ {currentPotentialWin.toFixed(0)}</span>
            </button>
          )}
        </div>

        <div className="flex justify-center items-center gap-2 opacity-30">
           <ShieldCheck size={14} className="text-green-500" />
           <span className="text-[9px] font-black uppercase tracking-[0.3em]">Encrypted Provably Fair System</span>
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-2px); }
          75% { transform: translateX(2px); }
        }
        .animate-shake {
          animation: shake 0.2s ease-in-out infinite;
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default SnakeGame;
