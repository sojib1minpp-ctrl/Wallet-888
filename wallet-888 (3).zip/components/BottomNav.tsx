import React from 'react';
import { Tab } from '../types';
import { LayoutGrid, Download, Upload, Clock, User as UserIcon } from 'lucide-react';

interface BottomNavProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const tabs: { id: Tab; label: string; icon: any }[] = [
    { id: 'games', label: 'GAMES', icon: LayoutGrid },
    { id: 'deposit', label: 'DEPOSIT', icon: Download },
    { id: 'withdraw', label: 'WITHDRAW', icon: Upload },
    { id: 'history', label: 'HISTORY', icon: Clock },
    { id: 'profile', label: 'PROFILE', icon: UserIcon },
  ];

  return (
    <div className="h-[76px] bg-white/95 dark:bg-[#0c0f1d]/95 backdrop-blur-2xl border-t border-gray-100 dark:border-gray-800 flex items-center justify-around px-2 z-[100] w-full shrink-0 rounded-t-[2.5rem] shadow-[0_-10px_40px_rgba(0,0,0,0.1)]">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center justify-center w-full h-full transition-all duration-300 relative ${
              isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-400 dark:text-gray-500'
            }`}
          >
            {isActive && (
              <span className="absolute top-1 w-8 h-1 bg-indigo-600 dark:bg-indigo-400 rounded-full shadow-[0_2px_10px_rgba(79,70,229,0.4)]"></span>
            )}
            <Icon size={22} strokeWidth={isActive ? 2.5 : 2} className={`transition-transform duration-300 ${isActive ? 'scale-110 -translate-y-1' : ''}`} />
            <span className={`text-[8px] font-black mt-1 uppercase tracking-[0.15em] transition-opacity duration-300 ${isActive ? 'opacity-100' : 'opacity-60'}`}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};

export default BottomNav;