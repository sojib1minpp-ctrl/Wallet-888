
import React, { useEffect, useState } from 'react';
import { Notification } from '../types';
import { CheckCircle, AlertCircle, Info, X } from 'lucide-react';

interface Props {
  notification: Notification;
  onClose: (id: string) => void;
}

const NotificationToast: React.FC<Props> = ({ notification, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Small delay to trigger animation
    const raf = requestAnimationFrame(() => setVisible(true));
    
    const timer = setTimeout(() => {
      setVisible(false);
      // Wait for exit animation before calling parent onClose
      setTimeout(() => onClose(notification.id), 500);
    }, 4000);

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(timer);
    };
  }, [notification.id, onClose]);

  const icons = {
    success: <CheckCircle className="text-green-500 shrink-0" size={20} />,
    error: <AlertCircle className="text-rose-500 shrink-0" size={20} />,
    info: <Info className="text-blue-500 shrink-0" size={20} />
  };

  const bgStyles = {
    success: 'bg-white dark:bg-gray-800 border-green-500',
    error: 'bg-white dark:bg-gray-800 border-rose-500',
    info: 'bg-white dark:bg-gray-800 border-blue-500'
  };

  const handleManualClose = () => {
    setVisible(false);
    setTimeout(() => onClose(notification.id), 300);
  };

  return (
    <div 
      className={`relative mt-3 w-[90%] max-w-sm pointer-events-auto transform transition-all duration-500 ease-out flex items-center justify-between gap-3 px-5 py-4 rounded-2xl border-l-4 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.15)] ${
        visible 
          ? 'translate-y-0 opacity-100 scale-100' 
          : '-translate-y-16 opacity-0 scale-95'
      } ${bgStyles[notification.type]}`}
    >
      <div className="flex items-center gap-3 overflow-hidden">
        {icons[notification.type]}
        <p className="text-[13px] font-black text-gray-800 dark:text-white truncate">
          {notification.message}
        </p>
      </div>
      
      <button 
        onClick={handleManualClose}
        className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors text-gray-400"
      >
        <X size={16} strokeWidth={3} />
      </button>
    </div>
  );
};

export default NotificationToast;
