
import React, { useState } from 'react';
import { User } from '../types';
import { ChevronLeft, UserCheck, ShieldCheck } from 'lucide-react';

interface SettingsProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  onBack: () => void;
  addNotification: (msg: string, type?: any) => void;
}

const SettingsView: React.FC<SettingsProps> = ({ user, setUser, onBack, addNotification }) => {
  const [firstName, setFirstName] = useState(user.firstName || '');
  const [lastName, setLastName] = useState(user.lastName || '');
  const [nid, setNid] = useState(user.nid || '');
  const [dob, setDob] = useState(user.dob || '');

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (user.isVerified) {
      addNotification("Account already verified!", "info");
      onBack();
      return;
    }
    
    setUser({ 
      ...user, 
      isVerified: true,
      firstName,
      lastName,
      nid,
      dob
    });
    addNotification("Verification submitted successfully!", "success");
    onBack();
  };

  if (user.isVerified) {
    return (
      <div className="space-y-6">
        <button onClick={onBack} className="flex items-center gap-1 text-gray-500 dark:text-gray-400 font-bold">
          <ChevronLeft size={20} /> Back
        </button>
        <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-xl flex flex-col items-center">
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
            <ShieldCheck size={48} />
          </div>
          <h2 className="text-2xl font-bold dark:text-white">Account Verified</h2>
          <p className="text-gray-500 mt-2 px-10">Your identity has been confirmed. Security settings are now locked for your protection.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1 text-gray-500 dark:text-gray-400 font-bold">
          <ChevronLeft size={20} /> Back
        </button>
        <h2 className="text-xl font-bold dark:text-white">Account Security</h2>
        <div className="w-10"></div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-700">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
            <UserCheck size={28} />
          </div>
          <div>
            <h3 className="font-bold text-lg dark:text-white leading-none">KYC Verification</h3>
            <p className="text-xs text-gray-500 mt-1">Submit documents to unlock higher limits</p>
          </div>
        </div>

        <form onSubmit={handleVerify} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">First Name</label>
              <input required type="text" value={firstName} onChange={e => setFirstName(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-gray-700 dark:text-white border-transparent focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="John" />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Last Name</label>
              <input required type="text" value={lastName} onChange={e => setLastName(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-gray-700 dark:text-white border-transparent focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Doe" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">ID Card / NID Number</label>
            <input required type="text" value={nid} onChange={e => setNid(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-gray-700 dark:text-white border-transparent focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="1234567890" />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Date of Birth</label>
            <input required type="date" value={dob} onChange={e => setDob(e.target.value)} className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-gray-700 dark:text-white border-transparent focus:ring-2 focus:ring-indigo-500 outline-none" />
          </div>

          <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg mt-4 transition-transform active:scale-95">
            Submit for Verification
          </button>
        </form>
      </div>
    </div>
  );
};

export default SettingsView;
