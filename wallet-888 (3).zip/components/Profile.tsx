
import React, { useState } from 'react';
import { User, AppSettings, BonusCode } from '../types';
import { Settings, Share2, Crown, ChevronRight, Phone, MessageCircle, DownloadCloud, Gift, Copy, Camera, ShieldCheck, Lock } from 'lucide-react';
import SettingsView from './Settings';
import ReferView from './Refer';
import FreeSpin from './FreeSpin';
import BonusCodeView from './BonusCode';
import AvatarSelect from './AvatarSelect';

interface ProfileProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  bonusCodes: BonusCode[];
  setBonusCodes: React.Dispatch<React.SetStateAction<BonusCode[]>>;
  addNotification: (msg: string, type?: any) => void;
  updateBalance: (amt: number) => void;
  settings: AppSettings;
}

const Profile: React.FC<ProfileProps> = ({ user, setUser, bonusCodes, setBonusCodes, addNotification, updateBalance, settings }) => {
  const [subView, setSubView] = useState<'main' | 'settings' | 'refer' | 'spin' | 'bonus' | 'avatar'>('main');

  if (subView === 'settings') return <SettingsView user={user} setUser={setUser} addNotification={addNotification} onBack={() => setSubView('main')} />;
  if (subView === 'refer') return <ReferView user={user} onBack={() => setSubView('main')} addNotification={addNotification} />;
  if (subView === 'spin') return <FreeSpin user={user} setUser={setUser} onBack={() => setSubView('main')} addNotification={addNotification} updateBalance={updateBalance} />;
  if (subView === 'bonus') return <BonusCodeView user={user} setUser={setUser} bonusCodes={bonusCodes} setBonusCodes={setBonusCodes} onBack={() => setSubView('main')} addNotification={addNotification} updateBalance={updateBalance} />;
  if (subView === 'avatar') return (
    <AvatarSelect 
      user={user} 
      onBack={() => setSubView('main')} 
      onSelect={(url) => {
        setUser({ ...user, avatarUrl: url });
        setSubView('main');
        addNotification("Avatar updated!", "success");
      }} 
    />
  );

  const handleCopyUID = () => {
    navigator.clipboard.writeText(user.uid);
    addNotification("UID Copied!", "info");
  };

  const currentAvatar = user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-black dark:text-white">Profile</h2>
        <div className="flex gap-2">
          <button onClick={() => setSubView('refer')} className="p-3 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-2xl shadow-sm border border-white dark:border-gray-700">
            <Share2 size={20} strokeWidth={2.5} />
          </button>
          <button onClick={() => setSubView('settings')} className="p-3 bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-2xl shadow-sm border border-white dark:border-gray-700">
            <Settings size={20} strokeWidth={2.5} />
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-[3rem] p-8 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.08)] border border-gray-100 dark:border-gray-700 flex flex-col items-center">
        <div className="relative group cursor-pointer" onClick={() => setSubView('avatar')}>
          <div className="w-28 h-28 rounded-full border-4 border-white dark:border-gray-700 overflow-hidden shadow-xl ring-8 ring-indigo-50 dark:ring-indigo-900/10 transition-transform group-hover:scale-105">
            <img 
              src={currentAvatar} 
              alt="Avatar" 
              className="w-full h-full object-cover bg-indigo-50 dark:bg-gray-700" 
            />
          </div>
          <div className="absolute -bottom-1 -right-1 bg-amber-400 p-2 rounded-full border-4 border-white dark:border-gray-800 shadow-lg">
            <Crown size={14} className="text-white fill-white" />
          </div>
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 rounded-full flex items-center justify-center transition-opacity">
            <Camera size={24} className="text-white" />
          </div>
        </div>

        <div className="mt-8 text-center">
          <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight leading-none mb-1">{user.email ? user.email.split('@')[0] : 'Member'}</h3>
          <p className="text-sm font-bold text-gray-400 mb-6">{user.phone}</p>
          
          <div 
            onClick={handleCopyUID}
            className="flex items-center gap-3 px-6 py-2.5 bg-[#f8f9ff] dark:bg-gray-700/50 rounded-full cursor-pointer hover:bg-indigo-50 dark:hover:bg-gray-700 transition-all border border-indigo-100 dark:border-gray-600 shadow-inner group"
          >
            <span className="text-[11px] font-black text-gray-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 uppercase tracking-widest">UID: <span className="text-indigo-600 dark:text-white font-mono">{user.uid}</span></span>
            <Copy size={12} className="text-indigo-600 dark:text-indigo-400" />
          </div>
        </div>
        
        <div className="mt-8 flex gap-4 w-full">
           <div className="flex-1 bg-green-50 dark:bg-green-900/10 p-4 rounded-3xl border border-green-100 dark:border-green-800/50 flex flex-col items-center gap-1">
              <ShieldCheck size={20} className="text-green-600" />
              <span className="text-[9px] font-black text-green-700 dark:text-green-400 uppercase tracking-widest">Verified</span>
           </div>
           <div className="flex-1 bg-blue-50 dark:bg-blue-900/10 p-4 rounded-3xl border border-blue-100 dark:border-blue-800/50 flex flex-col items-center gap-1">
              <Lock size={20} className="text-blue-600" />
              <span className="text-[9px] font-black text-blue-700 dark:text-blue-400 uppercase tracking-widest">Secure</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <button 
          onClick={() => setSubView('spin')}
          className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center gap-3 active:scale-95 transition-all hover:shadow-md"
        >
          <div className="w-14 h-14 bg-amber-100 dark:bg-amber-900/30 rounded-[1.5rem] flex items-center justify-center text-amber-600 dark:text-amber-400 shadow-inner">
            <Gift size={28} strokeWidth={2.5} />
          </div>
          <span className="text-xs font-black text-gray-800 dark:text-white uppercase tracking-widest">Free Spin</span>
        </button>
        <button 
          onClick={() => setSubView('bonus')}
          className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center gap-3 active:scale-95 transition-all hover:shadow-md"
        >
          <div className="w-14 h-14 bg-pink-100 dark:bg-pink-900/30 rounded-[1.5rem] flex items-center justify-center text-pink-600 dark:text-pink-400 shadow-inner">
            <Gift size={28} strokeWidth={2.5} />
          </div>
          <span className="text-xs font-black text-gray-800 dark:text-white uppercase tracking-widest">Bonus Code</span>
        </button>
      </div>

      <div className="space-y-4">
        <a href={settings.telegramLink} target="_blank" rel="noreferrer" className="w-full flex items-center justify-between bg-[#24A1DE] text-white p-5 rounded-[2rem] shadow-xl active:scale-95 transition-transform group">
          <div className="flex items-center gap-4">
            <MessageCircle size={32} />
            <div className="text-left">
              <p className="font-black text-lg uppercase">Telegram</p>
              <p className="text-[10px] opacity-80 uppercase font-bold tracking-[0.2em]">Live Support</p>
            </div>
          </div>
          <ChevronRight strokeWidth={3} />
        </a>

        <a href={settings.whatsappLink} target="_blank" rel="noreferrer" className="w-full flex items-center justify-between bg-[#25D366] text-white p-5 rounded-[2rem] shadow-xl active:scale-95 transition-transform group">
          <div className="flex items-center gap-4">
            <Phone size={32} />
            <div className="text-left">
              <p className="font-black text-lg uppercase">WhatsApp</p>
              <p className="text-[10px] opacity-80 uppercase font-bold tracking-[0.2em]">Contact Us</p>
            </div>
          </div>
          <ChevronRight strokeWidth={3} />
        </a>

        <a href={settings.downloadLink} target="_blank" rel="noreferrer" className="w-full flex items-center justify-between bg-indigo-600 text-white p-5 rounded-[2rem] shadow-xl active:scale-95 transition-transform group">
          <div className="flex items-center gap-4">
            <DownloadCloud size={32} />
            <div className="text-left">
              <p className="font-black text-lg uppercase">App Download</p>
              <p className="text-[10px] opacity-80 uppercase font-bold tracking-[0.2em]">Latest Version</p>
            </div>
          </div>
          <ChevronRight strokeWidth={3} />
        </a>
      </div>
    </div>
  );
};

export default Profile;
