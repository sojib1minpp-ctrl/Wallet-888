
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { User } from '../types';
import { ChevronLeft, ShieldCheck, Zap, Sparkles, Volume2, VolumeX, Trophy, Info, Star } from 'lucide-react';

interface SuperSlotProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type?: any) => void;
  onBack: () => void;
}

const SuperSlot: React.FC<SuperSlotProps> = ({ user, setUser, addNotification, onBack }) => {
  const [bet, setBet] = useState<number>(10);
  const [reels, setReels] = useState<number[]>([7, 7, 7]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showWinCelebration, setShowWinCelebration] = useState(false);
  
  const MIN_BET = 10;
  const MAX_BET = 50000;

  const playSound = useCallback((type: 'spin' | 'win' | 'lose') => {
    if (!soundEnabled) return;
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'spin') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    } else if (type === 'win') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(100, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(50, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
    }

    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  }, [soundEnabled]);

  const spinReels = () => {
    if (user.balance < bet) {
      addNotification("আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই!", "error");
      return;
    }
    if (bet < MIN_BET) {
      addNotification(`সর্বনিম্ন বেড ৳${MIN_BET}`, "error");
      return;
    }

    setIsSpinning(true);
    setLastWin(null);
    setShowWinCelebration(false);
    playSound('spin');

    setUser(prev => prev ? { 
      ...prev, 
      balance: prev.balance - bet,
      totalTurnover: (prev.totalTurnover || 0) + bet 
    } : null);

    let cycles = 0;
    const interval = setInterval(() => {
      setReels([
        Math.floor(Math.random() * 10),
        Math.floor(Math.random() * 10),
        Math.floor(Math.random() * 10)
      ]);
      cycles++;
      if (cycles > 25) {
        clearInterval(interval);
        finalizeSpin();
      }
    }, 80);
  };

  const finalizeSpin = () => {
    const random = Math.random() * 10000; // Increased range for ultra-rare jackpot
    let finalReels: number[];
    let winAmount = 0;

    if (random < 1) { // 0.01% chance for 90x Jackpot (Rare)
       finalReels = [9,9,9];
       winAmount = bet * 90;
    } else if (random < 10) { // 0.1% chance for high tier (2, 7, 8)
       const highRoll = Math.random();
       if (highRoll < 0.33) { finalReels = [2,2,2]; winAmount = bet * 6; }
       else if (highRoll < 0.66) { finalReels = [7,7,7]; winAmount = bet * 7; }
       else { finalReels = [8,8,8]; winAmount = bet * 8; }
    } else if (random < 50) { // 0.4% chance for 3x 5s
       finalReels = [5,5,5];
       winAmount = bet * (3 + Math.random()); 
    } else if (random < 120) { // 0.7% chance for 3x 3s
       finalReels = [3,3,3];
       winAmount = bet * (2 + Math.random()); 
    } else if (random < 250) { // 1.3% chance for 3x 1s
       finalReels = [1,1,1];
       winAmount = bet * 1; 
    } else if (random < 3000) { // 27.5% chance for NEAR MISS
       const matchNum = Math.floor(Math.random() * 10);
       let diffNum = Math.floor(Math.random() * 10);
       while (diffNum === matchNum) diffNum = Math.floor(Math.random() * 10);
       const pos = Math.floor(Math.random() * 3);
       finalReels = [matchNum, matchNum, matchNum];
       finalReels[pos] = diffNum;
       winAmount = 0;
    } else {
       finalReels = [
        Math.floor(Math.random() * 10),
        Math.floor(Math.random() * 10),
        Math.floor(Math.random() * 10)
      ];
      if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
        finalReels[2] = (finalReels[2] + 1) % 10;
      }
      winAmount = 0;
    }

    setReels(finalReels);
    setIsSpinning(false);
    
    if (winAmount > 0) {
      setUser(prev => prev ? { ...prev, balance: prev.balance + winAmount } : null);
      setLastWin(winAmount);
      playSound('win');
      if (winAmount >= bet) {
        setShowWinCelebration(true);
        addNotification(`চমৎকার! আপনি জিতেছেন ৳${winAmount.toFixed(2)}`, "success");
      } else {
        addNotification(`আপনি ৳${winAmount.toFixed(2)} ফেরত পেয়েছেন।`, "info");
      }
    } else {
      playSound('lose');
      addNotification("আপনি লস করেছেন! আবার চেষ্টা করুন।", "error");
    }
  };

  return (
    <div className="fixed inset-0 bg-[#0c051a] text-white flex flex-col overflow-hidden font-sans z-[100] animate-in fade-in duration-500">
      {/* Header */}
      <div className="p-4 flex items-center justify-between bg-[#1a0b3c]/80 backdrop-blur-xl z-[110] border-b border-white/5 shadow-2xl shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 bg-purple-600/20 rounded-xl text-purple-400 hover:text-white active:scale-90 transition-all">
            <ChevronLeft size={20} />
          </button>
          <div className="flex flex-col">
            <span className="text-xs font-black text-purple-500 uppercase tracking-tighter">SUPER SLOT</span>
            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">WALLET 888</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-full transition-all border ${soundEnabled ? 'bg-indigo-600/20 border-indigo-500/30 text-indigo-400' : 'bg-gray-800/20 border-white/5 text-gray-600'}`}
          >
            {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
          <div className="flex flex-col items-end">
            <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">Balance</span>
            <div className="flex items-center gap-1.5 text-indigo-400 font-black">
              <span className="text-xs">৳</span>
              <span className="text-base tabular-nums">{user.balance.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col items-center pt-6 pb-32 space-y-6 relative px-6">
        
        {/* Beautiful Payout Rules Table */}
        <div className="w-full max-w-[340px] bg-gradient-to-b from-[#1a0b3c] to-[#0c051a] backdrop-blur-md rounded-[2.5rem] border border-white/10 p-6 shadow-2xl animate-in slide-in-from-top duration-700">
          <div className="flex items-center justify-between mb-4 px-1">
             <div className="flex items-center gap-2">
                <Zap size={14} className="text-amber-400 fill-amber-400" />
                <span className="text-[10px] font-black text-amber-400 uppercase tracking-[0.2em]">Multiplier Info</span>
             </div>
             <div className="flex items-center gap-1 text-purple-400">
                <Star size={10} className="fill-purple-400 animate-pulse" />
                <span className="text-[8px] font-black uppercase tracking-widest">JACKPOT ACTIVE</span>
             </div>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {[
              { nums: [8,8,8], label: '8x Multiplier', mult: '8x' },
              { nums: [7,7,7], label: '7x Multiplier', mult: '7x' },
              { nums: [2,2,2], label: '6x Multiplier', mult: '6x' },
              { nums: [5,5,5], label: '3x - 4x Win', mult: '3x-4x' },
              { nums: [3,3,3], label: '2x - 3x Win', mult: '2x-3x' },
              { nums: [1,1,1], label: 'Money Back', mult: '1x' },
            ].map((rule, idx) => (
              <div key={idx} className="bg-black/30 p-2.5 rounded-2xl border border-white/5 flex flex-col gap-1.5 group hover:bg-white/5 transition-colors">
                <div className="flex gap-0.5 justify-center">
                  {rule.nums.map((n, i) => (
                    <span key={i} className="w-5 h-5 flex items-center justify-center bg-indigo-600/30 text-white font-black rounded-lg text-[9px] border border-white/10">{n}</span>
                  ))}
                </div>
                <div className="flex justify-between items-center px-1">
                  <span className="text-[8px] font-bold text-gray-500 uppercase truncate pr-1">{rule.label}</span>
                  <span className="text-[10px] font-black text-green-400">{rule.mult}</span>
                </div>
              </div>
            ))}
            
            {/* Ultra Rare Jackpot Row */}
            <div className="col-span-2 bg-gradient-to-r from-amber-500/10 via-amber-500/20 to-amber-500/10 p-4 rounded-3xl border border-amber-500/30 flex items-center justify-between mt-2 shadow-[0_0_20px_rgba(245,158,11,0.1)]">
               <div className="flex items-center gap-3">
                  <div className="flex gap-0.5">
                    {[9,9,9].map((n, i) => (
                      <span key={i} className="w-7 h-7 flex items-center justify-center bg-amber-500 text-black font-black rounded-lg text-xs shadow-[0_0_10px_rgba(245,158,11,0.5)]">{n}</span>
                    ))}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest leading-none mb-1">JACKPOT 90X</span>
                    <span className="text-[7px] font-bold text-amber-500/60 uppercase tracking-widest">Ultra Rare Chance</span>
                  </div>
               </div>
               <div className="flex flex-col items-end">
                 <span className="text-lg font-black text-amber-400 tracking-tighter">90x</span>
                 <span className="text-[7px] font-bold text-gray-500 uppercase tracking-widest">Between</span>
               </div>
            </div>
          </div>
        </div>

        {/* Slot Machine Area */}
        <div className="relative w-full max-w-[340px] bg-gradient-to-b from-[#1e1345] to-[#0c051a] p-8 rounded-[4rem] border-[12px] border-[#2c1d5b] shadow-[0_0_80px_rgba(0,0,0,0.8),inset_0_0_40px_rgba(139,92,246,0.3)]">
          <div className="bg-black/80 rounded-[2.5rem] p-4 border border-white/5 shadow-inner">
            <div className="flex justify-between items-center gap-3">
              {reels.map((val, idx) => (
                <div 
                  key={idx} 
                  className={`flex-1 aspect-[4/5] bg-gradient-to-b from-gray-900 via-black to-gray-900 rounded-3xl flex items-center justify-center text-6xl font-black text-white shadow-2xl border-x border-white/5 transition-all duration-100 ${isSpinning ? 'animate-pulse blur-[1px] scale-95' : 'scale-100'}`}
                >
                  <span className="drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]">{val}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-purple-500/60 to-transparent pointer-events-none -translate-y-1/2 z-10"></div>
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#2c1d5b] px-6 py-1 rounded-full border-t border-white/20 shadow-lg">
            <span className="text-[10px] font-black text-purple-300 uppercase tracking-[0.3em]">PROVABLY FAIR</span>
          </div>
        </div>

        {/* Status Display */}
        <div className="h-12 flex items-center justify-center">
          {lastWin !== null && lastWin > 0 && !showWinCelebration && (
            <div className="bg-green-500/10 border border-green-500/30 px-8 py-2 rounded-full flex items-center gap-3 animate-in zoom-in-95 duration-300">
              <Sparkles size={16} className="text-green-500" />
              <span className="text-sm font-black text-green-500 uppercase tracking-widest tabular-nums">
                WIN: ৳{lastWin.toFixed(2)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Win Modal */}
      {showWinCelebration && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 animate-in fade-in duration-500">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={() => setShowWinCelebration(false)}></div>
          <div className="relative w-full max-w-sm overflow-hidden bg-gradient-to-b from-indigo-900 to-black rounded-[3rem] border-4 border-amber-500 shadow-[0_0_100px_rgba(245,158,11,0.3)] animate-in zoom-in duration-300">
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none"></div>
            <div className="p-10 text-center space-y-6">
              <div className="relative inline-block">
                <Trophy size={80} className="text-amber-500 mx-auto drop-shadow-[0_0_20px_rgba(245,158,11,0.6)] animate-bounce" />
                <Sparkles size={24} className="absolute -top-2 -right-4 text-amber-400 animate-pulse" />
              </div>
              <div className="space-y-2">
                <h3 className="text-4xl font-black text-white tracking-tighter uppercase leading-none italic">WINNER!</h3>
                <p className="text-[10px] font-black text-amber-500/80 uppercase tracking-[0.4em]">JACKPOT PAYOUT</p>
              </div>
              <div className="bg-white/10 rounded-[2rem] p-6 border border-white/10 shadow-inner">
                <span className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Total Credited</span>
                <span className="text-5xl font-black text-amber-400 tabular-nums leading-none">৳{lastWin?.toFixed(2)}</span>
              </div>
              <button onClick={() => setShowWinCelebration(false)} className="w-full bg-amber-500 hover:bg-amber-600 text-black font-black py-4 rounded-2xl shadow-xl transition-all active:scale-95 uppercase tracking-widest text-sm">Claim Now</button>
            </div>
          </div>
        </div>
      )}

      {/* Control Panel */}
      <div className="p-8 pb-12 bg-[#0c051a] rounded-t-[3.5rem] border-t border-white/10 shadow-[0_-30px_60px_rgba(0,0,0,0.8)] space-y-6 shrink-0 z-[120]">
        <div className="flex items-center justify-between px-3">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1.5">Jackpot Bonus</span>
            <span className="text-xl font-black text-purple-500 tabular-nums">৳ {(bet * 90).toFixed(0)}</span>
          </div>
          <div className="flex items-center gap-2 bg-indigo-500/10 px-4 py-1.5 rounded-full border border-indigo-500/20">
            <Zap size={14} className="text-indigo-400" />
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">3 IN A ROW = WIN</span>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex-[1.2] relative bg-black/40 rounded-[1.8rem] p-4 flex flex-col border border-white/5 shadow-inner group">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1 leading-none">Stake Amount</span>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xl font-black text-gray-700">৳</span>
              <input 
                type="number"
                value={bet}
                onChange={(e) => setBet(Math.max(0, parseFloat(e.target.value) || 0))}
                disabled={isSpinning}
                className="bg-transparent w-full font-black text-2xl text-white outline-none tabular-nums"
                placeholder="10"
              />
            </div>
          </div>

          <button 
            onClick={spinReels}
            disabled={isSpinning}
            className={`flex-1 rounded-[1.8rem] flex flex-col items-center justify-center gap-1 transition-all active:scale-95 shadow-[0_15px_30px_rgba(0,0,0,0.4)] border-b-4 ${isSpinning ? 'bg-gray-800 border-gray-900 opacity-50' : 'bg-gradient-to-br from-purple-600 to-indigo-700 text-white border-purple-900 shadow-purple-600/30 hover:brightness-110'}`}
          >
            <span className="font-black uppercase tracking-[0.2em] text-[11px] leading-none mb-1">Spin Now</span>
            <span className="font-black text-sm tabular-nums leading-none">৳ {bet}</span>
          </button>
        </div>

        <div className="flex justify-center items-center gap-2 opacity-30">
           <ShieldCheck size={14} className="text-green-500" />
           <span className="text-[9px] font-black uppercase tracking-[0.3em]">SSL Provably Fair Enabled</span>
        </div>
      </div>
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default SuperSlot;
