
import React from 'react';
import { ChevronLeft, Check } from 'lucide-react';
import { User } from '../types';

interface AvatarSelectProps {
  user: User;
  onSelect: (url: string) => void;
  onBack: () => void;
}

const AvatarSelect: React.FC<AvatarSelectProps> = ({ user, onSelect, onBack }) => {
  // 15 cartoonish seeds for DiceBear Pixel Art or Avataaars
  const avatarSeeds = [
    'Felix', 'Aneka', 'Spooky', 'Garfield', 'Caspian',
    'Oliver', 'Luna', 'Simba', 'Milo', 'Nala',
    'Leo', 'Chloe', 'Max', 'Bella', 'Charlie'
  ];

  const getAvatarUrl = (seed: string) => `https://api.dicebear.com/7.x/pixel-art/svg?seed=${seed}`;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1 text-gray-500 dark:text-gray-400 font-bold">
          <ChevronLeft size={20} /> Back
        </button>
        <h2 className="text-xl font-black dark:text-white">Select Avatar</h2>
        <div className="w-10"></div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-700">
        <p className="text-center text-[10px] font-black text-gray-400 uppercase tracking-widest mb-6">Choose your cartoon character</p>
        
        <div className="grid grid-cols-3 gap-4">
          {avatarSeeds.map((seed) => {
            const url = getAvatarUrl(seed);
            const isSelected = user.avatarUrl === url;
            return (
              <button
                key={seed}
                onClick={() => onSelect(url)}
                className={`relative aspect-square rounded-2xl overflow-hidden border-4 transition-all hover:scale-105 active:scale-95 ${
                  isSelected ? 'border-indigo-600 ring-4 ring-indigo-50 dark:ring-indigo-900/20' : 'border-gray-50 dark:border-gray-700'
                }`}
              >
                <img src={url} alt={seed} className="w-full h-full object-cover bg-indigo-50 dark:bg-gray-700" />
                {isSelected && (
                  <div className="absolute inset-0 bg-indigo-600/20 flex items-center justify-center">
                    <div className="bg-indigo-600 text-white p-1 rounded-full shadow-lg">
                      <Check size={16} strokeWidth={3} />
                    </div>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
      
      <p className="text-center text-[11px] font-bold text-gray-400">
        This cartoon will be visible to everyone in the rankings.
      </p>
    </div>
  );
};

export default AvatarSelect;