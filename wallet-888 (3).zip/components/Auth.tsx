import React, { useState } from 'react';
import { User } from '../types';
import { Eye, EyeOff, Smartphone, Mail, Ticket, Lock, User as UserIcon, ShieldCheck } from 'lucide-react';
import { rtdb } from '../firebase';
import { ref, get, set, query, orderByChild, equalTo } from 'firebase/database';

interface AuthProps {
  onLogin: (user: User) => void;
  addNotification: (msg: string, type: 'success' | 'error' | 'info') => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin, addNotification }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [authMode, setAuthMode] = useState<'phone' | 'email'>('phone');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [promoCode, setPromoCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    if (password.length < 6) {
      addNotification('পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে!', 'error');
      return;
    }

    setLoading(true);

    const finalIdentifier = authMode === 'phone' ? `+880${identifier.replace(/^\+880/, '').replace(/^0/, '')}` : identifier.toLowerCase();

    try {
      if (isLogin) {
        // Admin Shortcut
        if (identifier === 'sojib1minpp@gmail.com' && password === '159632') {
          const adminRef = ref(rtdb, 'users/8888888');
          const adminSnap = await get(adminRef);
          if (adminSnap.exists()) {
             onLogin(adminSnap.val());
          } else {
             const adminUser: User = {
                id: 'admin_1', email: 'sojib1minpp@gmail.com', phone: '01827456782', password: '159632', 
                balance: 999999, uid: '8888888', isVerified: true, spinDaysRemaining: 0, 
                totalRefers: 0, refersDeposited: 0, totalEarned: 0, totalDeposits: 0, totalTurnover: 0, usedBonusCodes: []
              };
              await set(adminRef, adminUser);
              onLogin(adminUser);
          }
          addNotification('অ্যাডমিন হেডকোয়ার্টারে প্রবেশ করছেন...', 'success');
          setLoading(false);
          return;
        }

        // Search for user
        const usersRef = ref(rtdb, 'users');
        const snapshot = await get(usersRef);
        const users = snapshot.val() ? Object.values(snapshot.val()) as User[] : [];
        
        const foundUser = users.find(u => 
          (u.email.toLowerCase() === identifier.toLowerCase() || u.phone === finalIdentifier || u.phone === identifier) && 
          u.password === password
        );

        if (foundUser) {
          if (foundUser.isBlocked) {
            addNotification('আপনার অ্যাকাউন্টটি ব্লক করা হয়েছে!', 'error');
          } else {
            addNotification('লগইন সফল হয়েছে!', 'success');
            onLogin(foundUser);
          }
        } else {
          addNotification('ভুল তথ্য অথবা ইউজার খুঁজে পাওয়া যায়নি!', 'error');
        }
      } else {
        // Registration
        const usersRef = ref(rtdb, 'users');
        const snapshot = await get(usersRef);
        const users = snapshot.val() ? Object.values(snapshot.val()) as User[] : [];

        const emailExists = authMode === 'email' && users.some(u => u.email.toLowerCase() === finalIdentifier);
        const phoneExists = authMode === 'phone' && users.some(u => u.phone === finalIdentifier);

        if (emailExists || phoneExists) {
          addNotification('এই তথ্য দিয়ে ইতিমধ্যে একাউন্ট খোলা হয়েছে!', 'error');
        } else {
          const uid = Math.floor(1000000 + Math.random() * 9000000).toString();
          const newUser: User = {
            id: uid,
            email: authMode === 'email' ? finalIdentifier : '',
            phone: authMode === 'phone' ? finalIdentifier : '',
            password, 
            promoCode, 
            balance: 0, 
            uid, 
            isVerified: false,
            spinDaysRemaining: 0, 
            totalRefers: 0, 
            refersDeposited: 0,
            totalEarned: 0, 
            totalDeposits: 0, 
            totalTurnover: 0, 
            usedBonusCodes: []
          };
          await set(ref(rtdb, `users/${uid}`), newUser);
          addNotification('রেজিস্ট্রেশন সফল হয়েছে!', 'success');
          onLogin(newUser);
        }
      }
    } catch (err) {
      addNotification('সার্ভার ত্রুটি! আবার চেষ্টা করুন।', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#05070a] flex flex-col justify-center items-center p-6 transition-colors duration-200 relative overflow-hidden">
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-indigo-600/10 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-amber-500/10 rounded-full blur-[120px]"></div>

      <div className="max-w-md w-full bg-[#16181b]/90 backdrop-blur-3xl rounded-[3rem] shadow-[0_40px_100px_rgba(0,0,0,0.6)] p-10 border border-white/5 relative z-10 flex flex-col items-center">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-black text-white mb-2 uppercase tracking-[0.1em]">
            {isLogin ? 'LOGIN' : 'SIGN UP'}
          </h2>
          <p className="text-[10px] text-white/30 font-black uppercase tracking-[0.3em] flex items-center justify-center gap-2">
            <ShieldCheck size={12} className="text-indigo-500" /> Secure Wallet 888 Access
          </p>
        </div>

        <div className="flex bg-white/5 p-1 rounded-full mb-10 border border-white/5 w-full">
          <button type="button" onClick={() => { setAuthMode('phone'); setIdentifier(''); }} className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full text-[10px] font-black uppercase transition-all tracking-widest ${authMode === 'phone' ? 'bg-[#373a40] text-white shadow-lg' : 'text-white/30'}`}><Smartphone size={14} /> Phone</button>
          <button type="button" onClick={() => { setAuthMode('email'); setIdentifier(''); }} className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full text-[10px] font-black uppercase transition-all tracking-widest ${authMode === 'email' ? 'bg-[#373a40] text-white shadow-lg' : 'text-white/30'}`}><Mail size={14} /> Email</button>
        </div>

        <form onSubmit={handleAuth} className="space-y-6 w-full">
          <div className="space-y-2">
            <label className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Identity</label>
            <div className="relative group">
              {authMode === 'phone' && <div className="absolute left-6 top-1/2 -translate-y-1/2 text-white/40 font-black text-lg pointer-events-none">+880</div>}
              <input type={authMode === 'phone' ? 'tel' : 'email'} required value={identifier} onChange={(e) => setIdentifier(e.target.value)} className={`w-full ${authMode === 'phone' ? 'pl-20' : 'pl-8'} pr-14 py-5 rounded-[2rem] bg-white/5 text-white border border-white/10 outline-none focus:border-amber-400/50 font-bold text-lg shadow-inner transition-all placeholder:text-white/10`} placeholder={authMode === 'phone' ? "1XXXXXXXXX" : "username@email.com"} />
              <div className="absolute right-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-amber-400 transition-colors"><UserIcon size={20} /></div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Password</label>
            <div className="relative group">
              <input type={showPassword ? 'text' : 'password'} required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-8 py-5 rounded-[2rem] bg-white/5 text-white border border-white/10 outline-none focus:border-amber-400/50 pr-16 font-bold text-lg shadow-inner transition-all placeholder:text-white/10" placeholder="••••••••" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-6 top-1/2 -translate-y-1/2 text-white/20 hover:text-white transition-colors">{showPassword ? <EyeOff size={20} /> : <Eye size={20} />}</button>
            </div>
          </div>

          {!isLogin && (
            <div className="space-y-2 animate-in slide-in-from-top-4 duration-300">
              <label className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em] ml-4">Promo Code</label>
              <input type="text" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} className="w-full px-8 py-5 rounded-[2rem] bg-white/5 text-white border border-white/10 outline-none focus:border-amber-400/50 font-bold text-lg uppercase tracking-widest shadow-inner placeholder:text-white/10" placeholder="OPTIONAL" />
            </div>
          )}

          <button type="submit" disabled={loading} className={`w-full ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:scale-[1.02] active:scale-[0.98]'} bg-gradient-to-r from-[#fbbf24] to-[#c29107] text-[#05070a] font-black py-5 rounded-full shadow-[0_15px_30px_rgba(245,158,11,0.2)] transition-all mt-6 uppercase tracking-[0.2em] flex items-center justify-center gap-3 text-sm`}>
            {loading ? <div className="w-5 h-5 border-2 border-black/20 border-t-black rounded-full animate-spin"></div> : (isLogin ? 'Log In' : 'Join Now')}
          </button>
        </form>

        <div className="mt-10 text-center">
          <button type="button" onClick={() => { setIsLogin(!isLogin); setIdentifier(''); setPassword(''); }} className="text-amber-400/70 hover:text-amber-400 text-[10px] font-black uppercase tracking-[0.2em] transition-colors">
            {isLogin ? "Need an account? Sign Up" : 'Already have one? Login'}
          </button>
        </div>
      </div>
      <div className="mt-12 opacity-20 flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-white"></span><span className="text-[8px] font-black text-white uppercase tracking-[0.5em]">Wallet 888 Global Security</span><span className="w-1.5 h-1.5 rounded-full bg-white"></span></div>
    </div>
  );
};

export default Auth;