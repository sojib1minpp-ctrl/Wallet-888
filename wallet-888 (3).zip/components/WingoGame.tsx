
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { User } from '../types';
import { ChevronLeft, Headset, HelpCircle, ChevronRight, Trophy, Minus, Plus, Check, Frown, Volume2, VolumeX, ShieldCheck, X } from 'lucide-react';

interface GameResult {
  period: string;
  number: number;
  bigSmall: 'Big' | 'Small';
  color: string[];
}

interface UserBet {
  period: string;
  amount: number;
  type: string | number;
  status: 'pending' | 'win' | 'loss';
  winAmount?: number;
  resultNumber?: number;
}

interface ResultModal {
  isOpen: boolean;
  status: 'win' | 'loss';
  amount: number;
  type: string | number;
  period: string;
  multiplier: number;
}

interface WingoGameProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  addNotification: (msg: string, type?: any) => void;
  onBack: () => void;
}

const WingoGame: React.FC<WingoGameProps> = ({ user, setUser, addNotification, onBack }) => {
  const [activeTab, setActiveTab] = useState<'30s' | '1m' | '3m' | '5m'>('30s');
  // Removed 'chart' history tab - only Game and My History remain
  const [historyTab, setHistoryTab] = useState<'game' | 'my'>('game');
  const [timeLeft, setTimeLeft] = useState(0);
  const [history, setHistory] = useState<GameResult[]>([]);
  const [isNewResult, setIsNewResult] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  // Betting Modal States
  const [betModalOpen, setBetModalOpen] = useState(false);
  const [selectedBetType, setSelectedBetType] = useState<string | number | null>(null);
  const [modalBaseAmount, setModalBaseAmount] = useState(1);
  const [modalQuantity, setModalQuantity] = useState(1);
  const [modalXMultiplier, setModalXMultiplier] = useState(1);
  const [agreedToRules, setAgreedToRules] = useState(true);

  const [resultModal, setResultModal] = useState<ResultModal | null>(null);
  const [myBets, setMyBets] = useState<UserBet[]>([]);

  const soundEnabledRef = useRef(soundEnabled);
  useEffect(() => { soundEnabledRef.current = soundEnabled; }, [soundEnabled]);

  const durations = useMemo(() => ({ '30s': 30, '1m': 60, '3m': 180, '5m': 300 }), []);

  const speak = (text: string) => {
    if (!soundEnabledRef.current) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.4;
    window.speechSynthesis.speak(utterance);
  };

  /**
   * Sequential Period ID logic matching user's latest screenshot serial.
   * Format: 20260206 + prefix + sequential_serial (531170xxx range)
   */
  const getPeriodId = (tab: '30s' | '1m' | '3m' | '5m', cycleOffset: number = 0) => {
    const now = Date.now();
    const durationSec = durations[tab];
    const cycle = Math.floor(now / (durationSec * 1000)) + cycleOffset;
    const prefix = tab === '30s' ? '1000' : tab === '1m' ? '2000' : tab === '3m' ? '3000' : '5000';
    // Serial starting point from the screenshot: 531170750
    const serial = 531170750 + cycle;
    return `20260206${prefix}${serial}`;
  };

  const currentPeriod = useMemo(() => getPeriodId(activeTab), [activeTab, timeLeft]);

  /**
   * Seeded Random Result Generation for stability.
   */
  const seededRandomResult = (periodId: string): GameResult => {
    const seedString = periodId.slice(-9);
    const seed = parseInt(seedString) || 0;
    const prng = (s: number) => {
      const x = Math.sin(s) * 10000;
      return x - Math.floor(x);
    };
    const val = prng(seed);
    const num = Math.floor(val * 10);
    const bigSmall = num >= 5 ? 'Big' : 'Small';
    const color = num === 0 ? ['red', 'violet'] : num === 5 ? ['green', 'violet'] : [1,3,7,9].includes(num) ? ['green'] : ['red'];
    return { period: periodId, number: num, bigSmall, color };
  };

  // Result modal auto-close timer (3 seconds)
  useEffect(() => {
    let timer: any;
    if (resultModal?.isOpen) {
      timer = setTimeout(() => {
        setResultModal(null);
      }, 3000);
    }
    return () => clearTimeout(timer);
  }, [resultModal?.isOpen]);

  // Main game loop
  useEffect(() => {
    const updateTimer = () => {
      const nowMs = Date.now();
      const durationMs = durations[activeTab] * 1000;
      const elapsedInCycle = nowMs % durationMs;
      const remainingMs = durationMs - elapsedInCycle;
      const remainingSec = Math.ceil(remainingMs / 1000);
      
      if (remainingSec <= 5 && remainingSec > 0 && remainingSec !== timeLeft) speak(remainingSec.toString());
      setTimeLeft(remainingSec);

      if (remainingSec === durations[activeTab]) {
        const prevPeriod = getPeriodId(activeTab, -1);
        const result = seededRandomResult(prevPeriod);
        
        // Instant table update
        setHistory(prev => {
          if (prev[0]?.period === result.period) return prev;
          return [result, ...prev.slice(0, 9)];
        });
        
        setIsNewResult(true);
        setTimeout(() => setIsNewResult(false), 2000);
        
        resolveBets(prevPeriod, result);
      }
    };
    updateTimer();
    const timerId = setInterval(updateTimer, 1000);
    return () => clearInterval(timerId);
  }, [activeTab, durations, timeLeft]);

  // Initial history generation
  useEffect(() => {
    const initial: GameResult[] = [];
    for (let i = 1; i <= 10; i++) {
      initial.push(seededRandomResult(getPeriodId(activeTab, -i)));
    }
    setHistory(initial);
  }, [activeTab]);

  const resolveBets = (period: string, result: GameResult) => {
    setMyBets(prev => prev.map(bet => {
      if (bet.period === period && bet.status === 'pending') {
        let isWin = false;
        let mult = 0;
        if (typeof bet.type === 'number') {
          // Numbers: 7.5x
          if (bet.type === result.number) { isWin = true; mult = 7.5; }
        } else if (bet.type === 'big' || bet.type === 'small') {
          // Big/Small: 1.95x
          if (bet.type.toLowerCase() === result.bigSmall.toLowerCase()) { isWin = true; mult = 1.95; }
        } else if (result.color.includes(bet.type as string)) {
          // Colors: 2.25x
          isWin = true; 
          mult = 2.25;
        }

        if (isWin) {
          const winAmt = bet.amount * mult;
          setUser(u => u ? { ...u, balance: u.balance + winAmt } : null);
          setResultModal({ isOpen: true, status: 'win', amount: winAmt, type: bet.type, period: bet.period, multiplier: mult });
          speak("Win");
          return { ...bet, status: 'win', winAmount: winAmt, resultNumber: result.number };
        } else {
          setResultModal({ isOpen: true, status: 'loss', amount: bet.amount, type: bet.type, period: bet.period, multiplier: 0 });
          speak("Loss");
          return { ...bet, status: 'loss', winAmount: 0, resultNumber: result.number };
        }
      }
      return bet;
    }));
  };

  const isLocked = timeLeft <= 5;
  const timeDisplay = {
    m1: Math.floor(Math.floor(timeLeft / 60) / 10),
    m2: Math.floor(timeLeft / 60) % 10,
    s1: Math.floor((timeLeft % 60) / 10),
    s2: (timeLeft % 60) % 10,
  };

  const handleBetClick = (type: string | number) => {
    if (isLocked) return;
    setSelectedBetType(type);
    setBetModalOpen(true);
    setModalQuantity(1);
    setModalXMultiplier(1);
    setAgreedToRules(true);
  };

  const currentTotalAmount = modalBaseAmount * modalQuantity * modalXMultiplier;

  const handleFinalBet = () => {
    if (!agreedToRules) { addNotification("Please agree to pre-sale rules", "error"); return; }
    if (user.balance < currentTotalAmount) { addNotification("ব্যালেন্স নেই!", "error"); return; }
    const newBet: UserBet = { period: currentPeriod, amount: currentTotalAmount, type: selectedBetType!, status: 'pending' };
    setMyBets(prev => [newBet, ...prev]);
    setUser(prev => prev ? { ...prev, balance: prev.balance - currentTotalAmount, totalTurnover: (prev.totalTurnover || 0) + currentTotalAmount } : null);
    addNotification(`বেড সফল: ৳${currentTotalAmount}`, "success");
    setBetModalOpen(false);
  };

  return (
    <div className="fixed inset-0 bg-[#f8f9fc] flex flex-col font-sans z-[100] animate-in fade-in duration-300 overflow-hidden">
      {/* Header */}
      <header className="bg-[#fbbf24] p-3 shadow-lg flex-shrink-0 z-[110]">
        <div className="flex items-center justify-between mb-3 px-2">
          <div className="flex items-center gap-2">
            <button onClick={onBack} className="text-white p-1 hover:bg-white/10 rounded-full active:scale-90 transition-transform"><ChevronLeft size={24} strokeWidth={3} /></button>
            <span className="text-white font-black text-xl tracking-tight uppercase">WALLET 888</span>
          </div>
          <div className="flex items-center gap-4 text-white">
            <Headset size={22} className="active:opacity-50" />
            {soundEnabled ? <Volume2 size={22} onClick={() => setSoundEnabled(false)} className="cursor-pointer" /> : <VolumeX size={22} onClick={() => setSoundEnabled(true)} className="cursor-pointer" />}
          </div>
        </div>
        <div className="flex justify-center">
          <div className="bg-white/20 backdrop-blur-md px-8 py-2 rounded-full border border-white/30 shadow-inner flex items-center gap-4">
             <span className="text-[10px] font-black text-white/70 uppercase tracking-widest">Balance</span>
             <span className="text-2xl font-black text-white tabular-nums">৳ {user.balance.toFixed(2)}</span>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar bg-gray-50/50 pb-20">
        <div className="bg-[#fbbf24] px-4 pb-3">
          <div className="flex gap-1 bg-white/10 p-1.5 rounded-2xl">
            {(['30s', '1m', '3m', '5m'] as const).map((t) => (
              <button key={t} onClick={() => setActiveTab(t)} className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${activeTab === t ? 'bg-white text-[#fbbf24] shadow-md scale-[1.05]' : 'text-white/60'}`}>WINGO {t}</button>
            ))}
          </div>
        </div>

        {/* Timer Box */}
        <div className="m-4 mt-2 p-6 bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] rounded-[2.5rem] text-white relative shadow-2xl border border-white/20 overflow-hidden">
          <div className="flex justify-between items-center relative z-10">
            <div className="space-y-6">
              <div className="flex items-center gap-1.5 bg-white/20 px-4 py-1.5 rounded-full w-fit text-[9px] font-black uppercase tracking-widest border border-white/10 shadow-sm">How to play</div>
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.2em] opacity-80 mb-3 text-white/90">WINGO {activeTab.toUpperCase()}</p>
                <div className="flex gap-2">
                   {history.slice(0, 5).map((row, i) => (
                     <div key={i} className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-black border border-white/30 shadow-md ${row?.color?.includes('green') ? 'bg-green-500' : (row?.color?.includes('red') ? 'bg-red-500' : 'bg-purple-500')}`}>{row?.number}</div>
                   ))}
                </div>
              </div>
            </div>
            <div className="text-right flex flex-col items-end">
              <p className="text-[11px] uppercase font-black opacity-80 mb-3 tracking-[0.2em]">Time remaining</p>
              <div className="flex gap-2">
                {[timeDisplay.m1, timeDisplay.m2, ':', timeDisplay.s1, timeDisplay.s2].map((v, i) => (
                  v === ':' ? <span key={i} className="text-3xl font-black mx-1 opacity-50 self-center">:</span> :
                  <div key={i} className="bg-white text-[#fbbf24] w-9 h-14 rounded-xl flex items-center justify-center text-3xl font-black shadow-lg border border-white/50">{v}</div>
                ))}
              </div>
              <p className="text-[10px] font-black mt-4 font-mono opacity-80 tracking-tighter leading-none select-all">{currentPeriod}</p>
            </div>
          </div>
          {isLocked && <div className="absolute inset-0 bg-black/10 backdrop-blur-[2px] z-20 flex items-center justify-center animate-in fade-in duration-300"><span className="text-[130px] font-black text-white/50 animate-pulse leading-none select-none">{timeLeft}</span></div>}
        </div>

        {/* Stake Section */}
        <div className="px-4 space-y-5 mt-4">
          <div className="flex gap-2.5">
            <button disabled={isLocked} onClick={() => handleBetClick('green')} className="flex-1 bg-[#22c55e] text-white font-black py-4 rounded-2xl shadow-lg border-b-4 border-green-700 uppercase text-[12px] tracking-[0.15em] active:scale-95 disabled:opacity-30 transition-all">Green</button>
            <button disabled={isLocked} onClick={() => handleBetClick('violet')} className="flex-1 bg-[#a855f7] text-white font-black py-4 rounded-2xl shadow-lg border-b-4 border-purple-700 uppercase text-[12px] tracking-[0.15em] active:scale-95 disabled:opacity-30 transition-all">Violet</button>
            <button disabled={isLocked} onClick={() => handleBetClick('red')} className="flex-1 bg-[#ef4444] text-white font-black py-4 rounded-2xl shadow-lg border-b-4 border-red-700 uppercase text-[12px] tracking-[0.15em] active:scale-95 disabled:opacity-30 transition-all">Red</button>
          </div>

          <div className="bg-white rounded-[2.5rem] p-6 grid grid-cols-5 gap-4 shadow-xl border border-gray-100/50">
            {[0,1,2,3,4,5,6,7,8,9].map(n => (
              <button key={n} disabled={isLocked} onClick={() => handleBetClick(n)} className="aspect-square rounded-full flex items-center justify-center text-2xl font-black text-white shadow-xl border-4 border-white transition-transform active:scale-90 disabled:opacity-30" style={{ background: n===0 ? 'linear-gradient(135deg,#ef4444 50%,#a855f7 50%)' : n===5 ? 'linear-gradient(135deg,#22c55e 50%,#a855f7 50%)' : [1,3,7,9].includes(n) ? '#22c55e' : '#ef4444' }}>{n}</button>
            ))}
          </div>

          <div className="flex gap-4">
            <button disabled={isLocked} onClick={() => handleBetClick('big')} className="flex-1 py-7 rounded-[2.5rem] bg-gradient-to-r from-orange-400 to-orange-500 border-b-8 border-orange-700 text-white font-black uppercase text-4xl shadow-2xl active:scale-95 disabled:opacity-30 tracking-[0.1em] transition-all">BIG</button>
            <button disabled={isLocked} onClick={() => handleBetClick('small')} className="flex-1 py-7 rounded-[2.5rem] bg-gradient-to-r from-blue-500 to-blue-600 border-b-8 border-blue-800 text-white font-black uppercase text-4xl shadow-2xl active:scale-95 disabled:opacity-30 tracking-[0.1em] transition-all">SMALL</button>
          </div>
        </div>

        {/* Improved History Tabs - Just Game and My */}
        <div className="m-4 mt-8 space-y-5">
          <div className="flex gap-2.5 p-1 bg-white rounded-2xl shadow-sm border border-gray-100">
            {(['game','my'] as const).map(t => (
              <button key={t} onClick={() => setHistoryTab(t)} className={`flex-1 py-3 rounded-xl font-black text-[10px] uppercase tracking-[0.15em] transition-all ${historyTab === t ? 'bg-[#fbbf24] text-white shadow-lg scale-105' : 'text-gray-400 hover:bg-gray-50'}`}>{t === 'game' ? 'Game History' : 'My History'}</button>
            ))}
          </div>

          {historyTab === 'game' ? (
            <div className="bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-gray-100">
              <table className="w-full text-center">
                <thead className="bg-[#fbbf24] text-white text-[10px] font-black uppercase tracking-widest">
                  <tr><th className="py-5 pl-5 text-left w-[55%]">Period</th><th className="w-[12%]">Number</th><th className="w-[15%]">Big Small</th><th className="pr-5 text-right w-[18%]">Color</th></tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {history.slice(0, 10).map((r, idx) => (
                    <tr key={r?.period || idx} className={`transition-all duration-300 ${isNewResult && idx === 0 ? 'bg-amber-50' : ''}`}>
                      <td className="py-5 pl-5 text-[10.5px] font-black text-gray-500 font-mono tracking-tighter text-left whitespace-nowrap overflow-visible leading-none">{r?.period}</td>
                      <td className="py-5 text-2xl font-black tabular-nums" style={{ color: r?.color?.includes('violet') ? '#a855f7' : (r?.color?.includes('green') ? '#22c55e' : '#ef4444') }}>{r?.number}</td>
                      <td className="py-5 text-[11px] font-black uppercase tracking-widest text-gray-800">{r?.bigSmall}</td>
                      <td className="py-5 pr-5">
                        <div className="flex justify-end gap-1.5">
                          {r?.color?.map((c, i) => (<div key={i} className={`w-4 h-4 rounded-full border-2 border-white shadow-sm ${c==='green' ? 'bg-green-500' : (c==='red' ? 'bg-red-500' : 'bg-purple-500')}`}></div>))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-gray-100 min-h-[300px]">
              {myBets.length === 0 ? (
                <div className="p-20 text-center flex flex-col items-center gap-4 animate-in fade-in duration-500">
                  <span className="text-[11px] font-black text-gray-300 uppercase tracking-[0.4em]">Empty Records</span>
                  <HelpCircle className="text-gray-200" size={40} />
                </div>
              ) : (
                <table className="w-full text-center">
                  <thead className="bg-[#fbbf24] text-white text-[10px] font-black uppercase tracking-widest">
                    <tr><th className="py-5 pl-5 text-left">Period</th><th>Stake</th><th>Payout</th><th className="pr-5 text-right">Result</th></tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {myBets.map((bet, idx) => (
                      <tr key={idx} className="animate-in fade-in slide-in-from-right duration-300">
                        <td className="py-5 pl-5 text-[10.5px] font-black text-gray-500 font-mono tracking-tighter text-left leading-none">
                          {bet.period.slice(-8)}
                        </td>
                        <td className="py-5 text-[11px] font-black tabular-nums text-gray-800">৳{bet.amount}</td>
                        <td className={`py-5 text-[11px] font-black tabular-nums ${bet.status === 'win' ? 'text-green-500' : (bet.status === 'loss' ? 'text-rose-500' : 'text-amber-500')}`}>
                          {bet.status === 'win' ? `+৳${bet.winAmount?.toFixed(1)}` : (bet.status === 'loss' ? `-৳${bet.amount}` : 'Pending')}
                        </td>
                        <td className="py-5 pr-5 text-right">
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border-2 ${
                            bet.status === 'win' ? 'bg-green-50 border-green-200 text-green-600' : 
                            (bet.status === 'loss' ? 'bg-rose-50 border-rose-200 text-rose-600' : 'bg-amber-50 border-amber-200 text-amber-600')
                          }`}>
                            {bet.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-22 left-0 right-0 flex justify-center items-center gap-2 opacity-30 pointer-events-none"><ShieldCheck size={14} className="text-green-500" /><span className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">REAL-TIME LIVE FEED</span></div>

      {/* WIN/LOSS MODAL with 3s timer and cancel */}
      {resultModal?.isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-8 animate-in fade-in zoom-in duration-400">
           <div className="absolute inset-0 bg-black/85 backdrop-blur-xl" onClick={() => setResultModal(null)}></div>
           <div className={`relative w-full max-w-sm rounded-[3.5rem] p-12 text-center shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border-[8px] bg-white ${resultModal.status === 'win' ? 'border-amber-400' : 'border-gray-200'}`}>
              {resultModal.status === 'win' ? (
                <div className="space-y-8">
                  <Trophy size={110} className="text-amber-500 mx-auto animate-bounce drop-shadow-[0_0_15px_rgba(245,158,11,0.5)]" />
                  <h3 className="text-4xl font-black text-amber-600 uppercase tracking-tighter">Winner!</h3>
                  <div className="bg-amber-50 p-8 rounded-[2.5rem] border border-amber-100 shadow-inner">
                    <p className="text-[11px] font-black text-amber-400 uppercase mb-2 tracking-[0.2em]">Payout</p>
                    <p className="text-5xl font-black text-amber-600">৳{resultModal.amount.toFixed(2)}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-8 opacity-90">
                  <Frown size={110} className="text-gray-300 mx-auto opacity-40" />
                  <h3 className="text-3xl font-black text-gray-400 uppercase tracking-tighter">Better Luck Next</h3>
                  <div className="p-6 bg-gray-50 rounded-[2.5rem] border border-gray-100">
                    <p className="text-[11px] font-bold text-gray-400 leading-relaxed italic">"Try the next sequential round! Live results favor everyone."</p>
                  </div>
                </div>
              )}
              
              <div className="flex gap-4 mt-12">
                <button onClick={() => setResultModal(null)} className="flex-1 py-6 rounded-[2.5rem] font-black uppercase text-[12px] tracking-[0.25em] bg-gray-50 text-gray-500 active:scale-95 transition-all shadow-sm">Cancel</button>
                <button onClick={() => setResultModal(null)} className="flex-[2] py-6 rounded-[2.5rem] font-black uppercase text-[12px] tracking-[0.25em] bg-[#fbbf24] text-white active:scale-95 transition-all shadow-md">Confirm</button>
              </div>
              <div className="mt-4 text-[10px] font-black text-gray-300 uppercase tracking-widest animate-pulse">Closing in 3s...</div>
           </div>
        </div>
      )}

      {/* Stake Confirmation Modal */}
      {betModalOpen && (
        <div className="fixed inset-0 z-[150] flex flex-col justify-end animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setBetModalOpen(false)}></div>
          <div className="relative w-full bg-white rounded-t-[2.5rem] overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-400 flex flex-col">
            <div className="bg-[#ffa84d] py-3 px-6 flex flex-col items-center">
              <span className="text-white text-sm font-bold">WinGo 30sec</span>
              <div className="w-full bg-white rounded-lg mt-2 py-1.5 flex justify-center shadow-sm">
                 <span className="text-gray-800 text-sm font-medium">Select {typeof selectedBetType === 'string' ? selectedBetType.charAt(0).toUpperCase() + selectedBetType.slice(1) : selectedBetType}</span>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-[#1a2b4b] text-lg font-semibold">Balance</span>
                <div className="flex gap-2">
                  {[1, 10, 100, 1000].map(v => (
                    <button key={v} onClick={() => setModalBaseAmount(v)} className={`w-14 py-2 rounded-md text-sm font-bold transition-all ${modalBaseAmount === v ? 'bg-[#ffa84d] text-white shadow-md' : 'bg-[#f5f7fa] text-gray-400'}`}>{v}</button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[#1a2b4b] text-lg font-semibold">Quantity</span>
                <div className="flex items-center gap-1 bg-[#f5f7fa] p-1 rounded-md">
                   <button onClick={() => setModalQuantity(Math.max(1, modalQuantity - 1))} className="w-8 h-8 bg-[#ffa84d]/20 text-[#ffa84d] rounded flex items-center justify-center active:scale-90"><Minus size={16} strokeWidth={3} /></button>
                   <input type="number" value={modalQuantity} onChange={e => setModalQuantity(Math.max(1, parseInt(e.target.value) || 1))} className="w-12 bg-transparent text-center font-bold text-gray-800 outline-none" />
                   <button onClick={() => setModalQuantity(modalQuantity + 1)} className="w-8 h-8 bg-[#ffa84d] text-white rounded flex items-center justify-center active:scale-90"><Plus size={16} strokeWidth={3} /></button>
                </div>
              </div>

              <div className="flex justify-end gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {[1, 5, 10, 20, 50, 100].map(v => (
                  <button key={v} onClick={() => setModalXMultiplier(v)} className={`px-3.5 py-2 rounded-md text-xs font-bold transition-all ${modalXMultiplier === v ? 'bg-[#ffa84d] text-white shadow-sm' : 'bg-[#f5f7fa] text-gray-400'}`}>X{v}</button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button onClick={() => setAgreedToRules(!agreedToRules)} className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${agreedToRules ? 'bg-[#ffa84d]' : 'border-2 border-gray-300'}`}>
                  {agreedToRules && <Check size={12} className="text-white" strokeWidth={4} />}
                </button>
                <p className="text-sm font-medium text-gray-500">I agree <span className="text-[#ff6b6b]">《Pre-sale rules》</span></p>
              </div>
            </div>

            <div className="flex h-14 border-t border-gray-100">
              <button onClick={() => setBetModalOpen(false)} className="w-1/3 bg-[#f5f7fa] text-gray-400 font-bold uppercase text-sm flex items-center justify-center tracking-widest active:bg-gray-100 transition-colors">Cancel</button>
              <button onClick={handleFinalBet} className="flex-1 bg-[#ffa84d] text-white font-bold text-base flex items-center justify-center active:opacity-90 transition-opacity">Total amount ৳{currentTotalAmount.toFixed(2)}</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default WingoGame;
