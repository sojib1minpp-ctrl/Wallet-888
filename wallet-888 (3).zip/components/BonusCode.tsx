
import React, { useState } from 'react';
import { User, BonusCode } from '../types';
import { ChevronLeft, Ticket } from 'lucide-react';

interface BonusCodeProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  bonusCodes: BonusCode[];
  setBonusCodes: React.Dispatch<React.SetStateAction<BonusCode[]>>;
  onBack: () => void;
  addNotification: (msg: string, type: any) => void;
  updateBalance: (amt: number) => void;
}

const BonusCodeView: React.FC<BonusCodeProps> = ({ user, setUser, bonusCodes, setBonusCodes, onBack, addNotification, updateBalance }) => {
  const [code, setCode] = useState('');

  const handleClaim = () => {
    if (!code) return;
    
    const uppercaseCode = code.trim().toUpperCase();
    const foundCode = bonusCodes.find(c => c.code === uppercaseCode);

    if (!foundCode) {
      addNotification("ভুল বোনাস কোড! আবার চেষ্টা করুন।", "error");
      return;
    }

    // Check if user already used this code
    if (user.usedBonusCodes?.includes(foundCode.id)) {
      addNotification("আপনি ইতিমধ্যে এই কোডটি ব্যবহার করেছেন!", "error");
      return;
    }

    // Check if limit reached
    if (foundCode.currentUses >= foundCode.maxUses) {
      addNotification("দুঃখিত, এই কোডের লিমিট শেষ হয়ে গেছে!", "error");
      return;
    }

    // Success: Update balance and track usage
    const reward = foundCode.reward;
    
    // Update global bonusCodes state
    setBonusCodes(prev => prev.map(c => 
      c.id === foundCode.id ? { ...c, currentUses: c.currentUses + 1 } : c
    ));

    // Update user state
    setUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        balance: prev.balance + reward,
        usedBonusCodes: [...(prev.usedBonusCodes || []), foundCode.id]
      };
    });

    addNotification(`অভিনন্দন! আপনি ৳${reward} বোনাস পেয়েছেন!`, "success");
    setCode('');
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between px-1">
        <button onClick={onBack} className="flex items-center gap-1 text-gray-500 dark:text-gray-400 font-bold">
          <ChevronLeft size={20} /> Back
        </button>
        <h2 className="text-xl font-black dark:text-white uppercase tracking-tight">Redeem Rewards</h2>
        <div className="w-10"></div>
      </div>

      <div className="bg-white dark:bg-gray-800 p-10 rounded-[3rem] shadow-2xl border border-gray-100 dark:border-gray-700 text-center space-y-8">
        <div className="w-24 h-24 bg-pink-50 dark:bg-pink-900/20 text-pink-600 dark:text-pink-400 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-inner border border-pink-100 dark:border-pink-900/30">
          <Ticket size={48} strokeWidth={2.5} />
        </div>
        
        <div className="space-y-3">
          <h3 className="text-2xl font-black dark:text-white tracking-tight leading-none uppercase">Enter Bonus Code</h3>
          <p className="text-xs text-gray-400 font-bold leading-relaxed px-4">
            আমাদের অফিশিয়াল চ্যানেল থেকে পাওয়া স্পেশাল কোডটি এখানে দিন এবং সাথে সাথে জিতে নিন বোনাস টাকা!
          </p>
        </div>

        <div className="space-y-5">
          <div className="relative group">
             <input 
              type="text" 
              value={code}
              onChange={e => setCode(e.target.value)}
              placeholder="ENTER CODE HERE" 
              className="w-full px-8 py-6 rounded-[2rem] bg-[#f8faff] dark:bg-gray-700 dark:text-white border-2 border-indigo-50 dark:border-gray-600 focus:border-indigo-500 outline-none text-center font-black text-xl tracking-[0.25em] shadow-inner transition-all"
            />
          </div>
          
          <button 
            onClick={handleClaim}
            className="w-full bg-[#5343e8] hover:bg-[#4335c9] text-white font-black py-6 rounded-[2rem] shadow-[0_20px_40px_-10px_rgba(83,67,232,0.4)] active:scale-[0.96] transition-all uppercase tracking-[0.2em] text-sm"
          >
            Claim Rewards Now
          </button>
        </div>
        
        <div className="flex items-center justify-center gap-2 pt-4 opacity-40">
           <span className="w-1 h-1 rounded-full bg-gray-400"></span>
           <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest">One-time use per verified user</p>
           <span className="w-1 h-1 rounded-full bg-gray-400"></span>
        </div>
      </div>

      <div className="bg-indigo-50 dark:bg-indigo-900/10 p-6 rounded-[2rem] border border-indigo-100 dark:border-indigo-800 flex gap-4 items-center">
         <div className="bg-indigo-600 text-white p-2 rounded-xl">
            <Ticket size={18} />
         </div>
         <p className="text-[11px] font-bold text-indigo-700 dark:text-indigo-400 leading-relaxed">
           টিপস: আমাদের টেলিগ্রাম গ্রুপে নিয়মিত নতুন বোনাস কোড দেওয়া হয়। দ্রুত জয়েন করুন!
         </p>
      </div>
    </div>
  );
};

export default BonusCodeView;
